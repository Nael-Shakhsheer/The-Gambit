const $ = (selector) => document.querySelector(selector);
const CLASS_ORDER = ["Knight", "Wizard", "Archer", "Cleric", "Rogue", "Druid", "Bard", "Healer"];
const SYMBOLS = { Knight: "♜", Wizard: "✦", Archer: "➶", Cleric: "✚", Rogue: "⚔", Druid: "❧", Bard: "♫", Healer: "✧" };
const DEFAULT_BINDINGS = { up: "w", down: "s", left: "a", right: "d", special: "q", ultimate: "x", revive: "e" };
const BINDING_LABELS = { up: "Move up", down: "Move down", left: "Move left", right: "Move right", special: "Special attack", ultimate: "Ultimate attack", revive: "Revive / interact" };
let keyBindings;
try { keyBindings = Object.assign({}, DEFAULT_BINDINGS, JSON.parse(localStorage.getItem("gauntlet-keybindings") || "{}")); }
catch { keyBindings = Object.assign({}, DEFAULT_BINDINGS); }
let bindingCapture = null;
let session = JSON.parse(localStorage.getItem("gauntlet-session") || "null");
let lastChatSignature = "";
let lastPuzzleId = "";
let lastPuzzleClue = "";
let puzzleDialogueTimer = null;
let lastTownSignature = "";
let lastRouteSignature = "";
let lastLoadoutSignature = "";
let lastAbilityBarSignature = "";
let lastClassSignature = "";
let lastChestSignature = "";
let lastPrivateNotice = "";
let privateNoticeUntil = 0;
let latestRoom = null;
let arenaPointerActive = false;
let polling = false;
let moveState = { x: 0, y: 0, attack: false };
let lastSentMove = "";
let lastInputSent = 0;
const motionTracks = new Map();
let motionScene = "";
let lastSnapshotAt = 0;
const terrainLayer = document.createElement("canvas");
let terrainKey = "";
const glowLayers = new Map();
const heroSprites = {};
const SPRITE_DIRECTIONS = ["south", "south-east", "east", "north-east", "north", "north-west", "west", "south-west"];
for (const role of ["Knight", "Wizard", "Serpent", "Minotaur"]) {
  const base = "/sprites/" + role.toLowerCase() + "-idle";
  const image = new Image();
  const sprite = heroSprites[role] = { image, sheet: null };
  image.src = base + ".png";
  fetch(base + ".json").then((response) => {
    if (!response.ok) throw new Error("Sprite metadata unavailable");
    return response.json();
  }).then((metadata) => { sprite.sheet = metadata.spritesheet; })
    .catch(() => { sprite.sheet = null; });
}

function drawImportedHero(ctx, player, x, y, spriteKey = player.class) {
  const sprite = heroSprites[spriteKey];
  if (!sprite?.sheet || !sprite.image.complete || !sprite.image.naturalWidth) return false;
  const sheet = sprite.sheet;
  const directionIndex = (Math.round((Math.PI / 2 - Math.atan2(player.facingY ?? 1, player.facingX ?? 0)) / (Math.PI / 4)) + 8) % 8;
  const row = sheet.rows.find((entry) => entry.type === "animation" && entry.direction === SPRITE_DIRECTIONS[directionIndex]);
  if (!row) return false;
  const now = Date.now();
  let frames = spriteKey === "Minotaur" ? (player.moving ? [3, 4, 5] : [0, 1, 2]) : player.moving ? [2, 3] : [0, 1];
  let frameIndex = Math.floor(now / 180);
  if (player.status !== "alive") frames = [0];
  else if (player.animationUntil * 1000 > now) {
    frames = ["Serpent", "Minotaur"].includes(spriteKey) ? [6, 7, 8] : player.animation === "ultimate" ? [8] : player.animation === "special" ? [7] : [4, 5, 6];
    frameIndex = Math.max(0, Math.min(frames.length - 1, Math.floor((now - (player.animationUntil * 1000 - 450)) / 130)));
  }
  const column = frames[frameIndex % frames.length];
  const cell = sheet.cell_size;
  ctx.imageSmoothingEnabled = false;
  ctx.save();
  if (player.status !== "alive") {
    ctx.translate(x, y); ctx.rotate(Math.PI / 2); ctx.translate(-x, -y);
  }
  ctx.drawImage(sprite.image, column * cell.width, row.row * cell.height, cell.width, cell.height,
    x - 32, y - 42, 64, 64);
  ctx.restore();
  return true;
}

async function api(path, data) {
  if (window.location.protocol === "file:") {
    throw new Error("Open the game at http://127.0.0.1:8000/ with server.py running. This file preview cannot connect to the game server.");
  }
  const response = await fetch(path, {
    method: data ? "POST" : "GET",
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Something went wrong.");
  return result;
}
function sendAction(action, extra) {
  if (!session) return Promise.resolve();
  return api("/api/action", Object.assign({ room: session.room, player: session.player, action }, extra || {}));
}
function saveSession(value) {
  session = value;
  localStorage.setItem("gauntlet-session", JSON.stringify(value));
  enterLobby();
  refresh();
}
function enterLobby() {
  $("#entry").classList.add("hidden");
  $("#lobby").classList.remove("hidden");
  $("#roomCodeDisplay").textContent = session.room;
  $("#connection").textContent = "CONNECTING";
  $("#connection").className = "connection connecting";
}
function notice(element, message) { element.textContent = message; }

$("#createForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  notice($("#entryNotice"), "");
  try {
    const result = await api("/api/rooms", { name: $("#createName").value });
    saveSession({ room: result.room, player: result.player });
  } catch (error) { notice($("#entryNotice"), error.message); }
});
$("#joinForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  notice($("#entryNotice"), "");
  try {
    const result = await api("/api/join", { name: $("#joinName").value, room: $("#roomCode").value });
    saveSession({ room: result.room, player: result.player });
  } catch (error) { notice($("#entryNotice"), error.message); }
});
function renderKeyBindings() {
  const fields = $("#keyBindingFields");
  fields.replaceChildren();
  Object.entries(BINDING_LABELS).forEach(([action, label]) => {
    const row = document.createElement("div");
    row.className = "key-binding-row";
    const name = document.createElement("span"); name.textContent = label;
    const button = document.createElement("button"); button.type = "button"; button.className = "secondary key-bind";
    button.dataset.bind = action;
    button.textContent = bindingCapture === action ? "Press a key…" : String(keyBindings[action] || DEFAULT_BINDINGS[action]).toUpperCase();
    button.setAttribute("aria-label", label + " key, currently " + button.textContent);
    row.append(name, button); fields.append(row);
  });
  $("#controlHint").textContent = "Move: WASD · Dash: Space (5s) · Light attack: Left click · Special: " + String(keyBindings.special).toUpperCase() +
    " · Ultimate: " + String(keyBindings.ultimate).toUpperCase();
}
$("#openSettings").addEventListener("click", () => { $("#keySettings").classList.remove("hidden"); renderKeyBindings(); });
$("#closeSettings").addEventListener("click", () => { bindingCapture = null; $("#keySettings").classList.add("hidden"); });
$("#resetBindings").addEventListener("click", () => {
  keyBindings = Object.assign({}, DEFAULT_BINDINGS);
  localStorage.setItem("gauntlet-keybindings", JSON.stringify(keyBindings));
  bindingCapture = null; renderKeyBindings();
});
$("#keyBindingFields").addEventListener("click", (event) => {
  const button = event.target.closest("[data-bind]");
  if (button) { bindingCapture = button.dataset.bind; renderKeyBindings(); }
});
$("#roomCode").addEventListener("input", (event) => { event.target.value = event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ""); });
$("#copyCode").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(session.room);
    $("#copyCode").textContent = "Copied!";
    setTimeout(() => $("#copyCode").textContent = "Copy invite code", 1600);
  } catch { $("#copyCode").textContent = "Code: " + session.room; }
});
async function returnToMainMenu() {
  try { await sendAction("leaveRoom"); } catch { /* The room may have expired; clear the saved local session either way. */ }
  session = null;
  latestRoom = null;
  localStorage.removeItem("gauntlet-session");
  $("#lobby").classList.add("hidden");
  $("#entry").classList.remove("hidden");
  document.body.classList.remove("is-playing");
  $("#connection").textContent = "READY";
  $("#connection").className = "connection";
  const filePreview = window.location.protocol === "file:";
  notice($("#entryNotice"), filePreview ?
    "This file preview cannot reach multiplayer. Open the live server page instead." : "");
  $("#liveGameLink").classList.toggle("hidden", !filePreview);
  notice($("#roomNotice"), "");
}
$("#mainMenu").addEventListener("click", returnToMainMenu);
$("#mainMenuGame").addEventListener("click", returnToMainMenu);
$("#startRun").addEventListener("click", async () => {
  try { await sendAction("start"); refresh(); }
  catch (error) { notice($("#entryNotice"), error.message); }
});
$("#abilityChoices").addEventListener("click", async (event) => {
  const button = event.target.closest("[data-ability]");
  if (!button || !latestRoom) return;
  const current = latestRoom.selectedAbilities.slice();
  const id = button.dataset.ability;
  const ability = (latestRoom.abilityOptions[latestRoom.players.find((player) => player.id === latestRoom.you)?.class] || []).find((entry) => entry.id === id);
  if (!ability) return;
  const currentRecords = latestRoom.abilityOptions[latestRoom.players.find((player) => player.id === latestRoom.you)?.class] || [];
  const category = ability.attackType;
  const next = current.filter((entry) => currentRecords.find((option) => option.id === entry)?.attackType !== category);
  if (!current.includes(id)) next.push(id);
  const order = { light: 0, special: 1, ultimate: 2 };
  next.sort((a, b) => order[currentRecords.find((option) => option.id === a)?.attackType] - order[currentRecords.find((option) => option.id === b)?.attackType]);
  try { await sendAction("loadout", { abilities: next }); notice($("#abilityNotice"), next.length + " of 3 selected."); refresh(); }
  catch (error) { notice($("#abilityNotice"), error.message); }
});
$("#abilityButtons").addEventListener("click", async (event) => {
  const button = event.target.closest("[data-ability-slot]");
  if (!button || button.disabled) return;
  try { await sendAction("ability", { slot: Number(button.dataset.abilitySlot) }); notice($("#combatNotice"), ""); refresh(); }
  catch (error) { notice($("#combatNotice"), error.message); }
});
async function triggerAbility(category) {
  if (!latestRoom || latestRoom.phase !== "combat") return;
  if (latestRoom.waveCountdown) return;
  const index = latestRoom.abilitySlots.findIndex((ability) => ability.attackType === category);
  if (index < 0) return notice($("#combatNotice"), "Choose this ability in your class loadout first.");
  try { await sendAction("ability", { slot: index + 1 }); notice($("#combatNotice"), ""); refresh(); }
  catch (error) { notice($("#combatNotice"), error.message); }
}
async function triggerDash() {
  if (!latestRoom || latestRoom.phase !== "combat" || latestRoom.dashCooldown) return;
  try { await sendAction("dash"); refresh(); }
  catch (error) { notice($("#combatNotice"), error.message); }
}
$("#chestSwapChoices").addEventListener("click", async (event) => {
  const button = event.target.closest("[data-chest-swap]");
  if (!button) return;
  try { await sendAction("chestClaim", { replace: button.dataset.chestSwap }); notice($("#chestNotice"), ""); refresh(); }
  catch (error) { notice($("#chestNotice"), error.message); }
});
$("#quickPouch").addEventListener("click", async (event) => {
  const use = event.target.closest("[data-use-item]");
  const equip = event.target.closest("[data-equip-item]");
  const button = use || equip;
  if (!button || button.disabled) return;
  try {
    if (use) await sendAction("useItem", { item: use.dataset.useItem });
    else await sendAction("equipItem", { item: equip.dataset.equipItem, slot: Number(equip.dataset.equipSlot) });
    notice($("#pouchNotice"), ""); refresh();
  } catch (error) { notice($("#pouchNotice"), error.message); }
});
$("#quickGear").addEventListener("click", async (event) => {
  const button = event.target.closest("[data-unequip]");
  if (!button || button.disabled) return;
  try {
    await sendAction("unequipItem", { slotKind: button.dataset.slotKind, slot: Number(button.dataset.slot) });
    notice($("#pouchNotice"), ""); refresh();
  } catch (error) { notice($("#pouchNotice"), error.message); }
});
$("#utilityHotbar").addEventListener("click", async (event) => {
  const button = event.target.closest("[data-use-item]");
  if (!button || button.disabled) return;
  try { await sendAction("useItem", { item: button.dataset.useItem }); refresh(); }
  catch (error) { notice($("#combatNotice"), error.message); }
});
async function triggerUtility(index) {
  if (!latestRoom) return;
  const item = latestRoom.utilitySlots[index];
  const own = latestRoom.players.find((player) => player.id === latestRoom.you);
  if (!item || !canUseUtility(latestRoom, item, own)) return;
  try { await sendAction("useItem", { item: item.id }); refresh(); }
  catch (error) { notice($("#combatNotice"), error.message); }
}
$("#toggleChat").addEventListener("click", () => {
  const panel = $("#chatPanel");
  panel.classList.toggle("hud-open");
  $("#toggleChat").textContent = panel.classList.contains("hud-open") ? "Close chat" : "Chat";
});
$("#togglePouch").addEventListener("click", () => {
  const panel = $("#pouchPanel");
  panel.classList.toggle("hud-open");
  $("#togglePouch").textContent = panel.classList.contains("hud-open") ? "Close pouch" : "Pouch";
});
$("#expandPouch").addEventListener("click", () => {
  const expanded = $("#pouchPanel").classList.toggle("pouch-expanded");
  $("#expandPouch").textContent = expanded ? "Collapse" : "Expand";
  $("#expandPouch").setAttribute("aria-expanded", String(expanded));
});
$("#shopStock").addEventListener("click", async (event) => {
  const button = event.target.closest("[data-buy]");
  if (!button) return;
  try { await sendAction("shopBuy", { item: button.dataset.buy }); refresh(); }
  catch (error) { notice($("#townNotice"), error.message); }
});
$("#pouchItems").addEventListener("click", async (event) => {
  const sell = event.target.closest("[data-sell]");
  const use = event.target.closest("[data-use]");
  const equip = event.target.closest("[data-equip-item]");
  try {
    if (sell) await sendAction("shopSell", { item: sell.dataset.sell });
    else if (use) await sendAction("useItem", { item: use.dataset.use });
    else if (equip) await sendAction("equipItem", { item: equip.dataset.equipItem, slot: Number(equip.dataset.equipSlot) });
    else return;
    notice($("#townNotice"), "");
    refresh();
  } catch (error) { notice($("#townNotice"), error.message); }
});
$("#equipmentSlots").addEventListener("click", async (event) => {
  const button = event.target.closest("[data-unequip]");
  if (!button) return;
  try { await sendAction("unequipItem", { slotKind: button.dataset.slotKind, slot: Number(button.dataset.slot) }); refresh(); }
  catch (error) { notice($("#townNotice"), error.message); }
});
$("#closeTownShop").addEventListener("click", async () => {
  try { await sendAction("closeShop"); refresh(); }
  catch (error) { notice($("#townNotice"), error.message); }
});
$("#checkpointResume").addEventListener("click", async () => {
  try { await sendAction("checkpointResume"); refresh(); }
  catch (error) { notice($("#defeatMessage"), error.message); }
});
$("#chatForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const input = $("#chatInput");
  const message = input.value.trim();
  if (!message || !session) return;
  input.value = "";
  try { await sendAction("chat", { message }); }
  catch (error) { input.value = message; input.placeholder = error.message; }
});
$("#attackButton").textContent = "Light attack · Click / Tap";
$("#attackButton").addEventListener("pointerdown", (event) => { event.preventDefault(); triggerAbility("light"); });
$("#dashButton").addEventListener("pointerdown", (event) => { event.preventDefault(); triggerDash(); });
$("#interactButton").addEventListener("click", async () => {
  try { await interactWithWorld(); }
  catch (error) { notice($("#combatNotice"), error.message); }
});
$("#reviveButton").addEventListener("pointerdown", (event) => { event.preventDefault(); sendAction("revive").catch(() => {}); });
["pointerup", "pointerleave", "pointercancel"].forEach((type) => $("#reviveButton").addEventListener(type, (event) => { event.preventDefault(); sendAction("stopRevive").catch(() => {}); }));
$("#world").addEventListener("pointerdown", (event) => {
  if (event.button === 0 && latestRoom && latestRoom.phase === "combat") triggerAbility("light");
});
$("#world").addEventListener("pointermove", () => { arenaPointerActive = true; });
$("#world").addEventListener("pointerleave", () => { arenaPointerActive = false; });
async function chooseClass(name) {
  try { await sendAction("class", { class: name }); refresh(); }
  catch (error) { notice($("#entryNotice"), error.message); }
}
function renderAbilityChoices(room) {
  const mine = room.players.find((player) => player.id === room.you);
  const panel = $("#abilityLoadout");
  const className = mine && mine.class;
  panel.classList.toggle("hidden", room.phase !== "lobby" || !className);
  const options = className ? room.abilityOptions[className] || [] : [];
  const signature = JSON.stringify([className, options, room.selectedAbilities, room.phase]);
  if (signature === lastLoadoutSignature) return;
  lastLoadoutSignature = signature;
  const choices = $("#abilityChoices");
  choices.replaceChildren();
  options.forEach((ability) => {
    const selected = room.selectedAbilities.includes(ability.id);
    const button = document.createElement("button");
    button.className = "ability-choice" + (selected ? " selected" : "") + " category-" + ability.attackType;
    button.dataset.ability = ability.id;
    button.innerHTML = '<b></b><span></span><small></small>';
    button.querySelector("b").textContent = ability.attackType.toUpperCase() + " · " + ability.name + (selected ? " · EQUIPPED" : "");
    button.querySelector("span").textContent = ability.description;
    button.querySelector("small").textContent = ability.attackType === "light" ? "Left click · " + ability.cooldown + "s cooldown" :
      String(keyBindings[ability.attackType]).toUpperCase() + " · " + ability.cooldown + "s cooldown" + (ability.manaCost ? " · " + ability.manaCost + " MP" : "");
    choices.append(button);
  });
  $("#abilityNotice").textContent = (room.selectedAbilities.length || 0) + " of 3 selected. Choose one Light, one Special, and one Ultimate.";
}
function renderAbilityBar(room) {
  const bar = $("#abilityButtons");
  const own = room.players.find((player) => player.id === room.you);
  const signature = JSON.stringify([room.abilitySlots, room.phase, room.waveCountdown, own && own.status,
    room.abilitySlots.map((ability) => room.mana >= ability.manaCost)]);
  if (signature === lastAbilityBarSignature) return;
  lastAbilityBarSignature = signature;
  bar.replaceChildren();
  bar.classList.toggle("hidden", room.phase !== "combat" || !room.abilitySlots.length);
  room.abilitySlots.filter((ability) => ability.attackType !== "light").forEach((ability) => {
    const button = document.createElement("button");
    button.className = "secondary ability-key";
    button.dataset.abilitySlot = String(room.abilitySlots.indexOf(ability) + 1);
    button.title = ability.description;
    button.textContent = String(keyBindings[ability.attackType]).toUpperCase() + " · " + ability.name + (ability.manaCost ? " · " + ability.manaCost + " MP" : "") + (ability.cooldownLeft ? " · " + ability.cooldownLeft + "s" : " · Ready");
    button.disabled = room.phase !== "combat" || Boolean(room.waveCountdown) || !own || own.status !== "alive" || ability.cooldownLeft > 0 || room.mana < ability.manaCost;
    bar.append(button);
  });
}
function renderClasses(room) {
  const grid = $("#classGrid");
  const taken = new Set(room.players.filter((player) => player.class && player.id !== room.you).map((player) => player.class));
  const mine = room.players.find((player) => player.id === room.you);
  const signature = JSON.stringify([room.phase, room.players.map((player) => [player.id, player.class]), room.classes]);
  if (signature !== lastClassSignature) {
    lastClassSignature = signature;
    grid.replaceChildren();
    CLASS_ORDER.forEach((name) => {
      const info = room.classes[name];
      const button = document.createElement("button");
      button.className = "class-card" + (mine && mine.class === name ? " selected" : "");
      button.disabled = room.phase !== "lobby" || (taken.has(name) && (!mine || mine.class !== name));
      button.style.setProperty("--class-color", info.color);
      button.innerHTML = '<span class="class-icon"></span><span class="class-name"></span><span class="class-role"></span>' +
        (taken.has(name) && (!mine || mine.class !== name) ? '<span class="taken">TAKEN</span>' : "");
      button.querySelector(".class-icon").textContent = SYMBOLS[name];
      button.querySelector(".class-name").textContent = name;
      button.querySelector(".class-role").textContent = info.role;
      button.addEventListener("click", () => chooseClass(name));
      grid.append(button);
    });
  }
  grid.classList.toggle("locked", room.phase !== "lobby");
  renderAbilityChoices(room);
}
function renderPlayers(room) {
  const list = $("#players");
  const signature = JSON.stringify([room.phase, room.host, room.you, room.players.map((player) =>
    [player.id, player.name, player.class, player.hp, player.maxHp, player.status, player.reviving, player.abilityCount])]);
  if (list.dataset.signature === signature) return;
  list.dataset.signature = signature;
  $("#partyCount").textContent = room.players.length + " / 4";
  list.replaceChildren();
  room.players.forEach((player) => {
    const item = document.createElement("div");
    item.className = "player-card" + (player.status !== "alive" ? " downed-card" : "");
    item.innerHTML = '<span class="player-dot"></span><span class="player-info"><b class="player-name"></b><small class="player-class"></small></span><span class="player-health"></span>';
    item.querySelector(".player-dot").style.background = player.color;
    item.querySelector(".player-name").textContent = player.name + (player.id === room.host ? " · host" : "");
    item.querySelector(".player-class").textContent = player.reviving ? "Reviving an ally…" : !player.class ? "Choosing class" : player.abilityCount === 3 ? player.class + " · ready" : player.class + " · abilities " + player.abilityCount + "/3";
    item.querySelector(".player-health").textContent = player.class ? (player.status === "alive" ? player.hp + "/" + player.maxHp + " HP" : player.status.toUpperCase()) : "";
    list.append(item);
  });
  const own = room.players.find((player) => player.id === room.you);
  const ready = room.players.length > 0 && room.players.every((player) => player.class && player.abilityCount === 3);
  const start = $("#startRun");
  start.disabled = room.you !== room.host || !ready || room.phase !== "lobby";
  start.textContent = room.phase !== "lobby" ? "Run in progress" : room.you !== room.host ? "Waiting for host" : ready ? "Begin the run" : own && own.class && own.abilityCount !== 3 ? "Choose one of each ability" : own && own.class ? "Waiting for party loadouts" : "Choose a class to begin";
}
function renderChat(room) {
  const signature = room.chat.map((message) => message.id).join("|");
  if (signature === lastChatSignature) return;
  lastChatSignature = signature;
  const box = $("#chatMessages");
  box.replaceChildren();
  room.chat.forEach((message) => {
    const line = document.createElement("div");
    line.className = message.player === "system" ? "chat-line system-line" : "chat-line";
    const author = document.createElement("b");
    author.textContent = message.name;
    const body = document.createElement("span");
    body.textContent = message.message;
    line.append(author, body);
    box.append(line);
  });
  box.scrollTop = box.scrollHeight;
}
function renderRoom(room) {
  updateMotionTracks(room);
  latestRoom = room;
  sendMovement(false);
  notice($("#roomNotice"), "");
  $("#connection").textContent = "SYNCED";
  $("#connection").className = "connection online";
  renderClasses(room);
  renderPlayers(room);
  renderAbilityBar(room);
  renderWorldToast(room);
  renderQuickPouch(room);
  renderUtilityHotbar(room);
  renderChat(room);
  const active = room.phase !== "lobby";
  document.body.classList.toggle("is-playing", active);
  $("#arenaPanel").classList.toggle("hidden", !active);
  $("#classPanel").classList.toggle("hidden", active);
  const regionLabel = ({ woodland: "Woodland", ruins: "Ruins", cavern: "Cavern", frost: "Frostlands" })[room.region] || "Gauntlet";
  const title = room.phase === "town" ? room.town :
    room.phase === "routes" ? "Stage " + room.stage + " · Fork in the road" :
    room.phase === "puzzle" ? "Stage " + room.stage + " · Rune chamber" :
    room.phase === "chest" ? "Stage " + room.stage + " · Treasure" :
    room.phase === "stage_exit" ? "Stage " + room.stage + " · Cleared" :
    room.phase === "defeat" ? "Stage " + room.stage + " · Defeat" :
    room.phase === "cleared" ? "The Gauntlet · Victory" :
    room.encounterType === "large_boss" ? room.encounterName :
    room.encounterType === "mini_boss" ? "Mini-Boss · " + room.encounterName :
    room.assassinationActive ? "Stage " + room.stage + " · ASSASSINATION ATTEMPT" :
    "Stage " + room.stage + " · " + regionLabel + " · Wave " + room.stageWave + " / " + room.stageWaves;
  $("#stageHeading").textContent = title;
  $("#runeCount").textContent = room.runes + " RUNES";
  const own = room.players.find((player) => player.id === room.you);
  $("#hpLabel").textContent = own ? "HP " + own.hp + " / " + own.maxHp : "HP";
  $("#hpFill").style.width = own && own.maxHp ? Math.max(0, Math.min(100, own.hp / own.maxHp * 100)) + "%" : "0%";
  $("#manaLabel").textContent = "MANA " + Math.floor(room.mana) + " / " + room.maxMana;
  $("#manaFill").style.width = Math.max(0, Math.min(100, room.mana / room.maxMana * 100)) + "%";
  $("#waveCountdown").classList.toggle("hidden", !room.waveCountdown || room.phase !== "combat");
  $("#waveCountdown").textContent = room.waveCountdown ? "WAVE " + room.stageWave + " IN " + room.waveCountdown : "";
  $(".hud-actions").classList.toggle("hidden", ["lobby", "defeat", "cleared"].includes(room.phase));
  $("#attackButton").classList.toggle("hidden", room.phase !== "combat");
  $("#attackButton").disabled = room.phase !== "combat" || Boolean(room.waveCountdown);
  $("#dashButton").classList.toggle("hidden", room.phase !== "combat");
  $("#dashButton").disabled = room.phase !== "combat" || Boolean(room.dashCooldown);
  $("#dashButton").textContent = room.dashCooldown ? "Dash · " + room.dashCooldown + "s" : "Space · Dash";
  $("#reviveButton").classList.toggle("hidden", room.phase !== "combat");
  const interactive = ["town", "puzzle", "chest"].includes(room.phase);
  $("#interactButton").classList.toggle("hidden", !interactive);
  if (room.phase === "chest") $("#interactButton").textContent = room.chestStatus === "nearby" ? "E · Open chest" : "Find the chest";
  else if (room.phase === "routes") $("#interactButton").textContent = room.nearRoute ? "E · Take " + room.nearRoute.name : "Find a path";
  else if (room.phase === "town") {
    if (room.townInterior) $("#interactButton").textContent = room.nearbyHouse ? "E · Return to town" : room.nearbyNpc ? "E · Talk to " + room.nearbyNpc.name : "Explore the building";
    else if (room.nearbyHouse) $("#interactButton").textContent = "E · Enter " + room.nearbyHouse.name;
    else if (room.nearbyNpc && room.nearbyNpc.id === "gate") $("#interactButton").textContent = (room.players.find((p) => p.id === room.you)?.townExitReady ? "E · Cancel exit vote" : "E · Vote to leave") + " · " + room.townExitVotes + "/" + room.townExitTotal;
    else if (room.nearbyNpc) $("#interactButton").textContent = "E · Talk to " + room.nearbyNpc.name;
    else $("#interactButton").textContent = "Explore town";
  }
  else if (room.phase === "puzzle") $("#interactButton").textContent = room.puzzle && room.puzzle.atTotem ? "E · Read totem" : "Find your totem";
  const townActive = room.phase === "town";
  const chestActive = room.phase === "chest";
  const defeatActive = room.phase === "defeat";
  const victoryActive = room.phase === "cleared";
  if (!chestActive) lastChestSignature = "";
  $("#townPanel").classList.toggle("hidden", !townActive || room.townInteraction !== "merchant");
  $("#chestPanel").classList.toggle("hidden", !chestActive || room.chestStatus !== "pending");
  $("#defeatPanel").classList.toggle("hidden", !defeatActive || !room.canResumeAtCheckpoint);
  $("#victoryPanel").classList.toggle("hidden", !victoryActive);
  if (townActive) renderTown(room);
  if (chestActive && room.chestStatus === "pending") renderChest(room);
  $("#checkpointResume").classList.toggle("hidden", !defeatActive || !room.canResumeAtCheckpoint || room.you !== room.host);
  const routeActive = room.phase === "routes";
  const puzzleActive = room.phase === "puzzle";
  $("#world").classList.remove("hidden");
  if (!puzzleActive) {
    clearTimeout(puzzleDialogueTimer);
    $("#puzzlePanel").classList.add("hidden");
    lastPuzzleId = "";
    lastPuzzleClue = "";
  }
  $(".arena-controls").classList.toggle("hidden", defeatActive || victoryActive);
  if (puzzleActive) renderPuzzle(room);
  if (room.phase === "combat") notice($("#combatNotice"), room.waveCountdown ? "Stay ready—enemies are rushing in from a random side." : "WASD to move · Space dash (5s) · Left click Light · " + String(keyBindings.special).toUpperCase() + " Special · " + String(keyBindings.ultimate).toUpperCase() + " Ultimate · " + String(keyBindings.revive).toUpperCase() + " revive");
  else if (room.phase === "routes") notice($("#combatNotice"), room.yourRouteVote ? "Waiting at the trail edge. Everyone must reach a left or right exit." : "Follow the fork left or right, then walk all the way to the screen edge to choose.");
  else if (room.phase === "stage_exit") notice($("#combatNotice"), "Stage cleared! Walk to the opening on the top edge. Party gathered: " + room.stageExitReady + " / " + room.players.length + ".");
  else if (room.phase === "chest") notice($("#combatNotice"), room.chestStatus === "nearby" ? "Press " + String(keyBindings.revive).toUpperCase() + " to open the chest." : "Walk to the chest in the center and press " + String(keyBindings.revive).toUpperCase() + ".");
  else if (room.phase === "town") notice($("#combatNotice"), room.townInterior ? (room.nearbyHouse ? "Press E at the door to return to the village." : room.nearbyNpc ? "Press E to talk to " + room.nearbyNpc.name + "." : "Find the shopkeeper inside, or return through the door.") : room.nearbyHouse ? "Press E to enter " + room.nearbyHouse.name + "." : room.nearbyNpc && room.nearbyNpc.id === "gate" ? "Gather at the exit and press E to vote. Everyone must be ready." : "Visit the Inn, Store, or Alchemy Lab. Gather at the south gate when everyone is ready to leave.");
  else if (room.phase === "puzzle") notice($("#combatNotice"), "Your party is in separate rune rooms. Find the totem clue, then stand on its matching rune.");
}
function updateMotionTracks(room) {
  const scene = [room.code, room.stage, room.phase, room.townInterior, room.puzzle?.id].join(":");
  const now = performance.now();
  if (scene !== motionScene) { motionTracks.clear(); lastSnapshotAt = 0; motionScene = scene; lastSentMove = ""; }
  const duration = lastSnapshotAt ? Math.max(50, Math.min(180, now - lastSnapshotAt)) : 100;
  const active = new Set();
  for (const [group, entities] of [["player", room.players], ["enemy", room.enemies], ["projectile", room.projectiles || []]]) {
    for (const entity of entities) {
      const key = group + ":" + entity.id;
      active.add(key);
      const previous = motionTracks.get(key);
      const position = previous ? interpolatedPosition(previous, now) : entity;
      const snap = !previous || Math.hypot(entity.x - position.x, entity.y - position.y) > 120;
      motionTracks.set(key, { x: snap ? entity.x : position.x, y: snap ? entity.y : position.y,
        targetX: entity.x, targetY: entity.y, start: now, duration });
    }
  }
  for (const key of motionTracks.keys()) if (!active.has(key)) motionTracks.delete(key);
  lastSnapshotAt = now;
}
function interpolatedPosition(track, now) {
  const fraction = Math.max(0, Math.min(1, (now - track.start) / track.duration));
  return { x: track.x + (track.targetX - track.x) * fraction, y: track.y + (track.targetY - track.y) * fraction };
}
function animateWorld(now) {
  if (latestRoom && latestRoom.phase !== "lobby" && !document.hidden) {
    const smooth = (group, entities) => entities.map((entity) => {
      const track = motionTracks.get(group + ":" + entity.id);
      return track ? { ...entity, ...interpolatedPosition(track, now) } : entity;
    });
    drawWorld({ ...latestRoom, players: smooth("player", latestRoom.players),
      enemies: smooth("enemy", latestRoom.enemies), projectiles: smooth("projectile", latestRoom.projectiles || []) });
  }
  requestAnimationFrame(animateWorld);
}
requestAnimationFrame(animateWorld);
function renderChest(room) {
  const signature = JSON.stringify([room.chestStatus, room.chestDecision, room.chestOpenedCount, room.chestTotal, room.chestReward, room.inventory, room.runes]);
  if (signature === lastChestSignature) return;
  lastChestSignature = signature;
  const pending = room.chestStatus === "pending";
  const done = room.chestStatus === "done";
  $("#pendingChestLoot").classList.toggle("hidden", !pending);
  $("#chestWait").classList.toggle("hidden", !done);
  $("#chestWait").textContent = "You opened your share. Waiting for the rest of the party.";
  $("#chestProgress").textContent = room.chestOpenedCount + " / " + room.chestTotal + " adventurers have opened their share.";
  if (!pending) return;
  $("#pendingChestName").textContent = room.chestReward.name + " · " + room.chestReward.rarity;
  $("#pendingChestDesc").textContent = room.chestReward.description;
  const choices = $("#chestSwapChoices");
  choices.replaceChildren();
  room.inventory.forEach((item) => {
    const button = document.createElement("button");
    button.className = "secondary";
    button.dataset.chestSwap = item.id;
    button.textContent = "Swap out " + item.name + " and sell for " + item.sell + " Runes";
    choices.append(button);
  });
}
function renderQuickPouch(room) {
  const pouch = $("#quickPouch");
  const gearPanel = $("#quickGear");
  const own = room.players.find((player) => player.id === room.you);
  if (room.privateNotice) { lastPrivateNotice = room.privateNotice; privateNoticeUntil = Date.now() + 6000; }
  const privateNotice = Date.now() < privateNoticeUntil ? lastPrivateNotice : "";
  const curseText = room.curse ? "CURSED · " + room.curse.name + " · " + room.curse.remainingStages + " combat/puzzle stages remain. " + room.curse.description + " Towns pause the timer." : privateNotice;
  const manaUsable = room.mana < room.maxMana;
  const signature = JSON.stringify([room.inventory, room.utilitySlots, room.toolSlots, room.phase, room.abilitySlots, own && own.hp, manaUsable, room.curse, curseText]);
  if (signature === pouch.dataset.signature) return;
  pouch.dataset.signature = signature;
  pouch.replaceChildren();
  $("#curseStatus").textContent = curseText;
  $("#curseStatus").classList.toggle("hidden", !curseText);
  $("#pouchPanel").classList.toggle("hidden", room.phase === "lobby");
  room.inventory.forEach((item) => {
    const row = document.createElement("div");
    row.className = "quick-item";
    const label = document.createElement("span");
    label.textContent = item.name + " · " + item.rarity;
    const controls = document.createElement("div");
    controls.className = "quick-item-actions";
    if (item.slot === "utility") {
      const use = document.createElement("button");
      use.className = "secondary"; use.dataset.useItem = item.id;
      use.textContent = item.kind === "hint" ? "Use" : "Use";
      use.disabled = !canUseUtility(room, item, own);
      controls.append(use);
      room.utilitySlots.forEach((equipped, index) => {
        const equip = document.createElement("button");
        equip.className = "secondary"; equip.dataset.equipItem = item.id; equip.dataset.equipSlot = String(index);
        equip.textContent = "U" + (index + 1);
        equip.title = "Equip in utility slot " + (index + 1);
        equip.disabled = Boolean(equipped && room.inventory.length >= 5);
        controls.append(equip);
      });
    } else if (item.slot === "tool") {
      room.toolSlots.forEach((equipped, index) => {
        const equip = document.createElement("button");
        equip.className = "secondary"; equip.dataset.equipItem = item.id; equip.dataset.equipSlot = String(index);
        equip.textContent = "T" + (index + 1);
        equip.title = "Equip in tool slot " + (index + 1);
        equip.disabled = Boolean(equipped && (equipped.kind !== item.kind || room.inventory.length >= 5));
        controls.append(equip);
      });
    }
    const description = document.createElement("p");
    description.className = "pouch-item-description";
    description.textContent = item.description || "";
    row.append(label, description, controls);
    pouch.append(row);
  });
  if (!room.inventory.length) pouch.textContent = "Pouch empty";
  gearPanel.replaceChildren();
  [["Utilities", room.utilitySlots, "utility"], ["Tools", room.toolSlots, "tool"]].forEach(([title, slots, slotKind]) => {
    slots.forEach((item, index) => {
      const slot = document.createElement("div");
      slot.className = "quick-gear-slot";
      const label = document.createElement("span");
      label.textContent = title + " " + (index + 1) + " · " + (item ? item.name : "Empty");
      slot.append(label);
      if (item) {
        const description = document.createElement("p");
        description.className = "pouch-item-description";
        description.textContent = item.description || "";
        slot.append(description);
        const remove = document.createElement("button");
        remove.className = "secondary"; remove.dataset.unequip = "1";
        remove.dataset.slotKind = slotKind; remove.dataset.slot = String(index);
        remove.textContent = "Unequip"; remove.disabled = room.inventory.length >= 5;
        slot.append(remove);
      }
      gearPanel.append(slot);
    });
  });
}
function canUseUtility(room, item, own) {
  if (!item || !own || own.status !== "alive") return false;
  if (item.kind === "hint") return room.phase === "routes";
  if (item.kind === "heal") return ["combat", "town"].includes(room.phase) && own.hp < own.maxHp;
  if (item.kind === "mana") return ["combat", "town"].includes(room.phase) && room.mana < room.maxMana;
  return ["ward", "buff", "speed", "arrows"].includes(item.kind) && room.phase === "combat";
}
function renderUtilityHotbar(room) {
  const hotbar = $("#utilityHotbar");
  const own = room.players.find((player) => player.id === room.you);
  const signature = JSON.stringify([room.utilitySlots, room.phase, own && own.status, own && own.hp, room.mana >= room.maxMana]);
  if (signature === hotbar.dataset.signature) return;
  hotbar.dataset.signature = signature;
  hotbar.replaceChildren();
  const icons = { heal: "✚", mana: "✦", ward: "⬡", hint: "⌕", buff: "⚔", speed: "➤", arrows: "➶" };
  room.utilitySlots.forEach((item, index) => {
    const button = document.createElement("button");
    button.className = "utility-slot";
    button.disabled = !item || !canUseUtility(room, item, own);
    if (item) {
      button.dataset.useItem = item.id;
      button.title = item.description;
      button.innerHTML = '<span class="utility-key"></span><span class="utility-icon"></span><span class="utility-name"></span>';
      button.querySelector(".utility-key").textContent = String(index + 1);
      button.querySelector(".utility-icon").textContent = icons[item.kind] || "✦";
      button.querySelector(".utility-name").textContent = item.name;
    } else {
      button.innerHTML = '<span class="utility-key"></span><span class="utility-name">Empty</span>';
      button.querySelector(".utility-key").textContent = String(index + 1);
    }
    hotbar.append(button);
  });
}
function renderRoutes(room) {
  const signature = JSON.stringify([room.routes, room.inventory, room.utilitySlots, room.yourRouteVote]);
  if (signature === lastRouteSignature) return;
  lastRouteSignature = signature;
  const choices = $("#routeChoices");
  choices.replaceChildren();
  const alreadyVoted = Boolean(room.yourRouteVote);
  room.routes.forEach((route) => {
    const button = document.createElement("button");
    button.className = "route-choice" + (room.yourRouteVote === route.id ? " selected" : "");
    button.dataset.route = route.id;
    button.disabled = alreadyVoted;
    const title = document.createElement("b");
    title.textContent = route.name;
    const kind = document.createElement("span");
    kind.textContent = route.easier ? "CLEAR ANSWER: EASIER PATH" : (route.kind === "puzzle" ? "Separated clue puzzle" : (route.kind === "town" ? "Peaceful town and inn checkpoint" : "Enemy gauntlet"));
    const votes = document.createElement("small");
    votes.textContent = route.votes + (route.votes === 1 ? " vote" : " votes");
    button.append(title, kind, votes);
    choices.append(button);
  });
  $("#routeNotice").textContent = alreadyVoted ? "Your vote is in. Waiting for the rest of the party…" : "Choose one path. The party proceeds when everyone has voted.";
  const lenses = $("#routeHintItems");
  lenses.replaceChildren();
  room.inventory.concat(room.utilitySlots.filter(Boolean)).filter((item) => item.kind === "hint").forEach((item) => {
    const button = document.createElement("button");
    button.className = "secondary route-lens-use";
    button.dataset.useRoute = item.id;
    button.textContent = "Use " + item.name + " to reveal the easier path";
    lenses.append(button);
  });
  if (!lenses.childElementCount) lenses.textContent = "A rare Pathfinder’s Lens can reveal which route is easier.";
}
function renderTown(room) {
  const signature = JSON.stringify([room.town, room.runes, room.inventory, room.utilitySlots, room.toolSlots, room.shopStock, room.you === room.host]);
  if (signature === lastTownSignature) return;
  lastTownSignature = signature;
  $("#townName").textContent = room.town + " · Inn & Market";
  const stock = $("#shopStock");
  stock.replaceChildren();
  room.shopStock.forEach((item) => {
    const card = document.createElement("div");
    card.className = "town-item";
    const details = document.createElement("div");
    details.innerHTML = '<b></b><small></small><span></span>';
    details.querySelector("b").textContent = item.name + " · " + item.rarity;
    details.querySelector("small").textContent = item.description;
    details.querySelector("span").textContent = item.price + " Runes";
    const buy = document.createElement("button");
    buy.className = "secondary";
    buy.dataset.buy = item.key;
    buy.textContent = "Buy";
    buy.disabled = room.runes < item.price || room.inventory.length >= 5;
    card.append(details, buy);
    stock.append(card);
  });
  if (!room.shopStock.length) stock.textContent = "The merchant is sold out.";
  const pouch = $("#pouchItems");
  const own = room.players.find((player) => player.id === room.you);
  pouch.replaceChildren();
  room.inventory.forEach((item) => {
    const card = document.createElement("div");
    card.className = "town-item";
    const details = document.createElement("div");
    details.innerHTML = '<b></b><small></small><span></span>';
    details.querySelector("b").textContent = item.name + " · " + item.rarity;
    details.querySelector("small").textContent = item.description;
    details.querySelector("span").textContent = "Sell for " + item.sell + " Runes";
    const controls = document.createElement("div");
    controls.className = "item-actions";
    const sell = document.createElement("button");
    sell.className = "secondary"; sell.dataset.sell = item.id; sell.textContent = "Sell";
    const use = document.createElement("button");
    use.className = "secondary"; use.dataset.use = item.id; use.textContent = item.kind === "hint" ? "Use at fork" : item.kind === "ward" ? "Use in combat" : "Use";
    use.disabled = item.kind !== "heal" || !own || own.hp >= own.maxHp;
    controls.append(sell, use);
    const slotCount = item.slot === "utility" ? 3 : 2;
    for (let slot = 0; slot < slotCount; slot += 1) {
      const equip = document.createElement("button");
      equip.className = "secondary"; equip.dataset.equipItem = item.id; equip.dataset.equipSlot = String(slot);
      equip.textContent = (item.slot === "utility" ? "Utility " : "Tool ") + (slot + 1);
      controls.append(equip);
    }
    card.append(details, controls);
    pouch.append(card);
  });
  if (!room.inventory.length) pouch.textContent = "Your pouch is empty.";
  const equipment = $("#equipmentSlots");
  equipment.replaceChildren();
  [["Utility slots", room.utilitySlots, "utility"], ["Tool slots", room.toolSlots, "tool"]].forEach(([title, slots, slotKind]) => {
    const group = document.createElement("div");
    group.className = "equipment-group";
    const heading = document.createElement("b");
    heading.textContent = title;
    group.append(heading);
    slots.forEach((item, index) => {
      const row = document.createElement("div");
      row.className = "equipment-slot";
      const label = document.createElement("span");
      label.textContent = (slotKind === "utility" ? "Utility " : "Tool ") + (index + 1) + ": " + (item ? item.name : "Empty");
      row.append(label);
      if (item) {
        const remove = document.createElement("button");
        remove.className = "secondary"; remove.dataset.unequip = "1";
        remove.dataset.slotKind = slotKind; remove.dataset.slot = String(index); remove.textContent = "Unequip";
        row.append(remove);
      }
      group.append(row);
    });
    equipment.append(group);
  });
}
function showPuzzleDialogue() {
  clearTimeout(puzzleDialogueTimer);
  $("#puzzlePanel").classList.remove("hidden");
  puzzleDialogueTimer = setTimeout(() => {
    $("#puzzlePanel").classList.add("hidden");
  }, 3000);
}
async function interactWithWorld() {
  await sendAction("interact");
  if (latestRoom?.phase === "puzzle" && latestRoom.puzzle?.atTotem) showPuzzleDialogue();
  refresh();
}
function renderPuzzle(room) {
  const puzzle = room.puzzle;
  if (!puzzle) return;
  if (puzzle.id !== lastPuzzleId) {
    lastPuzzleId = puzzle.id;
    lastPuzzleClue = "";
    showPuzzleDialogue();
  }
  if (puzzle.clue && puzzle.clue !== lastPuzzleClue) {
    lastPuzzleClue = puzzle.clue;
    showPuzzleDialogue();
  }
  const count = puzzle.partySize || room.players.length;
  $("#puzzlePath").textContent = "Rune chamber · " + count + " adventurer" + (count === 1 ? "" : "s");
  $("#puzzleClue").textContent = puzzle.clue || (puzzle.atTotem ? "The totem's inscription is unreadable." : "Find the scattered totem to learn which rune is yours.");
  $("#puzzleProgress").textContent = (puzzle.standingRune ? "Standing on " + puzzle.standingRune + (puzzle.isCorrect ? " · Your rune is correct!" : " · This may not be your rune.") : "Stand on the rune you believe matches the clue.") + " Party ready: " + puzzle.readyCount + " / " + count + ".";
  $("#puzzleNotice").textContent = "Each player sees only their own chamber and clue. Coordinate over party chat.";
}
function refresh() {
  if (polling || !session) return;
  polling = true;
  api("/api/state?room=" + encodeURIComponent(session.room) + "&player=" + encodeURIComponent(session.player))
    .then(renderRoom)
    .catch((error) => {
      if (error.message === "Room or player not found.") {
        session = null;
        latestRoom = null;
        localStorage.removeItem("gauntlet-session");
        $("#lobby").classList.add("hidden");
        $("#entry").classList.remove("hidden");
        document.body.classList.remove("is-playing");
        $("#connection").textContent = "READY";
        $("#connection").className = "connection";
        notice($("#entryNotice"), "That saved room has expired. Create a new room or join with a fresh code.");
        notice($("#roomNotice"), "");
        return;
      }
      $("#connection").textContent = "DISCONNECTED";
      $("#connection").className = "connection offline";
      notice($("#roomNotice"), error.message + " Return to the main menu to create or join a room.");
    })
    .finally(() => { polling = false; setTimeout(refresh, 100); });
}
function currentMovement() {
  let x = moveState.x, y = moveState.y;
  if (keys.has(String(keyBindings.left).toLowerCase()) || keys.has("arrowleft")) x -= 1;
  if (keys.has(String(keyBindings.right).toLowerCase()) || keys.has("arrowright")) x += 1;
  if (keys.has(String(keyBindings.up).toLowerCase()) || keys.has("arrowup")) y -= 1;
  if (keys.has(String(keyBindings.down).toLowerCase()) || keys.has("arrowdown")) y += 1;
  return { x: Math.max(-1, Math.min(1, x)), y: Math.max(-1, Math.min(1, y)), attack: moveState.attack || keys.has("attack") };
}
const keys = new Set();
function sendMovement(force) {
  if (!session || !latestRoom || !["combat", "town", "routes", "stage_exit", "puzzle", "chest"].includes(latestRoom.phase)) return;
  const now = performance.now();
  if (!force && now - lastInputSent < 90) return;
  const direction = currentMovement();
  const signature = direction.x + "," + direction.y + "," + direction.attack;
  if (!force && signature === lastSentMove) return;
  lastInputSent = now;
  lastSentMove = signature;
  sendAction("input", direction).catch(() => {});
}
window.addEventListener("keydown", (event) => {
  if (!event.key) return;
  const key = event.key.toLowerCase();
  if (bindingCapture) {
    event.preventDefault();
    if (/^[1-3]$/.test(key) || event.code === "Space") {
      notice($("#entryNotice"), "Space is reserved for dash; 1–3 are reserved for utilities.");
      return;
    }
    if ([...Object.entries(keyBindings)].some(([action, bound]) => action !== bindingCapture && String(bound).toLowerCase() === key)) {
      notice($("#entryNotice"), "Each action needs its own key. Choose another key.");
      return;
    }
    keyBindings[bindingCapture] = key;
    localStorage.setItem("gauntlet-keybindings", JSON.stringify(keyBindings));
    notice($("#entryNotice"), "Keybinding saved.");
    bindingCapture = null; renderKeyBindings();
    return;
  }
  if (event.target.closest("input,textarea,select")) return;
  if (/^[1-3]$/.test(key) || /^(Digit|Numpad)[1-3]$/.test(event.code)) {
    event.preventDefault();
    if (!event.repeat) triggerUtility(Number(/^(Digit|Numpad)[1-3]$/.test(event.code) ? event.code.slice(-1) : key) - 1);
    return;
  }
  if (event.code === "Space") {
    event.preventDefault();
    if (!event.repeat) triggerDash();
    return;
  }
  if (Object.values(keyBindings).some((bound) => String(bound).toLowerCase() === key) || ["arrowleft", "arrowright", "arrowup", "arrowdown"].includes(key)) event.preventDefault();
  if (key === String(keyBindings.special).toLowerCase()) { if (!event.repeat) triggerAbility("special"); return; }
  if (key === String(keyBindings.ultimate).toLowerCase()) { if (!event.repeat) triggerAbility("ultimate"); return; }
  if (key === String(keyBindings.revive).toLowerCase()) {
    if (!event.repeat) {
      if (latestRoom && latestRoom.phase === "combat") sendAction("revive").catch(() => {});
      else interactWithWorld().catch((error) => notice($("#combatNotice"), error.message));
    }
    return;
  }
  keys.add(key); sendMovement(true);
});
window.addEventListener("keyup", (event) => {
  if (!event.key) return;
  const key = event.key.toLowerCase();
  keys.delete(key);
  if (key === String(keyBindings.revive).toLowerCase() && latestRoom && latestRoom.phase === "combat") sendAction("stopRevive").catch(() => {});
  sendMovement(true);
});
window.addEventListener("blur", () => { keys.clear(); moveState = { x: 0, y: 0, attack: false }; sendAction("stopRevive").catch(() => {}); sendMovement(true); });
document.querySelectorAll("[data-move]").forEach((button) => {
  const vector = button.dataset.move.split(",").map(Number);
  const start = (event) => { event.preventDefault(); moveState = { x: vector[0], y: vector[1] }; sendMovement(true); };
  const stop = (event) => { event.preventDefault(); moveState = { x: 0, y: 0, attack: false }; sendMovement(true); };
  button.addEventListener("pointerdown", start);
  button.addEventListener("pointerup", stop);
  button.addEventListener("pointerleave", stop);
  button.addEventListener("pointercancel", stop);
});
function drawRegionScenery(ctx, room, theme, w, h) {
  let seed = 2166136261;
  const seedText = [room.code, room.stage, room.region].join(":");
  for (let i = 0; i < seedText.length; i++) seed = Math.imul(seed ^ seedText.charCodeAt(i), 16777619);
  const random = () => { seed += 0x6D2B79F5; let n = seed; n = Math.imul(n ^ n >>> 15, n | 1); n ^= n + Math.imul(n ^ n >>> 7, n | 61); return ((n ^ n >>> 14) >>> 0) / 4294967296; };
  const region = room.region || "woodland";
  for (let i = 0; i < (region === "ruins" ? 18 : 16); i++) {
    let x = 34 + random() * (w - 68), y = 34 + random() * (h - 68);
    if (y < 150 || y > h - 145) x = random() < 0.5 ? 48 + random() * 90 : w - 138 + random() * 90;
    const size = 10 + Math.floor(random() * 13);
    if (region === "woodland") {
      ctx.fillStyle = "#49382b"; ctx.fillRect(x - 4, y + 4, 9, size);
      ctx.fillStyle = i % 3 ? "#37654a" : "#4d7551";
      ctx.fillRect(x - size, y - size, size * 2, size);
      ctx.fillRect(x - size + 4, y - size - 6, size + 4, 9);
      ctx.fillStyle = "#729358"; ctx.fillRect(x - 6, y - size - 4, 5, 4);
    } else if (region === "ruins") {
      ctx.fillStyle = "#282d31"; ctx.fillRect(x - 9, y + size, 20, 5);
      ctx.fillStyle = i % 2 ? "#827d6c" : "#6f746f";
      ctx.fillRect(x - 7, y - size, 14, size * 2); ctx.fillRect(x - 12, y - size, 24, 6);
      ctx.fillStyle = "#a79b7d"; ctx.fillRect(x - 4, y - size + 5, 3, size - 2);
      if (i % 3 === 0) { ctx.fillStyle = "#575b52"; ctx.fillRect(x + 13, y + 11, 13, 7); ctx.fillRect(x + 18, y + 6, 8, 5); }
    } else if (region === "cavern") {
      ctx.fillStyle = "#1b2029"; ctx.fillRect(x - size, y + 5, size * 2, 8);
      ctx.fillStyle = i % 2 ? "#576471" : "#68727c";
      ctx.fillRect(x - size, y - 3, size * 2, 11); ctx.fillRect(x - size + 5, y - 8, size, 7);
      if (i % 3 === 0) { ctx.fillStyle = "#68c8cc"; ctx.fillRect(x + 5, y - 17, 4, 17); ctx.fillRect(x + 3, y - 9, 8, 3); }
    } else {
      ctx.fillStyle = "#45616d"; ctx.fillRect(x - 2, y, 5, size + 12);
      ctx.fillStyle = "#d3e2da"; ctx.fillRect(x - size, y - size, size * 2, size + 7);
      ctx.fillRect(x - size + 4, y - size - 7, size + 1, 10);
      ctx.fillStyle = "#9cb8be"; ctx.fillRect(x + 7, y + 10, size, 5);
    }
  }
  ctx.globalAlpha = 0.55;
  for (let i = 0; i < 62; i++) {
    const x = 22 + random() * (w - 44), y = 22 + random() * (h - 44);
    ctx.fillStyle = theme.detail; ctx.fillRect(Math.round(x), Math.round(y), 2 + Math.floor(random() * 3), 2);
  }
  ctx.globalAlpha = 1;
}
function renderWorldToast(room) {
  const toast = $("#worldToast");
  if (room.privateNotice) {
    lastPrivateNotice = room.privateNotice;
    privateNoticeUntil = Date.now() + 6500;
    toast.textContent = room.privateNotice;
  }
  const showing = Date.now() < privateNoticeUntil && Boolean(lastPrivateNotice);
  if (showing && !room.privateNotice) toast.textContent = lastPrivateNotice;
  toast.classList.toggle("hidden", !showing || room.phase === "lobby");
}
function drawPuzzleRoom(ctx, puzzle, w, h) {
  ctx.fillStyle = "#17152a"; ctx.fillRect(14, 14, w - 28, h - 28);
  ctx.strokeStyle = "#c3a7eb"; ctx.lineWidth = 9; ctx.strokeRect(20, 20, w - 40, h - 40);
  ctx.strokeStyle = "#78659a"; ctx.lineWidth = 3; ctx.setLineDash([10, 9]);
  ctx.strokeRect(34, 34, w - 68, h - 68); ctx.setLineDash([]);
  const glyphs = { SUN: "☼", MOON: "☾", LEAF: "❧", FLAME: "♨", WAVE: "≋", STAR: "✦" };
  const runeColors = { SUN: "#ffe27c", MOON: "#c4d8ff", LEAF: "#a7ed9c", FLAME: "#ff9a68", WAVE: "#83dcf4", STAR: "#f4eaff" };
  puzzle.runes.forEach((rune) => {
    const active = puzzle.standingRune === rune.rune;
    const color = runeColors[rune.rune] || "#eee";
    ctx.save(); ctx.shadowColor = active ? color : "#8973b8"; ctx.shadowBlur = active ? 18 : 8;
    ctx.fillStyle = active ? (puzzle.isCorrect ? "#526f48" : "#704742") : "#332b48";
    ctx.fillRect(rune.x - 39, rune.y - 33, 78, 66);
    ctx.strokeStyle = active ? (puzzle.isCorrect ? "#d5ed84" : "#ffae91") : "#a78dce";
    ctx.lineWidth = active ? 5 : 3; ctx.strokeRect(rune.x - 39, rune.y - 33, 78, 66);
    ctx.fillStyle = color; ctx.font = "bold 29px serif"; ctx.textAlign = "center";
    ctx.fillText(glyphs[rune.rune] || "✦", rune.x, rune.y + 5);
    ctx.restore();
    ctx.font = "bold 12px monospace"; ctx.fillStyle = "#fff4d5"; ctx.textAlign = "center";
    ctx.fillText(rune.rune, rune.x, rune.y + 49);
  });
  const totem = puzzle.totem;
  const sigilColor = runeColors[puzzle.targetSigil] || "#d6c5f0";
  ctx.save(); ctx.shadowColor = puzzle.atTotem ? sigilColor : "#aa8be3"; ctx.shadowBlur = puzzle.atTotem ? 22 : 12;
  ctx.fillStyle = "#211c30"; ctx.fillRect(totem.x - 34, totem.y - 36, 68, 72);
  ctx.strokeStyle = puzzle.atTotem ? sigilColor : "#c0a6e8"; ctx.lineWidth = 4; ctx.strokeRect(totem.x - 34, totem.y - 36, 68, 72);
  ctx.fillStyle = puzzle.atTotem ? "#413455" : "#352b49"; ctx.fillRect(totem.x - 25, totem.y - 27, 50, 54);
  ctx.fillStyle = puzzle.atTotem ? sigilColor : "#e7d8ff"; ctx.font = "bold 36px serif"; ctx.textAlign = "center";
  ctx.fillText(puzzle.targetSigil ? (glyphs[puzzle.targetSigil] || "✦") : "◇", totem.x, totem.y + 12);
  ctx.restore();
  ctx.fillStyle = "#fff1c8"; ctx.font = "bold 11px monospace"; ctx.textAlign = "center";
  ctx.fillText(puzzle.atTotem ? "TOTEM · " + puzzle.targetSigil : "TOTEM · FIND CLUE", totem.x, totem.y + 51);
}
function drawTownObjects(ctx, room, w, h) {
  ctx.fillStyle = "#35543b"; ctx.fillRect(0, 0, w, h);
  const houses = room.townHouses || [];
  for (const width of [44, 30]) {
    ctx.strokeStyle = width === 44 ? "#b38a4b" : "#e4c674"; ctx.lineWidth = width;
    ctx.lineJoin = "round";
    ctx.beginPath(); ctx.moveTo(480, 540); ctx.lineTo(480, 300); ctx.stroke();
    houses.forEach((house) => {
      ctx.beginPath(); ctx.moveTo(480, 300);
      if (house.y > 300) { ctx.lineTo(480, house.y + 47); ctx.lineTo(house.x, house.y + 47); }
      else { ctx.lineTo(house.x, 300); ctx.lineTo(house.x, house.y + 47); }
      ctx.stroke();
    });
  }
  ctx.fillStyle = "#72945d"; ctx.fillRect(52, 370, 130, 82); ctx.fillRect(785, 246, 108, 72);
  ctx.fillStyle = "#507a4a"; ctx.fillRect(58, 378, 118, 66); ctx.fillRect(791, 253, 96, 58);
  for (let i = 0; i < 12; i++) { ctx.fillStyle = i % 2 ? "#d88789" : "#f0d986"; ctx.fillRect(62 + (i % 6) * 18, 384 + Math.floor(i / 6) * 25, 5, 5); }
  // Garden hedges, fences, trees, and the village fountain.
  ctx.fillStyle = "#5b7a43"; [[40,170,12,116],[912,145,12,128],[70,476,180,10],[700,476,180,10]].forEach(([x,y,bw,bh]) => ctx.fillRect(x,y,bw,bh));
  [[80,112],[888,108],[84,425],[882,430],[548,132],[390,398],[602,420]].forEach(([x,y], i) => {
    ctx.fillStyle = "#69452f"; ctx.fillRect(x - 5, y + 4, 10, 25);
    ctx.fillStyle = i % 2 ? "#397b49" : "#438750"; ctx.fillRect(x - 22, y - 18, 44, 29); ctx.fillRect(x - 15, y - 30, 31, 17);
    ctx.fillStyle = "#71a65b"; ctx.fillRect(x - 9, y - 25, 13, 7);
  });
  const fountainX = room.townSeed % 2 ? 584 : 376;
  ctx.fillStyle = "#5b6260"; ctx.fillRect(fountainX - 44, 325, 88, 60); ctx.fillStyle = "#8c9382"; ctx.fillRect(fountainX - 38, 331, 76, 48);
  ctx.fillStyle = "#4da8bd"; ctx.fillRect(fountainX - 22, 344, 44, 28); ctx.fillStyle = "#b9dcda"; ctx.fillRect(fountainX - 26, 339, 51, 4);
  houses.forEach((house, index) => {
    const x = house.x, y = house.y, nearby = room.nearbyHouse && room.nearbyHouse.id === house.id;
    const roofs = ["#a94f3d", "#426f78", "#c56643", "#906451", "#b6773f"];
    // House shadow, stone foundation, timber walls, roof, windows, and door.
    ctx.fillStyle = "#18271c88"; ctx.fillRect(x - 68, y - 17, 140, 76);
    ctx.fillStyle = "#777465"; ctx.fillRect(x - 61, y - 30, 122, 73);
    ctx.fillStyle = index % 2 ? "#ead4a1" : "#e7c68b"; ctx.fillRect(x - 57, y - 47, 114, 83);
    ctx.fillStyle = "#67452e"; ctx.fillRect(x - 64, y - 53, 128, 12); ctx.fillRect(x - 62, y - 42, 8, 83); ctx.fillRect(x + 54, y - 42, 8, 83);
    ctx.fillStyle = house.roof || roofs[index % roofs.length]; ctx.fillRect(x - 70, y - 68, 140, 24); ctx.fillRect(x - 57, y - 77, 114, 13);
    ctx.fillStyle = "#eaa36a"; ctx.fillRect(x - 59, y - 45, 118, 4);
    ctx.fillStyle = "#6d9dab"; ctx.fillRect(x - 43, y - 23, 22, 19); ctx.fillRect(x + 21, y - 23, 22, 19);
    ctx.fillStyle = "#fff0c2"; ctx.fillRect(x - 34, y - 23, 3, 19); ctx.fillRect(x - 43, y - 15, 22, 3); ctx.fillRect(x + 30, y - 23, 3, 19); ctx.fillRect(x + 21, y - 15, 22, 3);
    ctx.fillStyle = "#633d32"; ctx.fillRect(x - 11, y + 2, 22, 35); ctx.fillStyle = "#e8c47b"; ctx.fillRect(x + 5, y + 19, 3, 3);
    ctx.fillStyle = "#f3e7c6"; ctx.font = "bold 9px monospace"; ctx.textAlign = "center"; ctx.fillText(house.name.toUpperCase(), x, y - 83);
    if (nearby) { ctx.strokeStyle = "#ffe389"; ctx.lineWidth = 2; ctx.strokeRect(x - 73, y - 80, 146, 137); ctx.fillStyle = "#fff0c8"; ctx.fillText("E · ENTER", x, y + 54); }
  });
  if (room.players.some((player) => player.townExitReady)) {
    ctx.fillStyle = "#fff0c8"; ctx.font = "bold 11px monospace"; ctx.textAlign = "center";
    ctx.fillText("READY " + room.townExitVotes + " / " + room.townExitTotal, 480, 524);
  }
  drawTownNpcs(ctx, room);
}
function drawTownNpcs(ctx, room) {
  const colors = { merchant: "#dfad62", alchemist: "#8ac8aa", innkeeper: "#c59478", gate: "#8bd2df" };
  const labels = { merchant: "MERCHANT", alchemist: "ALCHEMIST", innkeeper: "INNKEEPER", gate: "TRAIL GATE" };
  Object.entries(room.townNpcs || {}).forEach(([id, pos]) => {
    const x = pos.x, y = pos.y, color = colors[id] || "#e8d598";
    const nearby = room.nearbyNpc && room.nearbyNpc.id === id;
    if (id === "gate") {
      ctx.fillStyle = "#638c83"; ctx.fillRect(x - 48, y - 53, 13, 61); ctx.fillRect(x + 35, y - 53, 13, 61); ctx.fillRect(x - 48, y - 57, 96, 11);
      ctx.fillStyle = nearby ? "#ffe389" : "#c5ead3"; ctx.font = "10px monospace"; ctx.textAlign = "center"; ctx.fillText("EXIT · E TO VOTE", x, y - 39);
      return;
    }
    ctx.fillStyle = "#0e1720aa"; ctx.fillRect(x - 20, y + 14, 40, 8);
    ctx.fillStyle = "#24202a"; ctx.fillRect(x - 12, y - 15, 24, 33);
    ctx.fillStyle = color; ctx.fillRect(x - 10, y - 14, 20, 25);
    ctx.fillStyle = "#f1cda1"; ctx.fillRect(x - 8, y - 25, 16, 12);
    ctx.fillStyle = "#211a25"; ctx.fillRect(x - 9, y - 28, 18, 5); ctx.fillRect(x - 5, y - 31, 10, 4);
    ctx.fillStyle = "#28202a"; ctx.fillRect(x - 8, y + 10, 6, 8); ctx.fillRect(x + 2, y + 10, 6, 8);
    if (id === "merchant") { ctx.fillStyle = "#8c593d"; ctx.fillRect(x + 11, y - 4, 10, 14); ctx.fillStyle = "#ffd166"; ctx.fillRect(x + 13, y - 1, 4, 5); }
    if (id === "alchemist") { ctx.fillStyle = "#b3efcf"; ctx.fillRect(x + 10, y - 5, 8, 10); ctx.fillStyle = "#436f6d"; ctx.fillRect(x + 12, y - 9, 4, 4); }
    ctx.fillStyle = nearby ? "#ffe389" : "#f5e6c9"; ctx.font = "bold 10px monospace"; ctx.textAlign = "center";
    ctx.fillText((nearby ? "E · " : "") + labels[id], x, y + 34);
    if (nearby) { ctx.strokeStyle = "#ffe389"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y - 4, 27, 0, Math.PI * 2); ctx.stroke(); }
  });
}
function drawTownInterior(ctx, room, w, h) {
  ctx.fillStyle = "#805f42"; ctx.fillRect(0, 0, w, h);
  for (let y = 0; y < h; y += 28) { ctx.fillStyle = y % 56 ? "#916d4b" : "#9b7650"; ctx.fillRect(0, y, w, 26); ctx.fillStyle = "#634a37"; ctx.fillRect(0, y + 25, w, 3); }
  ctx.fillStyle = "#643e43"; ctx.fillRect(300, 176, 360, 225); ctx.fillStyle = "#b75c50"; ctx.fillRect(310, 186, 340, 205);
  ctx.fillStyle = "#e1bd74"; ctx.fillRect(332, 112, 82, 105); ctx.fillStyle = "#634932"; ctx.fillRect(342, 122, 62, 84);
  ctx.fillStyle = "#49706d"; ctx.fillRect(346, 126, 54, 36); ctx.fillStyle = "#c5a16c"; ctx.fillRect(346, 165, 54, 5);
  ctx.fillStyle = "#6d5039"; ctx.fillRect(590, 119, 127, 82); ctx.fillStyle = "#c7995e"; ctx.fillRect(598, 126, 111, 10); ctx.fillRect(598, 151, 111, 8); ctx.fillRect(598, 177, 111, 8);
  ctx.fillStyle = "#513a35"; ctx.fillRect(384, 272, 192, 82); ctx.fillStyle = "#dbb96f"; ctx.fillRect(394, 282, 172, 62);
  ctx.fillStyle = "#73513c"; ctx.fillRect(452, 428, 56, 112); ctx.fillStyle = "#d6b872"; ctx.fillRect(458, 435, 44, 90);
  const house = (room.townHouses || []).find((entry) => entry.id === room.townInterior);
  if (house?.service === "innkeeper") {
    [240, 660].forEach((x) => { ctx.fillStyle = "#51372b"; ctx.fillRect(x, 290, 92, 114); ctx.fillStyle = "#6d9494"; ctx.fillRect(x + 5, 310, 82, 86); ctx.fillStyle = "#f3e4ca"; ctx.fillRect(x + 7, 296, 78, 22); });
  } else if (house?.service === "alchemist") {
    ["#8bdac5", "#bb83ff", "#f2a456", "#85dcf2"].forEach((color, i) => { const x = 400 + i * 46; ctx.fillStyle = "#cfdfd1"; ctx.fillRect(x, 267, 8, 8); ctx.fillStyle = color; ctx.fillRect(x - 4, 275, 16, 16); });
    ctx.fillStyle = "#1c3037"; ctx.fillRect(258, 305, 76, 56); ctx.fillStyle = "#72da9c"; ctx.fillRect(264, 299, 64, 14);
  } else if (house?.service === "merchant") {
    [260, 666].forEach((x) => { ctx.fillStyle = "#563b2e"; ctx.fillRect(x, 285, 48, 52); ctx.fillStyle = "#e1bc6a"; ctx.fillRect(x + 3, 295, 42, 7); ctx.fillRect(x + 18, 285, 10, 52); });
  }
  drawTownNpcs(ctx, room);
  ctx.fillStyle = "#fff1c9"; ctx.font = "bold 12px monospace"; ctx.textAlign = "center"; ctx.fillText(house ? house.name.toUpperCase() : "PRIVATE HOUSE", 480, 80);
  ctx.fillText(room.nearbyHouse ? "E · RETURN TO TOWN" : "WALK TO THE DOOR", 480, 522);
}
function drawRouteGates(ctx, room) {
  ctx.fillStyle = "#243b30"; ctx.fillRect(0, 0, 960, 540);
  for (let x = 36; x < 960; x += 70) {
    ctx.fillStyle = "#193323"; ctx.fillRect(x - 18, 24, 36, 76); ctx.fillStyle = "#3b6242"; ctx.fillRect(x - 24, 10, 48, 40);
  }
  const paths = [[[480, 540], [480, 320], [260, 170], [0, 170]], [[480, 540], [480, 320], [700, 170], [960, 170]]];
  ctx.save(); ctx.lineJoin = "round";
  for (const width of [112, 92, 64]) {
    ctx.lineWidth = width; ctx.strokeStyle = width === 112 ? "#1a2e22" : width === 92 ? "#866a42" : "#c4a66b";
    paths.forEach((points) => { ctx.beginPath(); points.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)); ctx.stroke(); });
  }
  ctx.restore();
  ctx.fillStyle = "#704c33"; ctx.fillRect(473, 122, 14, 80); ctx.fillStyle = "#e4ca8b"; ctx.fillRect(375, 122, 210, 23); ctx.fillRect(375, 150, 210, 23);
  ctx.fillStyle = "#342d25"; ctx.font = "bold 12px monospace"; ctx.textAlign = "center";
  ctx.fillText("← " + (room.routes[0]?.name || "Left path"), 480, 138);
  ctx.fillText((room.routes[1]?.name || "Right path") + " →", 480, 166);
  (room.routes || []).forEach((route, index) => {
    const x = index === 0 ? 110 : 850, y = route.y;
    ctx.save(); ctx.globalAlpha = room.yourRouteVote === route.id ? 0.5 : 0.25; ctx.fillStyle = route.easier ? "#ffe68a" : "#a3e4c6";
    ctx.fillRect(index === 0 ? 0 : 918, y - 47, 42, 94); ctx.restore();
    ctx.fillStyle = "#fff0c8"; ctx.font = "bold 12px monospace"; ctx.textAlign = "center"; ctx.fillText(index === 0 ? "← " + route.name : route.name + " →", x, y - 63);
    ctx.font = "10px monospace"; ctx.fillText(route.votes + " / " + room.players.length + " at this edge", x, y + 69);
    if (route.easier) { ctx.fillStyle = "#ffe68a"; ctx.fillText("EASIER PATH", x, y + 85); }
  });
}
function drawStageExit(ctx, room) {
  ctx.fillStyle = "#c7ab75"; ctx.fillRect(390, 0, 180, 58);
  ctx.fillStyle = "#87d7bb"; ctx.fillRect(388, 0, 5, 60); ctx.fillRect(567, 0, 5, 60);
  ctx.fillStyle = "#fff0c8"; ctx.font = "bold 12px monospace"; ctx.textAlign = "center";
  ctx.fillText("↑ WALK OUT TO THE FORK", 480, 83);
  ctx.font = "10px monospace"; ctx.fillText(room.stageExitReady + " / " + room.players.length + " gathered", 480, 100);
}
function drawTreasureChest(ctx, chest) {
  const x = chest.x, y = chest.y, pulse = 0.68 + Math.sin(Date.now() / 200) * 0.16;
  ctx.save(); ctx.globalAlpha = pulse; ctx.fillStyle = "#ffcf63"; ctx.beginPath(); ctx.arc(x, y + 3, 35, 0, Math.PI * 2); ctx.fill(); ctx.restore();
  ctx.fillStyle = "#43272a"; ctx.fillRect(x - 25, y - 12, 50, 35);
  ctx.fillStyle = "#a24c32"; ctx.fillRect(x - 22, y - 9, 44, 28); ctx.fillRect(x - 25, y - 16, 50, 10);
  ctx.fillStyle = "#edb34e"; ctx.fillRect(x - 4, y - 12, 8, 27); ctx.fillRect(x - 21, y + 4, 42, 4);
  ctx.fillStyle = "#fff0c8"; ctx.font = "bold 11px monospace"; ctx.textAlign = "center"; ctx.fillText("TREASURE · E", x, y + 39);
}
function drawCombatEffects(ctx, room) {
  const now = Date.now();
  (room.projectiles || []).forEach((shot) => {
    ctx.save(); ctx.imageSmoothingEnabled = true; ctx.drawImage(enemyGlow(shot.color), shot.x - 16, shot.y - 16, 32, 32);
    ctx.imageSmoothingEnabled = false; ctx.fillStyle = shot.color;
    if (shot.class === "Archer") { ctx.translate(shot.x, shot.y); ctx.rotate(Math.atan2(shot.vy || 0, shot.vx || 1)); ctx.fillRect(-10, -2, 20, 4); ctx.fillRect(7, -4, 4, 8); }
    else if (["Knight", "Rogue"].includes(shot.class)) { ctx.beginPath(); ctx.arc(shot.x, shot.y, 6, 0, Math.PI * 2); ctx.fill(); }
    else { ctx.fillRect(shot.x - 5, shot.y - 5, 10, 10); ctx.fillRect(shot.x - 8, shot.y - 2, 16, 4); }
    ctx.restore();
  });
  (room.effects || []).forEach((effect) => {
    const remain = Math.max(0, Math.min(1, (effect.until * 1000 - now) / 800));
    if (!remain) return;
    ctx.save(); ctx.globalAlpha = remain; ctx.strokeStyle = effect.color || "#fff"; ctx.fillStyle = effect.color || "#fff"; ctx.lineWidth = 4;
    if (effect.type === "dash") {
      ctx.globalAlpha = remain * 0.6; ctx.lineWidth = 18; ctx.beginPath(); ctx.moveTo(effect.x, effect.y); ctx.lineTo(effect.targetX, effect.targetY); ctx.stroke();
      ctx.globalAlpha = remain; ctx.fillRect(effect.targetX - 7, effect.targetY - 7, 14, 14);
    } else if (effect.type === "slash" || effect.type === "cast" || effect.type === "enemy_attack") {
      const x = effect.targetX, y = effect.targetY, angle = Math.atan2(y - effect.y, x - effect.x);
      if (effect.type === "enemy_attack") { ctx.globalAlpha = remain * 0.45; ctx.strokeStyle = "#ff786b"; ctx.lineWidth = 3; ctx.setLineDash([7, 6]); ctx.beginPath(); ctx.moveTo(effect.x, effect.y); ctx.lineTo(x, y); ctx.stroke(); ctx.setLineDash([]); }
      ctx.translate(x, y); ctx.rotate(angle); ctx.beginPath(); ctx.arc(0, 0, 30, -0.8, 0.8); ctx.stroke();
      ctx.fillRect(-24, -3, 48, 6); ctx.fillRect(15, -8, 8, 16);
    } else if (effect.type === "impact" || effect.type === "burst" || effect.type === "heal" || effect.type === "aura") {
      const radius = 12 + (1 - remain) * (effect.type === "burst" ? 90 : 32);
      ctx.beginPath(); ctx.arc(effect.x, effect.y, radius, 0, Math.PI * 2); ctx.stroke();
      if (effect.type === "heal") { ctx.fillRect(effect.x - 3, effect.y - radius, 6, radius * 2); ctx.fillRect(effect.x - radius, effect.y - 3, radius * 2, 6); }
    }
    if (effect.text) { ctx.font = "bold 20px monospace"; ctx.textAlign = "center"; ctx.fillText(effect.text, effect.x, effect.y - 30); }
    ctx.restore();
  });
}
function drawArenaBackdrop(target, room, theme, w, h) {
  const key = [room.code, room.stage, room.region, w, h].join(":");
  if (key !== terrainKey) {
    terrainLayer.width = w; terrainLayer.height = h;
    const ctx = terrainLayer.getContext("2d");
  ctx.fillStyle = theme.base; ctx.fillRect(0, 0, w, h);
  for (let y = 0; y < h; y += 48) for (let x = 0; x < w; x += 48) {
    ctx.fillStyle = ((x / 48 + y / 48) % 2) ? theme.a : theme.b;
    ctx.fillRect(x, y, 46, 46);
    ctx.fillStyle = theme.detail; ctx.globalAlpha = 0.48; ctx.fillRect(x + 4, y + 5, 2, 2); ctx.globalAlpha = 1;
  }
  ctx.fillStyle = theme.trim;
  ctx.fillRect(0, 0, w, 14); ctx.fillRect(0, h - 14, w, 14);
  ctx.fillRect(0, 0, 14, h); ctx.fillRect(w - 14, 0, 14, h);
    drawRegionScenery(ctx, room, theme, w, h);
    terrainKey = key;
  }
  target.drawImage(terrainLayer, 0, 0);
}
function enemyGlow(color) {
  if (!glowLayers.has(color)) {
    const layer = document.createElement("canvas"); layer.width = layer.height = 128;
    const ctx = layer.getContext("2d");
    const gradient = ctx.createRadialGradient(64, 64, 10, 64, 64, 64);
    gradient.addColorStop(0, color + "88"); gradient.addColorStop(0.48, color + "55"); gradient.addColorStop(1, color + "00");
    ctx.fillStyle = gradient; ctx.fillRect(0, 0, 128, 128);
    glowLayers.set(color, layer);
  }
  return glowLayers.get(color);
}
function drawWorld(room) {
  const canvas = $("#world");
  if (!canvas || !room || room.phase === "lobby") return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width, h = canvas.height;
  const themes = {
    woodland: { base: "#243d32", a: "#294638", b: "#304d3c", detail: "#50724d", trim: "#4a4633" },
    ruins: { base: "#393b39", a: "#414440", b: "#494a43", detail: "#777465", trim: "#655b4b" },
    cavern: { base: "#242d3c", a: "#2b3545", b: "#313d4d", detail: "#56777b", trim: "#4b4e5c" },
    frost: { base: "#778d91", a: "#819a9d", b: "#8da6a5", detail: "#d4e4dc", trim: "#526f7d" }
  };
  const theme = themes[room.region] || themes.woodland;
  if (room.phase !== "town" && room.phase !== "routes") drawArenaBackdrop(ctx, room, theme, w, h);
  const ownTownInterior = room.phase === "town" && Boolean(room.townInterior);
  if (room.phase === "puzzle" && room.puzzle) drawPuzzleRoom(ctx, room.puzzle, w, h);
  if (room.phase === "town") {
    if (ownTownInterior) drawTownInterior(ctx, room, w, h);
    else drawTownObjects(ctx, room, w, h);
  }
  if (room.phase === "routes") drawRouteGates(ctx, room);
  if (room.phase === "stage_exit") drawStageExit(ctx, room);
  if (room.phase === "chest" && room.chest) drawTreasureChest(ctx, room.chest);
  (room.phase === "combat" ? room.enemies : []).forEach((enemy) => {
    const x = enemy.x, y = enemy.y, color = enemy.baseColor || "#85977a";
    const spriteScale = enemy.boss ? 2.5 : enemy.miniBoss ? 1.9 : 1.45;
    ctx.save(); ctx.imageSmoothingEnabled = true;
    const glowSize = 68 * spriteScale;
    ctx.drawImage(enemyGlow(enemy.color), x - glowSize / 2, y - 12 - glowSize / 2, glowSize, glowSize);
    ctx.restore();
    ctx.save(); ctx.globalAlpha = 0.2; ctx.fillStyle = enemy.color;
    ctx.beginPath(); ctx.ellipse(x, y + 12, 22 * spriteScale, 10 * spriteScale, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    ctx.save(); ctx.translate(x, y); ctx.scale(spriteScale, spriteScale); ctx.translate(-x, -y);
    const spriteKey = enemy.kind === "serpent" ? "Serpent" : enemy.kind === "minotaur" ? "Minotaur" : null;
    const imported = spriteKey && drawImportedHero(ctx, { ...enemy, status: "alive" }, x, y, spriteKey);
    if (!imported) {
    ctx.fillStyle = color;
    if (enemy.kind === "wolf") {
      ctx.fillRect(x - 9, y - 5, 20, 10); ctx.fillRect(x + 5, y - 10, 8, 9);
      ctx.fillRect(x + 8, y - 13, 3, 4); ctx.fillRect(x - 7, y + 4, 4, 5); ctx.fillRect(x + 5, y + 4, 4, 5);
    } else if (enemy.kind === "serpent") {
      ctx.fillRect(x - 7, y - 8, 14, 17); ctx.fillRect(x - 3, y - 13, 12, 9); ctx.fillRect(x - 1, y + 8, 8, 5);
    } else if (enemy.kind === "spider") {
      ctx.fillRect(x - 5, y - 6, 12, 12); ctx.fillRect(x - 13, y - 9, 8, 3); ctx.fillRect(x + 7, y - 9, 8, 3); ctx.fillRect(x - 14, y + 7, 9, 3); ctx.fillRect(x + 7, y + 7, 9, 3);
    } else if (enemy.kind === "dragon") {
      ctx.fillRect(x - 11, y - 5, 24, 15); ctx.fillRect(x + 8, y - 12, 13, 11);
      ctx.fillRect(x + 17, y - 8, 8, 5); ctx.fillRect(x + 13, y - 16, 3, 6); ctx.fillRect(x + 20, y - 15, 3, 6);
      ctx.fillRect(x - 5, y - 16, 7, 12); ctx.fillRect(x - 17, y - 20, 11, 15);
      ctx.fillRect(x + 1, y - 21, 12, 15); ctx.fillRect(x - 12, y + 10, 5, 8);
      ctx.fillRect(x + 5, y + 10, 5, 8); ctx.fillRect(x - 18, y + 5, 9, 4);
    } else {
      ctx.fillRect(x - 8, y - 7, 18, 18); ctx.fillRect(x - 4, y - 12, 12, 7); ctx.fillRect(x - 7, y + 10, 5, 4); ctx.fillRect(x + 3, y + 10, 5, 4);
    }
    const mobClassColor = room.classes[enemy.class] && room.classes[enemy.class].color || "#eee0b3";
    ctx.fillStyle = "#170f18"; ctx.fillRect(x - 4, y - 2, 3, 3); ctx.fillRect(x + 4, y - 2, 3, 3);
    ctx.fillStyle = mobClassColor;
    ctx.fillRect(x - 4, y - 2, 2, 2); ctx.fillRect(x + 4, y - 2, 2, 2);
    if (enemy.class === "Knight") {
      ctx.fillStyle = "#d1dbe1"; ctx.fillRect(x + 10, y - 8, 3, 22); ctx.fillStyle = "#b3894d"; ctx.fillRect(x + 8, y + 1, 7, 6);
    } else if (enemy.class === "Wizard" || enemy.class === "Druid") {
      ctx.fillStyle = mobClassColor; ctx.fillRect(x - 8, y - 18, 16, 4); ctx.fillRect(x - 4, y - 25, 9, 8);
      ctx.fillStyle = "#fff0a5"; ctx.fillRect(x + 12, y - 11, 3, 20); ctx.fillRect(x + 9, y - 14, 9, 4);
    } else if (enemy.class === "Archer") {
      ctx.strokeStyle = mobClassColor; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x + 12, y, 11, -1.25, 1.25); ctx.stroke();
      ctx.fillStyle = "#e6d1a0"; ctx.fillRect(x + 10, y - 2, 7, 2);
    } else if (enemy.class === "Rogue") {
      ctx.fillStyle = "#20202b"; ctx.fillRect(x - 8, y - 17, 16, 5); ctx.fillStyle = "#e7e8ec"; ctx.fillRect(x + 10, y - 1, 10, 3); ctx.fillRect(x + 17, y - 4, 3, 9);
    } else if (enemy.class === "Cleric" || enemy.class === "Healer") {
      ctx.fillStyle = mobClassColor; ctx.fillRect(x - 5, y - 21, 10, 3); ctx.fillRect(x - 1, y - 25, 3, 11);
      ctx.fillRect(x - 5, y - 19, 10, 3);
    } else if (enemy.class === "Bard") {
      ctx.fillStyle = mobClassColor; ctx.fillRect(x - 8, y - 17, 16, 4); ctx.fillRect(x + 11, y - 3, 9, 10);
      ctx.fillStyle = "#fff1c4"; ctx.fillRect(x + 14, y - 1, 2, 7);
    }
    }
    ctx.restore();
    const barWidth = enemy.boss ? 72 : enemy.miniBoss ? 56 : 40;
    const barY = enemy.boss ? y - 88 : enemy.miniBoss ? y - 68 : imported ? y - 50 : y - 32;
    ctx.fillStyle = "#211720"; ctx.fillRect(x - barWidth / 2, barY, barWidth, 4);
    ctx.fillStyle = enemy.boss ? "#f0c76c" : enemy.miniBoss ? "#d99159" : "#e66e68";
    ctx.fillRect(x - barWidth / 2 + 1, barY + 1, (barWidth - 2) * Math.max(0, enemy.hp) / enemy.maxHp, 2);
    ctx.fillStyle = "#eee2d2"; ctx.font = enemy.boss ? "bold 11px monospace" : "10px monospace"; ctx.textAlign = "center";
    ctx.fillText(enemy.affinity + " " + enemy.name, x, barY - 4);
  });
  const visiblePlayers = room.phase === "puzzle" || ownTownInterior ? room.players.filter((player) => player.id === room.you) : room.players.filter((player) => !player.indoors);
  visiblePlayers.forEach((player) => {
    if (room.phase === "combat" && player.id === room.you && player.status === "alive" && (arenaPointerActive || matchMedia("(pointer: coarse)").matches)) {
      const reach = Math.min(320, Math.max(50, room.attackRange || 150));
      ctx.save(); ctx.globalAlpha = 0.11; ctx.fillStyle = player.color;
      ctx.beginPath(); ctx.arc(player.x, player.y, reach, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = 0.35; ctx.strokeStyle = player.color; ctx.lineWidth = 2;
      ctx.setLineDash([7, 7]); ctx.beginPath(); ctx.arc(player.x, player.y, reach, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
    }
    ctx.globalAlpha = player.invisible ? 0.35 : 1;
    const x = player.x, y = player.y, color = player.color, role = player.class;
    const bob = Math.sin(Date.now() / 180 + x) * 1.2;
    const characterScale = room.phase === "town" ? 0.78 : 2;
    const nameOffset = room.phase === "town" ? 28 : heroSprites[role]?.sheet ? 72 : 37;
    ctx.fillStyle = "#15211a99"; ctx.fillRect(x - 11 * characterScale, y + 10 * characterScale, 22 * characterScale, 4 * characterScale);
    ctx.save(); ctx.translate(x, y + bob); ctx.scale(characterScale, characterScale); ctx.translate(-x, -y);
    if (!drawImportedHero(ctx, player, x, y)) {
    ctx.fillStyle = "#171722"; ctx.fillRect(x - 9, y - 12, 18, 25);
    ctx.fillStyle = role === "Rogue" ? "#46364f" : color; ctx.fillRect(x - 7, y - 10, 14, 17);
    ctx.fillStyle = "#fff0c9"; ctx.fillRect(x - 6, y - 9, 4, 11);
    ctx.fillStyle = "#382d32"; ctx.fillRect(x - 8, y + 6, 7, 9); ctx.fillRect(x + 1, y + 6, 7, 9);
    ctx.fillStyle = "#7b5142"; ctx.fillRect(x - 8, y + 12, 8, 3); ctx.fillRect(x + 1, y + 12, 8, 3);
    ctx.fillStyle = "#f0c49a"; ctx.fillRect(x - 6, y - 20, 12, 10);
    ctx.fillStyle = role === "Rogue" ? "#302637" : "#49343a"; ctx.fillRect(x - 7, y - 22, 14, 5);
    ctx.fillRect(x - 7, y - 18, 3, 5); ctx.fillRect(x + 4, y - 18, 3, 5);
    ctx.fillStyle = "#241f2b"; ctx.fillRect(x - 4, y - 16, 2, 2); ctx.fillRect(x + 2, y - 16, 2, 2);
    if (role === "Knight") {
      ctx.fillStyle = "#c5d0d2"; ctx.fillRect(x - 8, y - 22, 16, 6); ctx.fillRect(x - 5, y - 27, 10, 6);
      ctx.fillStyle = "#f2d87e"; ctx.fillRect(x - 2, y - 25, 4, 2);
      ctx.fillStyle = "#7595ac"; ctx.fillRect(x + 9, y - 6, 3, 20); ctx.fillRect(x + 7, y + 2, 7, 8);
      ctx.fillStyle = "#e1c978"; ctx.fillRect(x + 9, y + 4, 3, 4);
    } else if (role === "Wizard") {
      ctx.fillStyle = "#624a88"; ctx.fillRect(x - 9, y - 23, 18, 4); ctx.fillRect(x - 5, y - 34, 10, 12); ctx.fillRect(x - 8, y - 24, 16, 3);
      ctx.fillStyle = "#f2cc74"; ctx.fillRect(x - 2, y - 30, 4, 4);
      ctx.fillStyle = "#b8a0ed"; ctx.fillRect(x + 10, y - 17, 3, 31); ctx.fillStyle = "#d9c6ff"; ctx.fillRect(x + 7, y - 21, 9, 5);
    } else if (role === "Archer") {
      ctx.fillStyle = "#496e4d"; ctx.fillRect(x - 9, y - 22, 18, 5); ctx.fillRect(x - 6, y - 26, 12, 4);
      ctx.fillStyle = "#d9c38a"; ctx.fillRect(x + 10, y - 17, 2, 31); ctx.fillRect(x + 7, y - 18, 6, 3); ctx.fillRect(x + 7, y + 12, 6, 3);
    } else if (role === "Cleric") {
      ctx.fillStyle = "#eee0b3"; ctx.fillRect(x - 8, y - 22, 16, 5); ctx.fillRect(x - 5, y - 26, 10, 4); ctx.fillStyle = "#d3aa4f";
      ctx.fillRect(x - 2, y - 20, 4, 12); ctx.fillRect(x - 6, y - 16, 12, 4);
    } else if (role === "Rogue") {
      ctx.fillStyle = "#302637"; ctx.fillRect(x - 9, y - 22, 18, 7); ctx.fillRect(x - 7, y - 26, 14, 4);
      ctx.fillStyle = "#d4d0df"; ctx.fillRect(x + 10, y - 1, 3, 16); ctx.fillRect(x + 8, y - 3, 7, 3);
    } else if (role === "Druid") {
      ctx.fillStyle = "#594b39"; ctx.fillRect(x - 8, y - 24, 16, 5); ctx.fillRect(x - 4, y - 29, 8, 6);
      ctx.fillStyle = "#afd57d"; ctx.fillRect(x - 12, y - 27, 4, 8); ctx.fillRect(x + 8, y - 27, 4, 8); ctx.fillRect(x - 2, y - 33, 4, 6);
    } else if (role === "Bard") {
      ctx.fillStyle = "#b96492"; ctx.fillRect(x - 9, y - 23, 18, 4); ctx.fillRect(x - 3, y - 31, 8, 9); ctx.fillRect(x - 7, y - 24, 15, 3);
      ctx.fillStyle = "#e6ba77"; ctx.fillRect(x + 9, y - 7, 10, 10); ctx.fillRect(x + 12, y - 11, 4, 5); ctx.fillStyle = "#6b4d38"; ctx.fillRect(x + 10, y - 4, 8, 5);
    } else if (role === "Healer") {
      ctx.fillStyle = "#65b9b9"; ctx.fillRect(x - 8, y - 22, 16, 5); ctx.fillRect(x - 5, y - 26, 10, 4); ctx.fillStyle = "#f5ead8";
      ctx.fillRect(x + 10, y - 22, 3, 37); ctx.fillRect(x + 7, y - 24, 9, 4); ctx.fillRect(x + 10, y - 31, 3, 18);
    }
    }
    if (player.armorColor) { ctx.fillStyle = player.armorColor; ctx.fillRect(x - 8, y - 9, 16, 13); ctx.fillRect(x - 11, y - 7, 4, 10); ctx.fillStyle = "#ffffff55"; ctx.fillRect(x - 6, y - 8, 3, 8); }
    if (player.weaponColor) { ctx.fillStyle = "#171722"; ctx.fillRect(x + 10, y - 11, 5, 29); ctx.fillStyle = player.weaponColor; ctx.fillRect(x + 11, y - 12, 3, 28); ctx.fillRect(x + 8, y - 4, 9, 4); }
    if (player.summoned) { ctx.fillStyle = "#9bdb8c"; ctx.fillRect(x - 21, y + 2, 12, 9); ctx.fillRect(x - 23, y - 3, 6, 7); ctx.fillStyle = "#eff6bd"; ctx.fillRect(x - 21, y - 2, 2, 2); }
    ctx.restore();
    ctx.fillStyle = "#fff4d5"; ctx.font = room.phase === "town" ? "bold 9px monospace" : "bold 12px monospace"; ctx.textAlign = "center";
    ctx.fillText(player.name, x, y - nameOffset);
    if (player.status !== "alive") {
      ctx.fillStyle = "#ff8585"; ctx.fillText(player.status === "downed" ? "DOWN!" : "FALLEN", x, y + nameOffset);
    }
    ctx.globalAlpha = 1;
  });
  drawCombatEffects(ctx, room);
  if (room.phase === "cleared" || room.phase === "defeat") {
    ctx.fillStyle = room.phase === "defeat" ? "rgba(14, 8, 18, .82)" : "rgba(12, 20, 17, .72)";
    ctx.fillRect(0, 0, w, h);
    ctx.textAlign = "center"; ctx.fillStyle = room.phase === "defeat" ? "#e5857b" : "#f0d18a";
    ctx.font = "bold 32px monospace";
    ctx.fillText(room.phase === "defeat" ? "EVIL CLAIMS THE FIELD" : "THE DRAGON IS DEFEATED!", w / 2, h / 2);
  }
}
if (window.location.protocol === "file:") {
  $("#entry").classList.remove("hidden");
  $("#lobby").classList.add("hidden");
  document.body.classList.remove("is-playing");
  $("#connection").textContent = "OPEN SERVER PAGE";
  $("#connection").className = "connection connecting";
  notice($("#entryNotice"), "This file preview cannot reach multiplayer. Open the live server page instead.");
  $("#liveGameLink").classList.remove("hidden");
} else if (session) { enterLobby(); refresh(); }
