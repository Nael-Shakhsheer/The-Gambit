# Project instructions

Read `PROJECT_CONTEXT.md` and `README.md` before working on this project. They
carry the handoff context for The Gauntlet between computers and new chats.

- The user prefers ordinary implementation work to proceed without repeated
  approval requests. Ask for missing information only when it materially blocks
  the task, and flag concrete unsafe actions.
- Preserve the existing Python server and browser client architecture.
- `GAME_DESIGN.md` contains earlier planning. The latest user instructions and
  actual implementation take precedence over its outdated sections.
- Update `PROJECT_CONTEXT.md` when a change materially affects the game or its
  setup, so the next session can continue from the correct state.
- Use paths relative to this project in the application. The original home PC's
  drive letters and Python installation path must not become requirements.
- Run `python server.py` from the project folder and use the HTTP address in
  `README.md`. Opening `static/index.html` directly causes API connection errors.
- Rooms live in server memory. Restarting the server clears them. Static client
  and sprite changes normally need only a browser refresh; Python changes need
  a server restart.
