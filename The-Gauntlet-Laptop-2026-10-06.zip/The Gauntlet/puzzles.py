from __future__ import annotations

import random
import secrets

RUNES = ["SUN", "MOON", "LEAF", "FLAME", "WAVE", "STAR"]
HINTS = {
    "SUN": "Seek the golden rune that heralds the dawn.",
    "MOON": "Seek the silver rune that watches through the night.",
    "LEAF": "Seek the green rune of growing things.",
    "FLAME": "Seek the red rune that carries a living fire.",
    "WAVE": "Seek the blue rune that moves like water.",
    "STAR": "Seek the pale rune that shines far above the world.",
}


def new_puzzle(player_ids: list[str]) -> dict:
    rooms = {}
    for player_id in player_ids:
        positions = [(x, y) for y in (112, 226, 340, 426) for x in (125, 267, 409, 551, 693, 835)]
        random.shuffle(positions)
        options = [
            {"rune": rune, "x": positions[index][0], "y": positions[index][1]}
            for index, rune in enumerate(RUNES)
        ]
        target = random.choice(RUNES)
        free_spots = [(x, y) for y in (112, 226, 340, 426) for x in (125, 267, 409, 551, 693, 835)
                      if all((x - rune["x"]) ** 2 + (y - rune["y"]) ** 2 > 95 ** 2 for rune in options)]
        totem_x, totem_y = random.choice(free_spots)
        rooms[player_id] = {
            "runes": options,
            "target": target,
            "clue": HINTS[target],
            "totem": {"x": totem_x, "y": totem_y},
            "totemSeen": False,
            "wrongAt": 0,
            "standing": None,
        }
    return {"id": secrets.token_hex(4), "rooms": rooms}


def player_puzzle_view(puzzle: dict | None, player_id: str, position: tuple[float, float]) -> dict | None:
    if not puzzle or player_id not in puzzle["rooms"]:
        return None
    room = puzzle["rooms"][player_id]
    x, y = position
    at_totem = room["totemSeen"] or ((x - room["totem"]["x"]) ** 2 + (y - room["totem"]["y"]) ** 2 <= 48 ** 2)
    standing = next((rune["rune"] for rune in room["runes"]
                     if (x - rune["x"]) ** 2 + (y - rune["y"]) ** 2 <= 34 ** 2), None)
    return {
        "id": puzzle["id"],
        "runes": room["runes"],
        "totem": room["totem"],
        "clue": room["clue"] if at_totem else None,
        "targetSigil": room["target"] if at_totem else None,
        "atTotem": at_totem,
        "standingRune": standing,
        "isCorrect": standing == room["target"],
        "readyCount": sum(1 for pid, other in puzzle["rooms"].items() if other.get("standing") == other["target"]),
        "partySize": len(puzzle["rooms"]),
    }
