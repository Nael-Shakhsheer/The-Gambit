from __future__ import annotations

import math
import random
import secrets
import threading
import time
import copy
from puzzles import new_puzzle, player_puzzle_view

WIDTH = 960
HEIGHT = 540
MAX_PLAYERS = 4
CLASSES = {
    "Knight": {"role": "Melee tank", "hp": 150, "damage": 18, "speed": 145, "range": 120, "color": "#d9b76e"},
    "Wizard": {"role": "Ranged arcane damage", "hp": 100, "damage": 15, "speed": 145, "range": 250, "color": "#a68bff"},
    "Archer": {"role": "Fast piercing shots", "hp": 105, "damage": 13, "speed": 185, "range": 300, "color": "#8bd47b"},
    "Cleric": {"role": "Splash-potion support", "hp": 85, "damage": 9, "speed": 145, "range": 190, "color": "#ffe28a"},
    "Rogue": {"role": "Fast bleed damage", "hp": 80, "damage": 16, "speed": 205, "range": 125, "color": "#c68bd8"},
    "Druid": {"role": "Animal-summoning caster", "hp": 80, "damage": 12, "speed": 145, "range": 210, "color": "#6bc49b"},
    "Bard": {"role": "Team stat support", "hp": 75, "damage": 8, "speed": 145, "range": 185, "color": "#f095bf"},
    "Healer": {"role": "Strong healing and quick revives", "hp": 110, "damage": 6, "speed": 140, "range": 175, "color": "#85d9db"},
}
ABILITY_SETS = {
    "Knight": [
        ("shield_bash", "Shield Bash", "Strike and briefly stun the nearest foe.", "stun", 1.05, 155, 0.45, "light"),
        ("cleaving_arc", "Cleave", "A quick arc that hits nearby foes.", "area", 0.9, 125, 0.55, "light"),
        ("iron_wall", "Iron Wall", "Take half damage for 8 seconds.", "self_ward", 0.5, 0, 8, "special"),
        ("challenge", "Challenge", "Draw enemy attention for 7 seconds.", "taunt", 1, 0, 7, "special"),
        ("guardian_cry", "Last Stand", "Give the whole party a powerful ward.", "team_ward", 0.45, 0, 30, "ultimate"),
        ("earthshaker", "Earthshaker", "Smash the ground and damage every foe.", "area", 2.6, 260, 28, "ultimate"),
    ],
    "Wizard": [
        ("arc_burst", "Arc Bolt", "Fire a fast arcane projectile at the nearest foe.", "damage", 0.9, 285, 0.55, "light"),
        ("frost_lance", "Frost Lance", "Fire a quick freezing shard at a foe.", "stun", 1.0, 300, 0.5, "light"),
        ("spell_surge", "Spell Surge", "Increase your damage for 8 seconds.", "self_damage", 1.5, 0, 8, "special"),
        ("blink", "Blink", "Dash away from nearby danger.", "blink", 1, 180, 7, "special"),
        ("team_aegis", "Astral Aegis", "Protect the whole party with a strong ward.", "team_ward", 0.4, 0, 30, "ultimate"),
        ("arcane_cataclysm", "Arcane Cataclysm", "Unleash a huge blast across the arena.", "area", 3.0, 320, 28, "ultimate"),
    ],
    "Archer": [
        ("piercing_volley", "Quick Shot", "A fast arrow that pierces nearby foes.", "pierce", 0.8, 320, 0.4, "light"),
        ("snare_shot", "Snare Shot", "A quick arrow that briefly stuns.", "stun", 0.95, 300, 0.5, "light"),
        ("eagle_eye", "Eagle Eye", "Increase your damage for 8 seconds.", "self_damage", 1.55, 0, 8, "special"),
        ("quickstep", "Quickstep", "Move faster for 6 seconds.", "speed", 1.8, 0, 7, "special"),
        ("rain_of_arrows", "Rain of Arrows", "Strike every foe around your target.", "area", 2.4, 300, 29, "ultimate"),
        ("deadeye", "Deadeye", "A devastating shot at the nearest foe.", "damage", 4.0, 400, 28, "ultimate"),
    ],
    "Cleric": [
        ("radiant_flask", "Radiant Flask", "Throw a quick holy flask at the nearest foe.", "damage", 0.85, 250, 0.55, "light"),
        ("sanctified_throw", "Sanctified Throw", "A quick bolt of holy light.", "damage", 1.0, 250, 0.45, "light"),
        ("splash_mend", "Splash Mend", "Heal nearby allies.", "team_heal", 32, 240, 8, "special"),
        ("blessed_vial", "Blessed Vial", "Ward nearby allies for 7 seconds.", "team_ward", 0.6, 220, 8, "special"),
        ("sanctuary_rain", "Sanctuary Rain", "Restore health to the whole party.", "team_heal", 65, 0, 30, "ultimate"),
        ("cleansing_splash", "Cleansing Splash", "Revive a nearby fallen ally instantly.", "revive", 1, 240, 28, "ultimate"),
    ],
    "Rogue": [
        ("backstab", "Quick Cut", "A fast, bleeding strike against one foe.", "bleed", 1.0, 155, 0.38, "light"),
        ("fan_of_blades", "Fan of Blades", "A quick slash around you.", "area", 0.9, 140, 0.52, "light"),
        ("vanish", "Vanish", "Become untargetable for 5 seconds.", "invisible", 1, 0, 7, "special"),
        ("shadowstep", "Shadowstep", "Dash toward a foe and strike it.", "dash_strike", 1.8, 300, 8, "special"),
        ("death_bloom", "Death Bloom", "A storm of blades leaves every foe bleeding.", "area", 2.3, 280, 30, "ultimate"),
        ("execution", "Shadow Execution", "A devastating strike against the nearest foe.", "bleed", 4.0, 300, 27, "ultimate"),
    ],
    "Druid": [
        ("briar_burst", "Briar Burst", "A quick burst of thorns around you.", "area", 0.9, 155, 0.55, "light"),
        ("thornshot", "Thornshot", "A quick, focused thorn projectile.", "damage", 1.0, 280, 0.45, "light"),
        ("wolf_companion", "Wolf Companion", "Summon a spirit wolf to boost your damage.", "summon", 1.5, 0, 8, "special"),
        ("barkskin", "Barkskin", "Take half damage for 8 seconds.", "self_ward", 0.5, 0, 8, "special"),
        ("wild_mend", "Wild Mend", "Heal the whole party with primal magic.", "team_heal", 55, 0, 28, "ultimate"),
        ("primal_bloom", "Primal Bloom", "Thorns erupt beneath every enemy.", "area", 2.8, 330, 30, "ultimate"),
    ],
    "Bard": [
        ("discord_note", "Discord Note", "A quick sound burst around your target.", "area", 0.85, 200, 0.55, "light"),
        ("quickstring", "Quickstring", "Fire a quick piercing note at one foe.", "damage", 1.0, 250, 0.45, "light"),
        ("battle_anthem", "Battle Anthem", "Raise the party's damage for 8 seconds.", "team_damage", 1.3, 0, 8, "special"),
        ("fleet_rhythm", "Fleet Rhythm", "Give the party a short speed boost.", "team_speed", 1.5, 0, 8, "special"),
        ("grand_crescendo", "Grand Crescendo", "Raise every ally's damage dramatically.", "team_damage", 1.75, 0, 30, "ultimate"),
        ("rallying_chord", "Finale of Heroes", "Restore health to the whole party.", "team_heal", 65, 0, 28, "ultimate"),
    ],
    "Healer": [
        ("life_spark", "Life Spark", "A quick spark of light harms the nearest foe.", "damage", 0.9, 240, 0.5, "light"),
        ("healing_ray", "Gentle Mend", "Restore a little health to the most injured ally.", "team_heal", 12, 320, 0.8, "light"),
        ("major_mend", "Major Mend", "Heal the most injured nearby ally.", "team_heal", 55, 0, 8, "special"),
        ("quick_revival", "Quick Revival", "Instantly revive the nearest downed ally.", "revive", 1, 300, 7, "special"),
        ("miracle", "Miracle", "Restore a great amount of health to the party.", "team_heal", 90, 0, 30, "ultimate"),
        ("mass_revival", "Mass Revival", "Revive every fallen ally in the party.", "team_revive", 1, 0, 32, "ultimate"),
    ],
}
def ability_record(ability: tuple) -> dict:
    ability_id, name, description, kind, power, reach, cooldown, attack_type = ability
    return {"id": ability_id, "name": name, "description": description, "kind": kind,
            "power": power, "range": reach, "cooldown": cooldown,
            "attackType": attack_type,
            "manaCost": 0 if attack_type == "light" else 10 + round(cooldown * 1.5)}


ENEMIES = [
    ("Serpent Guard", "serpent", 46, 7, "#a9c65c"),
    ("Minotaur", "minotaur", 76, 11, "#b87b52"),
    ("Wolf", "wolf", 38, 8, "#aba8b6"),
    ("Cave Spider", "spider", 32, 6, "#9b83b1"),
    ("Cave Troll", "troll", 90, 12, "#7da48a"),
]
LARGE_BOSSES = [
    {"name": "Serpent Matriarch", "kind": "serpent", "affinity": "Poison", "hp": 620, "damage": 16},
    {"name": "Labyrinth Minotaur King", "kind": "minotaur", "affinity": "Storm", "hp": 820, "damage": 19},
    {"name": "Ancient Stone Behemoth", "kind": "troll", "affinity": "Nature", "hp": 980, "damage": 21},
    {"name": "Chimera", "kind": "monster", "affinity": "Arcane", "hp": 760, "damage": 18},
    {"name": "Great Wolf Guardian", "kind": "wolf", "affinity": "Ice", "hp": 680, "damage": 17},
]
DRAGON_TYPES = [
    {"name": "Fire Dragon", "affinity": "Fire", "hp": 1040, "damage": 22},
    {"name": "Ice Dragon", "affinity": "Ice", "hp": 1080, "damage": 20},
    {"name": "Dark Magic Dragon", "affinity": "Dark", "hp": 1120, "damage": 21},
    {"name": "Arcane Dragon", "affinity": "Arcane", "hp": 980, "damage": 23},
    {"name": "Storm Dragon", "affinity": "Storm", "hp": 1020, "damage": 22},
]
AFFINITIES = {
    "Fire": "#f47745",
    "Ice": "#85dcf2",
    "Dark": "#79618e",
    "Arcane": "#bb83ff",
    "Poison": "#92d64f",
    "Storm": "#e9dd72",
    "Nature": "#64c78d",
}
TOWNS = ["Mossgate", "Bellweather", "Hearthrest", "Silverbrook", "Rookhaven"]
TOWN_GATE = (480, 490)
TOWN_SERVICE_POSITION = (480, 220)
ROUTE_GATES = ((28, 170), (WIDTH - 28, 170))
FORK_PATHS = (((480, 540), (480, 320), (260, 170), (0, 170)),
              ((480, 540), (480, 320), (700, 170), (960, 170)))
PUZZLE_RUNS = (("one", 65), ("two", 30), ("three", 5))
ITEMS = {
    "healing_draught": {"name": "Healing Draught", "rarity": "Common", "price": 8, "sell": 4, "kind": "heal", "slot": "utility", "description": "Restore 40 HP."},
    "warding_tonic": {"name": "Warding Tonic", "rarity": "Uncommon", "price": 12, "sell": 6, "kind": "ward", "slot": "utility", "description": "Take 40% less damage for 30 seconds."},
    "mana_draught": {"name": "Mana Draught", "rarity": "Uncommon", "price": 14, "sell": 7, "kind": "mana", "slot": "utility", "mana": 50, "description": "Restore 50 mana."},
    "quickstep_elixir": {"name": "Quickstep Elixir", "rarity": "Uncommon", "price": 14, "sell": 7, "kind": "speed", "slot": "utility", "factor": 1.45, "duration": 10, "description": "Move 45% faster for 10 seconds."},
    "route_lens": {"name": "Pathfinder's Lens", "rarity": "Rare", "price": 18, "sell": 9, "kind": "hint", "slot": "utility", "description": "Reveal the easier path at the next fork. One use."},
    "ember_oil": {"name": "Ember Oil", "rarity": "Rare", "price": 25, "sell": 12, "kind": "buff", "slot": "utility", "factor": 1.4, "duration": 12, "description": "Deal 40% more damage for 12 seconds."},
    "piercing_arrows": {"name": "Piercing Arrows", "rarity": "Rare", "price": 24, "sell": 12, "kind": "arrows", "slot": "utility", "attacks": 5, "factor": 1.5, "description": "Empower your next 5 basic attacks."},
    "phoenix_flask": {"name": "Phoenix Flask", "rarity": "Epic", "price": 40, "sell": 20, "kind": "heal", "slot": "utility", "heal": 75, "description": "Restore 75 HP."},
    "stormguard_charm": {"name": "Stormguard Charm", "rarity": "Epic", "price": 42, "sell": 21, "kind": "ward", "slot": "utility", "factor": 0.35, "duration": 22, "description": "Take 65% less damage for 22 seconds."},
    "iron_sword": {"name": "Iron Sword", "rarity": "Common", "price": 22, "sell": 11, "kind": "weapon", "slot": "tool", "damage": 6, "color": "#d8d4c9", "description": "A sturdy blade adds 6 damage to attacks."},
    "oakguard_vest": {"name": "Oakguard Vest", "rarity": "Uncommon", "price": 20, "sell": 10, "kind": "armor", "slot": "tool", "armor": 3, "color": "#8a9d61", "description": "Woven bark armor blocks 3 damage per hit."},
    "moonsteel_sword": {"name": "Moonsteel Sword", "rarity": "Rare", "price": 34, "sell": 17, "kind": "weapon", "slot": "tool", "damage": 10, "color": "#b9d7e8", "description": "A moon-forged blade adds 10 damage to attacks."},
    "dragonbone_armor": {"name": "Dragonbone Armor", "rarity": "Epic", "price": 48, "sell": 24, "kind": "armor", "slot": "tool", "armor": 6, "color": "#df9b65", "description": "Dragonbone plates block 6 damage per hit."},
    "starfall_blade": {"name": "Starfall Blade", "rarity": "Legendary", "price": 80, "sell": 40, "kind": "weapon", "slot": "tool", "damage": 18, "color": "#f4d98c", "description": "A legendary blade adds 18 damage to attacks."},
    "aegis_of_dawn": {"name": "Aegis of Dawn", "rarity": "Legendary", "price": 76, "sell": 38, "kind": "armor", "slot": "tool", "armor": 10, "color": "#92d9d1", "description": "A radiant cuirass blocks 10 damage per hit."},
    "sage_wand": {"name": "Sage's Wand", "rarity": "Common", "price": 25, "sell": 12, "kind": "weapon", "slot": "tool", "damage": 6, "color": "#9d83ef", "description": "A crystal focus adds 6 damage to spells."},
    "wind_bow": {"name": "Wind Bow", "rarity": "Common", "price": 25, "sell": 12, "kind": "weapon", "slot": "tool", "damage": 6, "color": "#90cb77", "description": "A springy bow adds 6 damage to arrows."},
    "sun_censer": {"name": "Sun Censer", "rarity": "Common", "price": 25, "sell": 12, "kind": "weapon", "slot": "tool", "damage": 5, "color": "#e8ca74", "description": "A radiant censer adds 5 damage to holy flasks."},
    "shadow_blades": {"name": "Shadow Blades", "rarity": "Common", "price": 25, "sell": 12, "kind": "weapon", "slot": "tool", "damage": 7, "color": "#b898d5", "description": "Twin knives add 7 damage to quick strikes."},
    "thorn_staff": {"name": "Thorn Staff", "rarity": "Common", "price": 25, "sell": 12, "kind": "weapon", "slot": "tool", "damage": 6, "color": "#77bf82", "description": "A living branch adds 6 damage to nature magic."},
    "travel_lute": {"name": "Travel Lute", "rarity": "Common", "price": 25, "sell": 12, "kind": "weapon", "slot": "tool", "damage": 5, "color": "#df9dbd", "description": "A finely tuned lute adds 5 damage to sonic attacks."},
    "mercy_rod": {"name": "Mercy Rod", "rarity": "Common", "price": 25, "sell": 12, "kind": "weapon", "slot": "tool", "damage": 4, "color": "#8ce0db", "description": "A healing rod adds 4 damage to light attacks."},
}
CLASS_WEAPONS = {"Knight": "iron_sword", "Wizard": "sage_wand", "Archer": "wind_bow", "Cleric": "sun_censer",
                 "Rogue": "shadow_blades", "Druid": "thorn_staff", "Bard": "travel_lute", "Healer": "mercy_rod"}
LOOT_RARITIES = (("Common", 48), ("Uncommon", 27), ("Rare", 16), ("Epic", 7), ("Legendary", 2))
CURSES = [
    {"name": "Ashen Shackles", "description": "Movement speed is reduced by 25%.", "effect": "sluggish"},
    {"name": "Hollow Edge", "description": "You deal 25% less attack damage.", "effect": "weakened"},
    {"name": "Brittle Oath", "description": "You take 25% more damage from enemies.", "effect": "frail"},
]


class GameWorld:
    def __init__(self) -> None:
        self.rooms: dict[str, dict] = {}
        self.lock = threading.RLock()

    def _new_code(self) -> str:
        alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        while True:
            code = "".join(secrets.choice(alphabet) for _ in range(5))
            if code not in self.rooms:
                return code

    @staticmethod
    def _player(player_id: str, name: str) -> dict:
        return {
            "id": player_id, "name": name, "class": None, "hp": 100, "maxHp": 100,
            "mana": 100, "maxMana": 100, "lastManaTick": time.monotonic(),
            "x": 480, "y": 300, "dx": 0, "dy": 0, "status": "alive",
            "facingX": 1, "facingY": 0, "dashCooldownUntil": 0,
            "downedUntil": 0, "lastAttack": 0, "lastMove": time.monotonic(), "attacking": False, "reviving": None, "reviveStarted": 0,
            "inventory": [], "wardUntil": 0, "wardFactor": 1.0,
            "abilities": [], "abilityCooldowns": {}, "utilitySlots": [None, None, None], "toolSlots": [None, None],
            "weapon": None, "armor": None,
            "damageBoostUntil": 0, "damageBoost": 1, "speedBoostUntil": 0, "speedBoost": 1,
            "invisibleUntil": 0, "tauntUntil": 0, "summonUntil": 0,
            "specialAttacks": 0, "specialAttackFactor": 1,
            "curse": None, "chestReward": None, "shopStock": [], "townInteraction": None,
            "townInterior": None, "townReturn": None, "townExitReady": False,
        }

    def create_room(self, name: str) -> tuple[str, str]:
        with self.lock:
            code = self._new_code()
            player_id = secrets.token_urlsafe(9)
            room = {
                "code": code, "host": player_id, "phase": "lobby", "stage": 0, "region": "woodland",
                "players": {}, "enemies": [], "chat": [], "runes": 0,
                "wave": 0, "created": time.time(), "messageId": 0, "puzzle": None, "strainMistakes": 0,
                "routes": [], "routeVotes": {}, "routePressure": 0, "routeEffect": None,
                "revealedRoute": None, "town": None, "shopStock": {}, "checkpoint": None,
                "bossSequence": [], "bossesDefeated": 0, "miniBossesSinceBoss": 0,
                "miniBossesRequired": 0, "regularWavesSinceMiniBoss": 0,
                "regularWavesRequired": 0, "encounterType": "normal", "encounterName": "",
                "chest": None, "effects": [], "projectiles": [], "stageWave": 1, "stageWaves": 3,
                "waveStartsAt": 0,
                "miniBossStages": [], "bossStages": [8, 16, 25], "puzzlesRequired": 1,
                "puzzlesCompleted": 0, "puzzleStages": [], "townsTarget": 0, "townsVisited": 0, "townStages": [],
            }
            room["players"][player_id] = self._player(player_id, name or "Player")
            self.rooms[code] = room
            return code, player_id

    def join_room(self, code: str, name: str) -> tuple[str, str | None]:
        with self.lock:
            room = self.rooms.get(code.upper())
            if not room:
                raise ValueError("That room code was not found.")
            if room["phase"] != "lobby":
                raise ValueError("This run has already started.")
            if len(room["players"]) >= MAX_PLAYERS:
                raise ValueError("This room is full.")
            player_id = secrets.token_urlsafe(9)
            room["players"][player_id] = self._player(player_id, name or "Player")
            return code.upper(), player_id

    def state(self, code: str, player_id: str) -> dict:
        with self.lock:
            room = self.rooms.get(code.upper())
            if not room or player_id not in room["players"]:
                raise ValueError("Room or player not found.")
            players = []
            for player in room["players"].values():
                class_data = CLASSES.get(player["class"], {})
                players.append({
                    "id": player["id"], "name": player["name"], "class": player["class"],
                    "hp": player["hp"], "maxHp": player["maxHp"], "x": round(player["x"], 1),
                    "y": round(player["y"], 1), "status": player["status"], "reviving": bool(player.get("reviving")),
                    "color": class_data.get("color", "#e7e2d8"),
                    "role": class_data.get("role", "Choose a class"),
                    "weaponColor": (player.get("weapon") or {}).get("color"),
                    "armorColor": (player.get("armor") or {}).get("color"),
                    "facingX": player.get("facingX", 0), "facingY": player.get("facingY", 1),
                    "moving": bool(player.get("dx", 0) or player.get("dy", 0)),
                    "animation": player.get("animation", "idle"),
                    "animationUntil": player.get("animationUntil", 0),
                "abilityCount": len(player["abilities"]),
                    "summoned": player["summonUntil"] > time.monotonic(),
                    "invisible": player["invisibleUntil"] > time.monotonic(),
                    "indoors": bool(player.get("townInterior")),
                    "townExitReady": bool(player.get("townExitReady")),
                })
            return {
                "code": room["code"], "host": room["host"], "you": player_id,
                "phase": room["phase"], "stage": room["stage"], "wave": room["wave"], "region": room.get("region", "woodland"),
                "bossesDefeated": room["bossesDefeated"], "bossesTotal": 3,
                "attackRange": CLASSES.get(room["players"][player_id]["class"], {}).get("range", 0),
                "miniBossesDefeated": room["miniBossesSinceBoss"],
                "miniBossesRequired": room["miniBossesRequired"], "encounterType": room["encounterType"],
                "encounterName": room["encounterName"],
                "chestStatus": ("pending" if room["phase"] == "chest" and room["players"][player_id]["chestReward"] else
                                "done" if room["phase"] == "chest" and player_id in room["chest"]["decisions"] else
                                "nearby" if room["phase"] == "chest" and room["chest"] and math.hypot(room["players"][player_id]["x"] - room["chest"]["x"], room["players"][player_id]["y"] - room["chest"]["y"]) <= 62 else
                                "unopened" if room["phase"] == "chest" else None),
                "chestDecision": room["chest"]["decisions"].get(player_id) if room["phase"] == "chest" and room["chest"] else None,
                "chestOpenedCount": len(room["chest"]["decisions"]) if room["chest"] else 0,
                "chestTotal": len(room["players"]) if room["phase"] == "chest" else 0,
                "chestReward": dict(room["players"][player_id]["chestReward"]) if room["players"][player_id]["chestReward"] else None,
                "curse": dict(room["players"][player_id]["curse"]) if room["players"][player_id]["curse"] else None,
                "privateNotice": room.get("privateNotices", {}).pop(player_id, ""),
                "runes": room["runes"], "players": players, "classes": CLASSES,
                "mana": round(room["players"][player_id]["mana"], 1),
                "maxMana": room["players"][player_id]["maxMana"],
                "dashCooldown": max(0, math.ceil(room["players"][player_id].get("dashCooldownUntil", 0) - time.monotonic())),
                "enemies": [
                    {k: enemy[k] for k in ("id", "name", "kind", "affinity", "color", "x", "y", "hp", "maxHp")}
                    | {"boss": enemy.get("boss", False), "miniBoss": enemy.get("miniBoss", False), "class": enemy.get("class", "Knight"),
                       "baseColor": enemy.get("baseColor", "#85977a"), "facingX": enemy.get("facingX", 0),
                       "facingY": enemy.get("facingY", 1), "moving": enemy.get("moving", False),
                       "animation": "light", "animationUntil": enemy.get("animationUntil", 0)}
                    for enemy in room["enemies"]
                ],
                "chat": room["chat"][-40:], "puzzle": player_puzzle_view(room["puzzle"], player_id,
                    (room["players"][player_id]["x"], room["players"][player_id]["y"])),
                "effects": [dict(effect) for effect in room["effects"]],
                "projectiles": [dict(projectile) for projectile in room["projectiles"]],
                "stageWave": room["stageWave"], "stageWaves": room["stageWaves"],
                "waveCountdown": max(0, math.ceil(room.get("waveStartsAt", 0) - time.monotonic())) if room.get("waveStartsAt") else 0,
                "puzzlesCompleted": room["puzzlesCompleted"], "puzzlesRequired": room["puzzlesRequired"],
                "routes": [
                    {"id": route["id"], "name": route["name"],
                     "x": route["x"], "y": route["y"],
                     "votes": sum(1 for vote in room["routeVotes"].values() if vote == route["id"]),
                     "easier": room["revealedRoute"] == route["id"]}
                    for route in room["routes"]
                ],
                "yourRouteVote": room["routeVotes"].get(player_id),
                "stageExitReady": sum(self._at_stage_exit(member) for member in room["players"].values()) if room["phase"] == "stage_exit" else 0,
                "assassinationActive": room["phase"] == "combat" and room["encounterType"] == "assassination",
                "inventory": [dict(item) for item in room["players"][player_id]["inventory"]],
                "town": room["town"],
                "shopStock": [dict(item) for item in room["players"][player_id]["shopStock"]] if room["phase"] == "town" else [],
                "townInteraction": room["players"][player_id].get("townInteraction"),
                "townInterior": room["players"][player_id].get("townInterior"),
                "nearbyNpc": self._nearby_npc(room, room["players"][player_id]) if room["phase"] == "town" else None,
                "townNpcs": self._town_npcs(room, room["players"][player_id]) if room["phase"] == "town" else {},
                "townHouses": copy.deepcopy(room.get("townLayout", [])) if room["phase"] == "town" else [],
                "townSeed": room.get("townSeed", 0),
                "nearbyHouse": self._nearby_house(room, room["players"][player_id]) if room["phase"] == "town" else None,
                "townExitVotes": sum(1 for member in room["players"].values() if member.get("townExitReady")),
                "townExitTotal": len(room["players"]) if room["phase"] == "town" else 0,
                "nearRoute": self._near_route(room, room["players"][player_id]) if room["phase"] == "routes" else None,
                "chest": dict(room["chest"]) if room["phase"] == "chest" and room["chest"] else None,
                "canResumeAtCheckpoint": bool(room["checkpoint"]),
                "abilityOptions": {name: [ability_record(ability) for ability in options] for name, options in ABILITY_SETS.items()},
                "selectedAbilities": list(room["players"][player_id]["abilities"]),
                "abilitySlots": self._ability_slots(room["players"][player_id]),
                "utilitySlots": [dict(item) if item else None for item in room["players"][player_id]["utilitySlots"]],
                "toolSlots": [dict(item) if item else None for item in room["players"][player_id]["toolSlots"]],
            }

    def action(self, code: str, player_id: str, payload: dict) -> None:
        with self.lock:
            room = self.rooms.get(code.upper())
            if not room or player_id not in room["players"]:
                raise ValueError("Room or player not found.")
            action = str(payload.get("action", ""))
            if action == "leaveRoom":
                del room["players"][player_id]
                if not room["players"]:
                    del self.rooms[code.upper()]
                    return
                if room["host"] == player_id:
                    room["host"] = next(iter(room["players"]))
                for member in room["players"].values():
                    if member.get("reviving") == player_id:
                        member["reviving"] = None
                if room["phase"] == "puzzle":
                    room["puzzle"] = new_puzzle(list(room["players"]))
                elif room["phase"] == "routes":
                    room["routeVotes"].pop(player_id, None)
                    if room["routeVotes"] and len(room["routeVotes"]) == len(room["players"]):
                        self._resolve_routes(room)
                elif room["phase"] == "chest" and room["chest"]:
                    room["chest"]["decisions"].pop(player_id, None)
                    self._finish_chest_if_ready(room)
                self._say(room, "system", "The Gauntlet", "A player returned to the main menu.")
                return
            player = room["players"][player_id]
            if action == "class":
                chosen = str(payload.get("class", ""))
                if room["phase"] != "lobby":
                    raise ValueError("Class selection is closed for this run.")
                if chosen not in CLASSES:
                    raise ValueError("Unknown class.")
                if any(p["class"] == chosen for pid, p in room["players"].items() if pid != player_id):
                    raise ValueError("That class is already taken.")
                if player["class"] == chosen:
                    return
                player["class"] = chosen
                player["maxHp"] = CLASSES[chosen]["hp"]
                player["hp"] = player["maxHp"]
                player["abilities"] = []
                player["abilityCooldowns"] = {}
            elif action == "loadout":
                if room["phase"] != "lobby" or not player["class"]:
                    raise ValueError("Choose a class before setting abilities.")
                selected = payload.get("abilities")
                allowed = {ability[0] for ability in ABILITY_SETS[player["class"]]}
                if (not isinstance(selected, list) or len(selected) > 3 or
                        not all(isinstance(item, str) for item in selected) or
                        len(set(selected)) != len(selected) or any(item not in allowed for item in selected)):
                    raise ValueError("Choose one ability from each category.")
                category_by_id = {ability[0]: ability[7] for ability in ABILITY_SETS[player["class"]]}
                categories = [category_by_id[item] for item in selected]
                if len(set(categories)) != len(categories):
                    raise ValueError("Choose one Light, one Special, and one Ultimate ability.")
                player["abilities"] = [next((item for item in selected if category_by_id[item] == category), None)
                                        for category in ("light", "special", "ultimate") if any(c == category for c in categories)]
            elif action == "chat":
                message = str(payload.get("message", "")).strip()[:240]
                if message:
                    self._say(room, player_id, player["name"], message)
            elif action == "input":
                if room["phase"] not in ("combat", "town", "routes", "stage_exit", "puzzle", "chest") or player["status"] != "alive":
                    return
                dx = max(-1, min(1, float(payload.get("x", 0))))
                dy = max(-1, min(1, float(payload.get("y", 0))))
                length = math.hypot(dx, dy)
                if length > 1:
                    dx, dy = dx / length, dy / length
                player["dx"], player["dy"] = dx, dy
                if length > 0.05:
                    player["facingX"], player["facingY"] = dx, dy
                player["attacking"] = bool(payload.get("attack", False))
            elif action == "dash":
                now = time.monotonic()
                if room["phase"] != "combat" or player["status"] != "alive":
                    raise ValueError("Dash is available during combat while standing.")
                if player.get("dashCooldownUntil", 0) > now:
                    raise ValueError(f"Dash recharges in {math.ceil(player['dashCooldownUntil'] - now)} seconds.")
                dx, dy = player.get("dx", 0), player.get("dy", 0)
                if math.hypot(dx, dy) < 0.05:
                    dx, dy = player.get("facingX", 1), player.get("facingY", 0)
                length = max(0.001, math.hypot(dx, dy))
                dx, dy = dx / length, dy / length
                start_x, start_y = player["x"], player["y"]
                player["x"] = max(28, min(WIDTH - 28, player["x"] + dx * 116))
                player["y"] = max(30, min(HEIGHT - 30, player["y"] + dy * 116))
                player["facingX"], player["facingY"] = dx, dy
                player["dashCooldownUntil"] = now + 5
                self._add_effect(room, "dash", start_x, start_y, CLASSES.get(player["class"], {}).get("color", "#ffffff"),
                                 player["x"], player["y"], 0.32, attack_class=player["class"] or "")
            elif action == "attack":
                self._attack(room, player)
            elif action == "revive":
                self._revive(room, player)
            elif action == "interact":
                self._interact(room, player)
            elif action == "routeVote":
                if room["phase"] != "routes":
                    raise ValueError("There is no route choice right now.")
                route_id = str(payload.get("route", ""))
                if route_id not in {route["id"] for route in room["routes"]}:
                    raise ValueError("That route is no longer available.")
                route = next(route for route in room["routes"] if route["id"] == route_id)
                if math.hypot(player["x"] - route["x"], player["y"] - route["y"]) > 72 or 52 < player["x"] < WIDTH - 52:
                    raise ValueError("Follow the trail all the way to the screen edge before choosing it.")
                room["routeVotes"][player_id] = route_id
                self._say(room, "system", "The Gauntlet", f"{player['name']} votes for {next(r['name'] for r in room['routes'] if r['id'] == route_id)}.")
                if len(room["routeVotes"]) == len(room["players"]):
                    self._resolve_routes(room)
            elif action == "shopBuy":
                if room["phase"] != "town":
                    raise ValueError("The shop is open in town.")
                item_key = str(payload.get("item", ""))
                if not self._at_merchant(room, player):
                    raise ValueError("Visit the merchant before buying.")
                stock = next((entry for entry in player["shopStock"] if entry["key"] == item_key), None)
                if not stock:
                    raise ValueError("That item is not in stock.")
                if len(player["inventory"]) >= 5:
                    raise ValueError("Your five-item pouch is full.")
                if room["runes"] < stock["price"]:
                    raise ValueError("The party does not have enough Runes.")
                room["runes"] -= stock["price"]
                player["inventory"].append(self._make_item(item_key, stock["price"]))
                player["shopStock"].remove(stock)
                if room["checkpoint"]:
                    room["checkpoint"]["shopStock"][player_id] = copy.deepcopy(player["shopStock"])
                self._say(room, "system", "The Gauntlet", f"{player['name']} bought {ITEMS[item_key]['name']}.")
            elif action == "shopSell":
                if room["phase"] != "town":
                    raise ValueError("Items can be sold in town.")
                if not self._at_merchant(room, player):
                    raise ValueError("Visit the merchant before selling.")
                item_id = str(payload.get("item", ""))
                item = next((entry for entry in player["inventory"] if entry["id"] == item_id), None)
                if not item:
                    raise ValueError("That item is not in your pouch.")
                player["inventory"].remove(item)
                room["runes"] += item["sell"]
                self._say(room, "system", "The Gauntlet", f"{player['name']} sold {item['name']} for {item['sell']} Runes.")
            elif action == "closeShop":
                player["townInteraction"] = None
            elif action == "useItem":
                item_id = str(payload.get("item", ""))
                item = next((entry for entry in player["inventory"] + [i for i in player["utilitySlots"] if i] if entry["id"] == item_id), None)
                if not item:
                    raise ValueError("That item is not in your pouch.")
                if item["kind"] == "heal":
                    if room["phase"] not in ("town", "combat") or player["status"] != "alive":
                        raise ValueError("You can use a healing draught while alive in combat or town.")
                    if player["hp"] >= player["maxHp"]:
                        raise ValueError("You are already at full health.")
                    player["hp"] = min(player["maxHp"], player["hp"] + item.get("heal", 40))
                elif item["kind"] == "ward":
                    if room["phase"] != "combat" or player["status"] != "alive":
                        raise ValueError("A warding item can be used during combat.")
                    player["wardUntil"] = time.monotonic() + item.get("duration", 30)
                    player["wardFactor"] = item.get("factor", 0.6)
                elif item["kind"] == "hint":
                    if room["phase"] != "routes" or not room["routes"]:
                        raise ValueError("Save the lens for a route fork.")
                    easiest = min(route["danger"] for route in room["routes"])
                    room["revealedRoute"] = next(route["id"] for route in room["routes"] if route["danger"] == easiest)
                elif item["kind"] == "mana":
                    if room["phase"] not in ("combat", "town") or player["status"] != "alive":
                        raise ValueError("A Mana Draught can be used while alive in combat or town.")
                    if player["mana"] >= player["maxMana"]:
                        raise ValueError("Your mana is already full.")
                    player["mana"] = min(player["maxMana"], player["mana"] + item.get("mana", 50))
                elif item["kind"] == "buff":
                    if room["phase"] != "combat" or player["status"] != "alive":
                        raise ValueError("A damage tonic can be used while alive in combat.")
                    player["damageBoostUntil"] = max(player["damageBoostUntil"], time.monotonic() + item.get("duration", 10))
                    player["damageBoost"] = max(player["damageBoost"], item.get("factor", 1.4))
                elif item["kind"] == "speed":
                    if room["phase"] != "combat" or player["status"] != "alive":
                        raise ValueError("A speed elixir can be used while alive in combat.")
                    player["speedBoostUntil"] = max(player["speedBoostUntil"], time.monotonic() + item.get("duration", 10))
                    player["speedBoost"] = max(player["speedBoost"], item.get("factor", 1.45))
                elif item["kind"] == "arrows":
                    if room["phase"] != "combat" or player["status"] != "alive":
                        raise ValueError("Special arrows can be prepared while alive in combat.")
                    player["specialAttacks"] = item.get("attacks", 5)
                    player["specialAttackFactor"] = item.get("factor", 1.5)
                else:
                    raise ValueError("That item cannot be used here.")
                if item in player["inventory"]:
                    player["inventory"].remove(item)
                else:
                    slot = player["utilitySlots"].index(item)
                    player["utilitySlots"][slot] = None
                self._say(room, "system", "The Gauntlet", f"{player['name']} used {item['name']}.")
            elif action == "equipItem":
                item_id = str(payload.get("item", ""))
                slot_index = int(payload.get("slot", -1))
                item = next((entry for entry in player["inventory"] if entry["id"] == item_id), None)
                if not item:
                    raise ValueError("That item is not in your pouch.")
                if item["slot"] == "utility":
                    if not 0 <= slot_index < 3:
                        raise ValueError("Choose one of the three utility slots.")
                    displaced = player["utilitySlots"][slot_index]
                    if displaced and len(player["inventory"]) >= 5:
                        raise ValueError("Your pouch is full; make room before swapping this slot.")
                    player["utilitySlots"][slot_index] = item
                elif item["slot"] == "tool":
                    if not 0 <= slot_index < 2:
                        raise ValueError("Choose one of the two tool slots.")
                    if player["toolSlots"][slot_index] and player["toolSlots"][slot_index]["kind"] != item["kind"]:
                        raise ValueError("Choose a tool slot with a matching weapon or armor type.")
                    displaced = player["toolSlots"][slot_index]
                    if displaced and len(player["inventory"]) >= 5:
                        raise ValueError("Your pouch is full; make room before swapping this slot.")
                    player["toolSlots"][slot_index] = item
                    player["weapon"] = next((gear for gear in player["toolSlots"] if gear and gear["kind"] == "weapon"), None)
                    player["armor"] = next((gear for gear in player["toolSlots"] if gear and gear["kind"] == "armor"), None)
                else:
                    raise ValueError("That item cannot be equipped.")
                player["inventory"].remove(item)
                if displaced:
                    player["inventory"].append(displaced)
                self._say(room, "system", "The Gauntlet", f"{player['name']} equipped {item['name']}.")
            elif action == "unequipItem":
                slot_kind = str(payload.get("slotKind", ""))
                slot_index = int(payload.get("slot", -1))
                slots = player["utilitySlots"] if slot_kind == "utility" else player["toolSlots"] if slot_kind == "tool" else []
                if not 0 <= slot_index < len(slots) or not slots[slot_index]:
                    raise ValueError("That equipment slot is empty.")
                if len(player["inventory"]) >= 5:
                    raise ValueError("Your pouch is full; make room before unequipping.")
                item = slots[slot_index]
                slots[slot_index] = None
                player["inventory"].append(item)
                if slot_kind == "tool":
                    player["weapon"] = next((gear for gear in player["toolSlots"] if gear and gear["kind"] == "weapon"), None)
                    player["armor"] = next((gear for gear in player["toolSlots"] if gear and gear["kind"] == "armor"), None)
                self._say(room, "system", "The Gauntlet", f"{player['name']} unequipped {item['name']}.")
            elif action == "townContinue":
                self._vote_town_exit(room, player)
            elif action == "ability":
                slot_index = int(payload.get("slot", 0)) - 1
                if room["phase"] != "combat" or player["status"] != "alive" or not 0 <= slot_index < 3:
                    raise ValueError("Use an ability slot during combat while standing.")
                self._cast_ability(room, player, slot_index)
            elif action == "checkpointResume":
                if player_id != room["host"] or room["phase"] != "defeat" or not room["checkpoint"]:
                    raise ValueError("The host can return the party to its last inn after a wipe.")
                room["stage"] = room["checkpoint"]["stage"]
                room["wave"] = room["checkpoint"]["wave"]
                room["town"] = room["checkpoint"]["town"]
                room["region"] = room["checkpoint"].get("region", "woodland")
                for member_id, party_member in room["players"].items():
                    party_member["shopStock"] = copy.deepcopy(room["checkpoint"]["shopStock"].get(member_id, []))
                for key in ("bossesDefeated", "miniBossesSinceBoss", "miniBossesRequired",
                            "regularWavesSinceMiniBoss", "regularWavesRequired", "bossSequence", "stageWave", "stageWaves",
                            "miniBossStages", "bossStages", "puzzlesRequired", "puzzlesCompleted", "puzzleStages",
                            "townsTarget", "townsVisited", "townStages", "townLayout", "townSeed"):
                    room[key] = copy.deepcopy(room["checkpoint"][key])
                room["enemies"] = []
                room["waveStartsAt"] = 0
                for party_member in room["players"].values():
                    party_member["status"] = "alive"
                    party_member["hp"] = party_member["maxHp"]
                    party_member["mana"] = party_member["maxMana"]
                    party_member["x"], party_member["y"] = 480, 340
                    party_member["dx"], party_member["dy"] = 0, 0
                    party_member["townInterior"] = None
                    party_member["townReturn"] = None
                    party_member["townExitReady"] = False
                    party_member["townInteraction"] = None
                    party_member["attacking"] = False
                    party_member["reviving"] = None
                    party_member["wardUntil"] = 0
                    party_member["wardFactor"] = 1.0
                    party_member["damageBoostUntil"] = 0
                    party_member["speedBoostUntil"] = 0
                    party_member["specialAttacks"] = 0
                    party_member["specialAttackFactor"] = 1
                room["phase"] = "town"
                self._say(room, "system", "The Gauntlet", "The party returns to its last inn. Carried items remain.")
            elif action == "openChest":
                if room["phase"] != "chest" or not room["chest"]:
                    raise ValueError("There is no chest to open right now.")
                if math.hypot(player["x"] - room["chest"]["x"], player["y"] - room["chest"]["y"]) > 62:
                    raise ValueError("Walk up to the chest before opening it.")
                if player_id in room["chest"]["decisions"] or player["chestReward"]:
                    raise ValueError("You have already made your chest choice.")
                if not room["chest"]["runesAwarded"]:
                    chest_runes = random.randint(5, 12)
                    room["runes"] += chest_runes
                    room["chest"]["runesAwarded"] = True
                    room.setdefault("privateNotices", {})[player_id] = f"Chest opened: {chest_runes} shared Runes."
                    self._say(room, "system", "The Gauntlet", f"The opened chest contains {chest_runes} shared Runes.")
                if not player["curse"] and random.random() < 0.12:
                    curse = dict(random.choice(CURSES))
                    curse["remainingStages"] = 5
                    player["curse"] = curse
                    room["chest"]["decisions"][player_id] = "opened"
                    room.setdefault("privateNotices", {})[player_id] = f"CURSED: {curse['name']} — {curse['description']} It occupies your hidden curse slot."
                    self._say(room, "system", "The Gauntlet", f"A hidden curse latched onto {player['name']}! It will fade after five combat or puzzle stages.")
                else:
                    item = self._make_item(self._roll_chest_item_key())
                    if len(player["inventory"]) < 5:
                        player["inventory"].append(item)
                        room["chest"]["decisions"][player_id] = "opened"
                        room.setdefault("privateNotices", {})[player_id] = f"Chest loot: {item['rarity']} {item['name']} — added to your pouch."
                        self._say(room, "system", "The Gauntlet", f"{player['name']} found {item['rarity']} loot: {item['name']}.")
                    else:
                        player["chestReward"] = item
                        room.setdefault("privateNotices", {})[player_id] = f"Chest loot: {item['rarity']} {item['name']}. Swap a pouch item to claim it."
                        self._say(room, "system", "The Gauntlet", f"{player['name']} found {item['rarity']} loot, but their pouch is full. They must swap an item to claim it.")
                self._finish_chest_if_ready(room)
            elif action == "chestClaim":
                if room["phase"] != "chest" or not room["chest"] or not player["chestReward"]:
                    raise ValueError("You do not have a pending chest item to claim.")
                replace_id = str(payload.get("replace", ""))
                old_item = next((item for item in player["inventory"] if item["id"] == replace_id), None)
                if not old_item:
                    raise ValueError("Choose one pouch item to swap out.")
                player["inventory"].remove(old_item)
                room["runes"] += old_item["sell"]
                player["inventory"].append(player["chestReward"])
                item_name = player["chestReward"]["name"]
                player["chestReward"] = None
                room.setdefault("privateNotices", {})[player_id] = f"Chest loot claimed: {item_name}. {old_item['name']} sold for {old_item['sell']} Runes."
                room["chest"]["decisions"][player_id] = "opened"
                self._say(room, "system", "The Gauntlet", f"{player['name']} swapped {old_item['name']} for {item_name}; the old item sold for {old_item['sell']} Runes.")
                self._finish_chest_if_ready(room)
            elif action == "start":
                if player_id != room["host"]:
                    raise ValueError("Only the room host can start the run.")
                if room["phase"] != "lobby":
                    raise ValueError("The run has already started.")
                if not player["class"]:
                    raise ValueError("Choose a class before starting.")
                if any(not p["class"] for p in room["players"].values()):
                    raise ValueError("Every player must choose a class first.")
                if any(len(p["abilities"]) != 3 or
                       {next(ability[7] for ability in ABILITY_SETS[p["class"]] if ability[0] == selected)
                        for selected in p["abilities"]} != {"light", "special", "ultimate"}
                       for p in room["players"].values()):
                    raise ValueError("Every player must select one Light, one Special, and one Ultimate ability.")
                room["stage"] = 1
                room["wave"] = 1
                room["bossesDefeated"] = 0
                room["miniBossesSinceBoss"] = 0
                room["miniBossesRequired"] = random.randint(2, 4)
                room["regularWavesSinceMiniBoss"] = 0
                room["regularWavesRequired"] = random.randint(3, 5)
                room["bossSequence"] = random.sample(LARGE_BOSSES, 2) + [random.choice(DRAGON_TYPES)]
                room["bossStages"] = [8, 16, 25]
                room["miniBossStages"] = self._build_mini_boss_schedule()
                room["puzzlesRequired"], room["puzzleStages"] = self._build_puzzle_schedule()
                room["townsTarget"] = random.choices((2, 3, 4), weights=(15, 70, 15), k=1)[0]
                room["townsVisited"] = 0
                room["townStages"] = self._build_town_schedule(room["townsTarget"], room["puzzleStages"], room["miniBossStages"] + room["bossStages"])
                event_candidates = [stage for stage in range(2, 25) if stage not in
                                    room["townStages"] + room["puzzleStages"] + room["miniBossStages"] + room["bossStages"]]
                room["assassinationStage"] = random.choice(event_candidates) if event_candidates and random.random() < 0.08 else None
                room["assassinationUsed"] = False
                room["puzzlesCompleted"] = 0
                room["stageWave"] = 1
                room["stageWaves"] = self._stage_wave_count(len(room["players"]))
                room["waveStartsAt"] = 0
                room["encounterType"] = "normal"
                room["encounterName"] = ""
                room["phase"] = "combat"
                room["routeEffect"] = random.choice(("wave_size", "enemy_health"))
                self._reset_cooldowns(room)
                self._spawn_wave(room)
                self._say(room, "system", "The Gauntlet", "The run begins!")
            else:
                raise ValueError("Unknown action.")

    def _say(self, room: dict, player_id: str, name: str, message: str) -> None:
        room["messageId"] += 1
        room["chat"].append({
            "id": room["messageId"], "player": player_id, "name": name,
            "message": message, "at": time.time(),
        })
        room["chat"] = room["chat"][-80:]

    def _present_routes(self, room: dict) -> None:
        room["chest"] = None
        if room["stage"] + 1 in room.get("townStages", []):
            paths = [(name, "town", random.choice(("woodland", "ruins"))) for name in TOWNS]
        else:
            paths = [("Moss Road", "combat", "woodland"), ("High Arch", "puzzle", "ruins"),
                     ("Ashen Pass", "combat", "cavern"), ("Moonwell Way", "puzzle", "ruins"),
                     ("Frost Veil", "combat", "frost"), ("Glacier Stair", "puzzle", "frost")]
        chosen = random.sample(paths, 2)
        dangers = random.sample(range(1, 6), len(chosen))
        room["routes"] = [
            {"id": secrets.token_hex(3), "destination": name, "kind": kind, "region": region,
             "danger": dangers[index], "votes": {}, "x": ROUTE_GATES[index][0], "y": ROUTE_GATES[index][1],
             "name": name}
            for index, (name, kind, region) in enumerate(chosen)
        ]
        room["routeVotes"] = {}
        room["revealedRoute"] = None
        room["phase"] = "stage_exit"
        room["projectiles"] = []
        self._say(room, "system", "The Gauntlet", "Stage cleared. Gather at the opening on the top edge to reach the fork.")

    @staticmethod
    def _at_stage_exit(player: dict) -> bool:
        return player["status"] == "alive" and abs(player["x"] - WIDTH / 2) <= 96 and player["y"] <= 48

    def _enter_fork(self, room: dict) -> None:
        room["phase"] = "routes"
        for index, player in enumerate(room["players"].values()):
            player["x"], player["y"] = 480 + (index - (len(room["players"]) - 1) / 2) * 24, HEIGHT - 44
            player["dx"], player["dy"] = 0, 0
        self._say(room, "system", "The Gauntlet", "The road forks. Follow the left or right trail all the way to its edge. Everyone chooses by walking.")

    @staticmethod
    def _on_fork_path(x: float, y: float) -> bool:
        for path in FORK_PATHS:
            for (ax, ay), (bx, by) in zip(path, path[1:]):
                fraction = max(0, min(1, ((x - ax) * (bx - ax) + (y - ay) * (by - ay)) /
                                     ((bx - ax) ** 2 + (by - ay) ** 2)))
                if math.hypot(x - ax - fraction * (bx - ax), y - ay - fraction * (by - ay)) <= 54:
                    return True
        return False

    def _tick_travel(self, room: dict) -> None:
        if room["phase"] == "stage_exit":
            if room["players"] and all(self._at_stage_exit(member) for member in room["players"].values()):
                self._enter_fork(room)
        elif room["phase"] == "routes":
            for player in room["players"].values():
                route = self._near_route(room, player)
                if route and (player["x"] <= 52 or player["x"] >= WIDTH - 52):
                    room["routeVotes"][player["id"]] = route["id"]
                else:
                    room["routeVotes"].pop(player["id"], None)
            if room["players"] and len(room["routeVotes"]) == len(room["players"]):
                self._resolve_routes(room)

    def _resolve_routes(self, room: dict) -> None:
        counts = {route["id"]: sum(v == route["id"] for v in room["routeVotes"].values()) for route in room["routes"]}
        highest = max(counts.values())
        tied = [route for route in room["routes"] if counts[route["id"]] == highest]
        host_vote = room["routeVotes"].get(room["host"])
        selected = next((route for route in tied if route["id"] == host_vote), None) or random.choice(tied)
        easiest = min(route["danger"] for route in room["routes"])
        hardest = max(route["danger"] for route in room["routes"])
        if selected["danger"] == easiest and easiest != hardest:
            room["routePressure"] = min(6, room["routePressure"] + 1)
        elif selected["danger"] == hardest and easiest != hardest:
            room["routePressure"] = max(-6, room["routePressure"] - 1)
        room["stage"] += 1
        room["wave"] += 1
        room["stageWave"] = 1
        room["stageWaves"] = self._stage_wave_count(len(room["players"]))
        room["waveStartsAt"] = 0
        self._reset_cooldowns(room)
        room["region"] = selected.get("region", room.get("region", "woodland"))
        room["routes"] = []
        room["routeVotes"] = {}
        if room["stage"] in room["puzzleStages"] and room["puzzlesCompleted"] < room["puzzlesRequired"]:
            room["puzzle"] = new_puzzle(list(room["players"]))
            for index, player in enumerate(room["players"].values()):
                player["x"], player["y"] = 480, 468
                player["dx"], player["dy"] = 0, 0
            room["phase"] = "puzzle"
            self._say(room, "system", "The Gauntlet", "Each adventurer is sealed in a separate rune chamber. Find your totem and stand on its matching rune.")
        elif selected["kind"] == "town":
            self._enter_town(room, selected["destination"])
        else:
            room["phase"] = "combat"
            self._spawn_wave(room)

    @staticmethod
    def _advance_curses(room: dict) -> None:
        for player in room["players"].values():
            curse = player.get("curse")
            if not curse:
                continue
            curse["remainingStages"] -= 1
            if curse["remainingStages"] <= 0:
                player["curse"] = None
                # The cursed slot is private state; only the affected player learns that it faded.
                room.setdefault("privateNotices", {})[player["id"]] = "Your curse has finally faded."

    @staticmethod
    def _roll_chest_item_key() -> str:
        rarity = random.choices(
            [entry[0] for entry in LOOT_RARITIES],
            weights=[entry[1] for entry in LOOT_RARITIES],
            k=1,
        )[0]
        candidates = [key for key, item in ITEMS.items() if item["rarity"] == rarity]
        return random.choice(candidates)

    def _finish_chest_if_ready(self, room: dict) -> None:
        if room["chest"] and len(room["chest"]["decisions"]) == len(room["players"]):
            room["chest"] = None
            self._present_routes(room)

    @staticmethod
    def _make_item(item_key: str, price: int | None = None) -> dict:
        item = ITEMS[item_key]
        return {"id": secrets.token_hex(5), "key": item_key, "name": item["name"], "rarity": item["rarity"],
                "kind": item["kind"], "slot": item["slot"], "description": item["description"],
                "price": price if price is not None else item["price"], "sell": item["sell"],
                "damage": item.get("damage", 0), "armor": item.get("armor", 0), "color": item.get("color"),
                "heal": item.get("heal", 40 if item["kind"] == "heal" else 0),
                "mana": item.get("mana", 0),
                "factor": item.get("factor", 1), "duration": item.get("duration", 0),
                "cooldownRestore": item.get("cooldownRestore", 0), "attacks": item.get("attacks", 0)}

    def _stock_shop(self, room: dict, player: dict) -> None:
        class_consumable = {
            "Knight": "warding_tonic", "Wizard": "mana_draught", "Archer": "piercing_arrows",
            "Cleric": "phoenix_flask", "Rogue": "quickstep_elixir", "Druid": "ember_oil",
            "Bard": "quickstep_elixir", "Healer": "healing_draught",
        }.get(player["class"], "healing_draught")
        keys = list(dict.fromkeys(("healing_draught", class_consumable, CLASS_WEAPONS[player["class"]])))
        if random.random() < 0.18:
            keys.append("route_lens")
        if random.random() < 0.3:
            keys.append(random.choice(("phoenix_flask", "stormguard_charm", "dragonbone_armor", "aegis_of_dawn")))
        player["shopStock"] = [{"key": key, **self._make_item(key), "price": ITEMS[key]["price"]} for key in keys]

    @staticmethod
    def _ability_slots(player: dict) -> list[dict]:
        now = time.monotonic()
        abilities = {ability[0]: ability_record(ability) for ability in ABILITY_SETS.get(player["class"], [])}
        return [
            {**abilities[ability_id], "cooldownLeft": math.ceil(max(0, player["abilityCooldowns"].get(ability_id, 0) - now))}
            for ability_id in player["abilities"] if ability_id in abilities
        ]

    @staticmethod
    def _town_npcs(room: dict, player: dict) -> dict:
        if not player.get("townInterior"):
            return {"gate": {"x": TOWN_GATE[0], "y": TOWN_GATE[1]}}
        house = next((entry for entry in room.get("townLayout", []) if entry["id"] == player["townInterior"]), None)
        service = house.get("service") if house else None
        return {service: {"x": TOWN_SERVICE_POSITION[0], "y": TOWN_SERVICE_POSITION[1]}} if service else {}

    def _nearby_npc(self, room: dict, player: dict) -> dict | None:
        npc_names = {"merchant": "Merchant", "alchemist": "Alchemist", "innkeeper": "Innkeeper", "gate": "Trail Gate"}
        close = [(math.hypot(player["x"] - pos["x"], player["y"] - pos["y"]), key, pos["x"], pos["y"])
                 for key, pos in self._town_npcs(room, player).items()]
        if not close:
            return None
        distance, key, x, y = min(close)
        return {"id": key, "name": npc_names[key], "x": x, "y": y} if distance <= 70 else None

    @staticmethod
    def _nearby_house(room: dict, player: dict) -> dict | None:
        if player.get("townInterior"):
            return {"id": "exit_house", "name": "Town", "x": 480, "y": 450} if math.hypot(player["x"] - 480, player["y"] - 450) <= 62 else None
        for house in room.get("townLayout", []):
            door_x, door_y = house["x"], house["y"] + 47
            if math.hypot(player["x"] - door_x, player["y"] - door_y) <= 44:
                return {**house, "doorX": door_x, "doorY": door_y}
        return None

    def _at_merchant(self, room: dict, player: dict) -> bool:
        npc = self._nearby_npc(room, player)
        return bool(npc and npc["id"] == "merchant")

    @staticmethod
    def _town_walkable(room: dict, x: float, y: float) -> bool:
        return not any(abs(x - house["x"]) < 69 and house["y"] - 78 < y < house["y"] + 35
                       for house in room.get("townLayout", []))

    @staticmethod
    def _new_town_layout() -> list[dict]:
        buildings = [("inn", "Inn", "innkeeper"), ("store", "Store", "merchant"),
                     ("lab", "Alchemy Lab", "alchemist"), ("cottage", "Cottage", None),
                     ("lodge", "Lodge", None)]
        slots = [(205, 150), (480, 145), (755, 155), (240, 360), (725, 355)]
        random.shuffle(slots)
        roofs = ["#a94f3d", "#426f78", "#c56643", "#906451", "#b6773f"]
        random.shuffle(roofs)
        return [{"id": key, "name": name, "service": service,
                 "x": pos[0] + random.randint(-20, 20), "y": pos[1] + random.randint(-12, 12),
                 "roof": roofs[index]} for index, ((key, name, service), pos) in enumerate(zip(buildings, slots))]

    def _vote_town_exit(self, room: dict, player: dict) -> None:
        if room["phase"] != "town" or player.get("townInterior"):
            raise ValueError("Step outside and gather at the town exit to vote.")
        gate_x, gate_y = TOWN_GATE
        if math.hypot(player["x"] - gate_x, player["y"] - gate_y) > 78:
            raise ValueError("Gather at the town gate before voting to leave.")
        player["townExitReady"] = not player.get("townExitReady", False)
        if player["townExitReady"]:
            ready_count = sum(1 for member in room["players"].values() if member.get("townExitReady"))
            self._say(room, "system", "The Gauntlet", f"{player['name']} is ready to leave town ({ready_count}/{len(room['players'])}).")
        else:
            self._say(room, "system", "The Gauntlet", f"{player['name']} changed their vote to stay in town.")
        if all(member.get("townExitReady") and not member.get("townInterior") and
               math.hypot(member["x"] - gate_x, member["y"] - gate_y) <= 78
               for member in room["players"].values()):
            room["phase"] = "combat"
            room["waveStartsAt"] = 0
            room["stageWave"] = 1
            for member in room["players"].values():
                member["townInteraction"] = None
                member["townExitReady"] = False
            self._reset_cooldowns(room)
            self._say(room, "system", "The Gauntlet", "Everyone is ready. The party leaves town together!")
            self._spawn_wave(room)

    @staticmethod
    def _near_route(room: dict, player: dict) -> dict | None:
        near = [(math.hypot(player["x"] - route["x"], player["y"] - route["y"]), route) for route in room["routes"]]
        if not near:
            return None
        distance, route = min(near, key=lambda item: item[0])
        return {"id": route["id"], "name": route["name"]} if distance <= 72 else None

    @staticmethod
    def _reset_cooldowns(room: dict) -> None:
        for player in room["players"].values():
            player["abilityCooldowns"] = {}

    @staticmethod
    def _build_mini_boss_schedule() -> list[int]:
        stages = []
        for start, end in ((1, 8), (8, 16), (16, 25)):
            count = random.randint(2, 4)
            for index in range(count):
                ideal = start + (index + 1) * (end - start) / (count + 1)
                candidates = [stage for stage in range(start + 1, end) if stage not in stages]
                pick = min(candidates, key=lambda stage: (abs(stage - ideal + random.uniform(-0.45, 0.45)), random.random()))
                stages.append(pick)
        return sorted(stages)

    @staticmethod
    def _build_puzzle_schedule() -> tuple[int, list[int]]:
        count = random.choices((1, 2, 3), weights=(65, 30, 5), k=1)[0]
        pools = ((4, 5, 6, 7), (11, 12, 13, 14), (18, 19, 20, 22, 23))
        return count, [random.choice(pool) for pool in pools[:count]]

    @staticmethod
    def _build_town_schedule(count: int, excluded: list[int], boss_stages: list[int]) -> list[int]:
        bands = ((2, 7), (8, 13), (14, 19), (20, 24))
        candidates = [[stage for stage in range(start, end + 1) if stage not in excluded and stage not in boss_stages]
                      for start, end in bands]
        selected = []
        for band in random.sample(candidates, min(count, len(candidates))):
            available = [stage for stage in band if stage not in selected]
            if available:
                selected.append(random.choice(available))
        fallback = [stage for stage in range(2, 25) if stage not in excluded and stage not in boss_stages and stage not in selected]
        while len(selected) < count and fallback:
            pick = random.choice(fallback)
            selected.append(pick)
            fallback.remove(pick)
        return sorted(selected)

    def _interact(self, room: dict, player: dict) -> None:
        player_id = player["id"]
        if room["phase"] == "chest":
            self.action(room["code"], player_id, {"action": "openChest"})
            return
        if room["phase"] == "routes":
            route = self._near_route(room, player)
            if not route:
                raise ValueError("Walk up to one of the glowing paths first.")
            self.action(room["code"], player_id, {"action": "routeVote", "route": route["id"]})
            return
        if room["phase"] == "puzzle":
            puzzle_room = room["puzzle"]["rooms"][player_id]
            totem = puzzle_room["totem"]
            if math.hypot(player["x"] - totem["x"], player["y"] - totem["y"]) <= 58:
                puzzle_room["totemSeen"] = True
                return
            rune = next((entry for entry in puzzle_room["runes"]
                         if math.hypot(player["x"] - entry["x"], player["y"] - entry["y"]) <= 40), None)
            if rune and rune["rune"] != puzzle_room["target"] and time.monotonic() - puzzle_room["wrongAt"] >= 1.5:
                puzzle_room["wrongAt"] = time.monotonic()
                room["strainMistakes"] += 1
                room.setdefault("privateNotices", {})[player_id] = "Wrong rune. The gauntlet grows slightly harder."
                self._say(room, "system", "The Gauntlet", f"{player['name']} tested the wrong rune. The run grows slightly more dangerous.")
                return
            raise ValueError("Find the totem for its clue, then stand on the matching rune.")
        if room["phase"] == "town":
            house = self._nearby_house(room, player)
            if player.get("townInterior") and house:
                player["townInterior"] = None
                player["x"], player["y"] = player.get("townReturn") or (house.get("x", 480), house.get("y", 220))
                player["townReturn"] = None
                player["townInteraction"] = None
                player["dx"], player["dy"] = 0, 0
                room.setdefault("privateNotices", {})[player_id] = "You step back into the village."
                return
            if house and not player.get("townInterior"):
                player["townReturn"] = (player["x"], player["y"])
                player["townInterior"] = house["id"]
                player["x"], player["y"] = 480, 405
                player["dx"], player["dy"] = 0, 0
                player["townExitReady"] = False
                player["townInteraction"] = None
                room.setdefault("privateNotices", {})[player_id] = f"You entered {house['name']}. Press E at the door to return to town."
                return
            npc = self._nearby_npc(room, player)
            if not npc:
                raise ValueError("Walk to the door, the shopkeeper, or the town gate to interact.")
            npc_id = npc["id"]
            player["townInteraction"] = npc_id
            if npc_id == "alchemist":
                if len(player["inventory"]) < 5:
                    gift = random.choice(("healing_draught", "mana_draught", "quickstep_elixir"))
                    player["inventory"].append(self._make_item(gift))
                    room.setdefault("privateNotices", {})[player_id] = f"The alchemist gives you a {ITEMS[gift]['name']}. Added to your pouch."
                else:
                    player["hp"] = min(player["maxHp"], player["hp"] + 40)
                    player["mana"] = min(player["maxMana"], player["mana"] + 40)
                    room.setdefault("privateNotices", {})[player_id] = "The alchemist restores 40 health and mana; your pouch was full."
            elif npc_id == "innkeeper":
                for member in room["players"].values():
                    member["hp"], member["mana"] = member["maxHp"], member["maxMana"]
                if room.get("checkpoint"):
                    room["checkpoint"]["stage"] = room["stage"]
                    room["checkpoint"]["wave"] = room["wave"]
                    room["checkpoint"]["town"] = room["town"]
                    room["checkpoint"]["region"] = room.get("region", "woodland")
                room.setdefault("privateNotices", {})[player_id] = "The innkeeper restores the whole party and confirms this inn as your checkpoint."
                self._say(room, "system", "The Gauntlet", f"{player['name']} checked in at the inn. The party is restored.")
            elif npc_id == "gate":
                self._vote_town_exit(room, player)
            return
        raise ValueError("There is nothing nearby to interact with.")

    def _enter_town(self, room: dict, town_name: str | None = None) -> None:
        room["phase"] = "town"
        room["town"] = town_name or random.choice(TOWNS)
        room["townsVisited"] = room.get("townsVisited", 0) + 1
        room["townLayout"] = self._new_town_layout()
        room["townSeed"] = random.randrange(1, 1_000_000)
        for index, party_member in enumerate(room["players"].values()):
            party_member["status"] = "alive"
            party_member["hp"] = party_member["maxHp"]
            party_member["mana"] = party_member["maxMana"]
            party_member["x"], party_member["y"] = 480 + (index - (len(room["players"]) - 1) / 2) * 42, 335
            party_member["dx"], party_member["dy"] = 0, 0
            party_member["attacking"] = False
            party_member["reviving"] = None
            party_member["wardUntil"] = 0
            party_member["wardFactor"] = 1.0
            party_member["townInteraction"] = None
            party_member["townInterior"] = None
            party_member["townReturn"] = None
            party_member["townExitReady"] = False
            self._stock_shop(room, party_member)
        room["checkpoint"] = {"stage": room["stage"], "wave": room["wave"], "town": room["town"], "region": room.get("region", "woodland"),
                               "shopStock": {pid: copy.deepcopy(p["shopStock"]) for pid, p in room["players"].items()},
                               **{key: copy.deepcopy(room[key]) for key in (
                                   "bossesDefeated", "miniBossesSinceBoss", "miniBossesRequired",
                                   "regularWavesSinceMiniBoss", "regularWavesRequired", "bossSequence", "stageWave", "stageWaves",
                                   "miniBossStages", "bossStages", "puzzlesRequired", "puzzlesCompleted", "puzzleStages",
                                   "townsTarget", "townsVisited", "townStages", "townLayout", "townSeed")}}
        self._say(room, "system", "The Gauntlet", f"The party reaches {room['town']}. Rest, trade, and shop; this inn is now the checkpoint.")

    @staticmethod
    def _party_factor(room: dict, values: tuple[float, ...]) -> float:
        return values[max(0, min(3, len(room["players"]) - 1))]

    @staticmethod
    def _stage_wave_count(player_count: int) -> int:
        return 2 if player_count <= 2 else 3

    @staticmethod
    def _stage_ramp(room: dict) -> float:
        stage = max(1, min(25, room["stage"]))
        ramp = 0.62 + 0.38 * (stage - 1) / 24
        # Add gentle pressure from stage 8, then increase it each stage.
        if stage >= 8:
            ramp += 0.08 + 0.04 * (stage - 8)
        return ramp

    def _spawn_wave(self, room: dict, preserve_players: bool = False) -> None:
        if room["stage"] == room.get("assassinationStage") and room["stageWave"] == 1 and not room.get("assassinationUsed"):
            self._spawn_assassination(room)
        elif room["stage"] in room["bossStages"] and room["stageWave"] == room["stageWaves"]:
            self._spawn_large_boss(room)
        elif room["stage"] in room["miniBossStages"] and room["stageWave"] == room["stageWaves"]:
            self._spawn_mini_boss(room)
        else:
            self._spawn_regular_wave(room)
        for enemy in room["enemies"]:
            if enemy["kind"] == "minotaur":
                enemy["speed"] *= 1.3
        if room.get("phase") == "combat":
            if preserve_players:
                self._place_enemies_at_random_edge(room)
            else:
                self._position_battle_formation(room)
            if room["encounterType"] == "assassination":
                self._place_assassins_at_edges(room)

    def _spawn_assassination(self, room: dict) -> None:
        self._spawn_regular_wave(room)
        count = len(room["players"])
        originals = list(room["enemies"])
        room["enemies"] = []
        for index in range((6, 12, 18, 24)[max(0, min(3, count - 1))]):
            enemy = copy.deepcopy(originals[index % len(originals)])
            enemy["id"] = secrets.token_hex(4)
            enemy["name"] = "Assassin " + enemy["name"]
            enemy["hp"] = enemy["maxHp"] = math.ceil(enemy["maxHp"] * 1.4)
            enemy["damage"] = max(1, round(enemy["damage"] * 1.25))
            enemy["speed"] *= 1.12
            enemy["assassin"] = True
            enemy["class"] = random.choice(("Rogue", "Knight", "Archer", "Wizard"))
            room["enemies"].append(enemy)
        room["assassinationUsed"] = True
        room["encounterType"] = "assassination"
        room["encounterName"] = "Assassination attempt"
        self._add_effect(room, "ambush", WIDTH / 2, HEIGHT / 2, "#f58b8b", duration=3, text="ASSASSINATION ATTEMPT!")
        self._say(room, "system", "The Gauntlet", "Assassins surround the party! Survive the ambush.")

    @staticmethod
    def _place_assassins_at_edges(room: dict) -> None:
        edges = ("top", "right", "bottom", "left")
        for index, enemy in enumerate(room["enemies"]):
            edge = edges[index % 4]
            along = (index // 4 + 1) / (math.ceil(len(room["enemies"]) / 4) + 1)
            if edge in ("top", "bottom"):
                enemy["x"], enemy["y"] = 32 + along * (WIDTH - 64), 3 if edge == "top" else HEIGHT - 3
            else:
                enemy["x"], enemy["y"] = 3 if edge == "left" else WIDTH - 3, 32 + along * (HEIGHT - 64)
            enemy["entryEdge"] = edge
            enemy["lastAttack"] = time.monotonic() + 1.5

    @staticmethod
    def _place_enemies_at_random_edge(room: dict) -> None:
        edge = random.choice(("top", "right", "bottom", "left"))
        count = len(room["enemies"])
        for index, enemy in enumerate(room["enemies"]):
            along = (index + 1) / (count + 1)
            if edge == "top":
                enemy["x"], enemy["y"] = 32 + along * (WIDTH - 64), 3
            elif edge == "bottom":
                enemy["x"], enemy["y"] = 32 + along * (WIDTH - 64), HEIGHT - 3
            elif edge == "left":
                enemy["x"], enemy["y"] = 3, 32 + along * (HEIGHT - 64)
            else:
                enemy["x"], enemy["y"] = WIDTH - 3, 32 + along * (HEIGHT - 64)
            enemy["entryEdge"] = edge

    @staticmethod
    def _position_battle_formation(room: dict) -> None:
        players = list(room["players"].values())
        player_gap = min(92, 760 / max(1, len(players)))
        player_start = WIDTH / 2 - player_gap * (len(players) - 1) / 2
        for index, player in enumerate(players):
            player["x"], player["y"] = player_start + index * player_gap, HEIGHT - 92
            player["dx"], player["dy"] = 0, 0
            player["attacking"] = False
        enemies = room["enemies"]
        columns = min(len(enemies), 6)
        gap = min(136, 800 / max(1, columns))
        start_x = WIDTH / 2 - gap * (columns - 1) / 2
        for index, enemy in enumerate(enemies):
            row, column = divmod(index, columns)
            row_gap = 56 if enemy.get("boss") or enemy.get("miniBoss") else 48
            enemy["x"] = start_x + column * gap
            enemy["y"] = 82 + row * row_gap

    def _spawn_regular_wave(self, room: dict) -> None:
        count = len(room["players"])
        amounts = {1: (1, 2), 2: (3, 5), 3: (5, 8), 4: (8, 12)}
        minimum, maximum = amounts[max(1, min(4, count))]
        amount = random.randint(minimum, maximum)
        if room["routeEffect"] == "wave_size":
            amount = max(minimum, min(maximum, amount + room["routePressure"] * max(1, math.ceil(count / 2))))
        room["enemies"] = []
        strain = self._strain_percent(room["strainMistakes"])
        route_health = room["routePressure"] * 0.025 if room["routeEffect"] == "enemy_health" else 0
        hp_scale = self._party_factor(room, (0.68, 0.78, 0.9, 1.0)) * (0.76 + 0.24 * self._stage_ramp(room))
        damage_scale = self._party_factor(room, (0.48, 0.68, 0.84, 1.0)) * (0.62 + 0.38 * self._stage_ramp(room))
        speed_scale = self._party_factor(room, (0.72, 0.82, 0.92, 1.0)) * (0.76 + 0.24 * self._stage_ramp(room))
        for index in range(amount):
            name, kind, hp, damage, base_color = random.choice(ENEMIES)
            affinity = random.choice(list(AFFINITIES))
            enemy_class = random.choice(tuple(CLASSES))
            angle = (2 * math.pi * index) / max(1, amount)
            room["enemies"].append({
                "id": secrets.token_hex(4), "name": name, "kind": kind,
                "affinity": affinity, "color": AFFINITIES[affinity],
                "baseColor": base_color, "class": enemy_class, "x": 120 + random.random() * (WIDTH - 240),
                "y": 70 + random.random() * (HEIGHT - 140),
                "hp": max(1, math.ceil(hp * hp_scale * (1 + strain) * (1 + route_health))), "maxHp": max(1, math.ceil(hp * hp_scale * (1 + strain) * (1 + route_health))),
                "damage": max(1, round(damage * damage_scale * (1 + strain))), "speed": max(22, round(random.randint(48, 70) * speed_scale)),
                "lastAttack": 0, "stunUntil": 0, "bleedUntil": 0, "bleedDamage": 0, "lastBleedTick": 0,
            })
        room["encounterType"] = "normal"
        room["encounterName"] = ""
        room["regularWavesSinceMiniBoss"] += 1
        self._say(room, "system", "The Gauntlet", f"Wave {room['wave']}: {amount} enemies approach.")

    def _spawn_mini_boss(self, room: dict) -> None:
        count = len(room["players"])
        strain = self._strain_percent(room["strainMistakes"])
        route_health = room["routePressure"] * 0.025 if room["routeEffect"] == "enemy_health" else 0
        room["enemies"] = []
        room["encounterType"] = "mini_boss"
        room["regularWavesSinceMiniBoss"] = 0
        room["regularWavesRequired"] = random.randint(3, 5)
        if random.choice(("empowered", "squadron")) == "empowered":
            name, kind, hp, damage, base_color = random.choice(ENEMIES)
            affinity = random.choice(list(AFFINITIES))
            enemy_class = random.choice(tuple(CLASSES))
            hp_scale = self._party_factor(room, (0.68, 0.78, 0.9, 1.0)) * (0.76 + 0.24 * self._stage_ramp(room))
            damage_scale = self._party_factor(room, (0.48, 0.68, 0.84, 1.0)) * (0.62 + 0.38 * self._stage_ramp(room))
            speed_scale = self._party_factor(room, (0.72, 0.82, 0.92, 1.0)) * (0.76 + 0.24 * self._stage_ramp(room))
            scaled_hp = math.ceil(hp * (2.8 + 0.2 * room["miniBossesSinceBoss"]) * count * hp_scale * (1 + strain) * (1 + route_health))
            room["encounterName"] = f"Empowered {affinity} {name}"
            room["enemies"].append({
                "id": secrets.token_hex(4), "name": room["encounterName"], "kind": kind,
                "affinity": affinity, "color": AFFINITIES[affinity], "baseColor": base_color, "class": enemy_class,
                "x": random.randint(180, WIDTH - 180), "y": random.randint(100, HEIGHT - 100),
                "hp": scaled_hp, "maxHp": scaled_hp,
                "damage": max(1, round(damage * 1.2 * damage_scale * (1 + strain))), "speed": max(24, round(random.randint(56, 76) * speed_scale)),
                "lastAttack": 0, "stunUntil": 0, "bleedUntil": 0, "bleedDamage": 0, "lastBleedTick": 0,
                "miniBoss": True,
            })
            self._say(room, "system", "The Gauntlet", f"Mini-boss: {room['encounterName']} enters the gauntlet!")
        else:
            amount = math.ceil(2.5 * count)
            room["encounterName"] = "Mini-boss Squadron"
            hp_scale = self._party_factor(room, (0.68, 0.78, 0.9, 1.0)) * (0.76 + 0.24 * self._stage_ramp(room))
            damage_scale = self._party_factor(room, (0.48, 0.68, 0.84, 1.0)) * (0.62 + 0.38 * self._stage_ramp(room))
            speed_scale = self._party_factor(room, (0.72, 0.82, 0.92, 1.0)) * (0.76 + 0.24 * self._stage_ramp(room))
            for index in range(amount):
                name, kind, hp, damage, base_color = random.choice(ENEMIES)
                affinity = random.choice(list(AFFINITIES))
                enemy_class = random.choice(tuple(CLASSES))
                scaled_hp = max(1, math.ceil(hp * hp_scale * (1 + strain) * (1 + route_health)))
                room["enemies"].append({
                    "id": secrets.token_hex(4), "name": name, "kind": kind,
                    "affinity": affinity, "color": AFFINITIES[affinity], "baseColor": base_color, "class": enemy_class,
                    "x": 120 + random.random() * (WIDTH - 240), "y": 70 + random.random() * (HEIGHT - 140),
                    "hp": scaled_hp, "maxHp": scaled_hp,
                    "damage": max(1, round(damage * damage_scale * (1 + strain))), "speed": max(22, round(random.randint(48, 70) * speed_scale)),
                    "lastAttack": 0, "stunUntil": 0, "bleedUntil": 0, "bleedDamage": 0, "lastBleedTick": 0,
                    "miniBoss": False,
                })
            self._say(room, "system", "The Gauntlet", f"Mini-boss round: a squadron of {amount} enemies advances!")

    def _spawn_large_boss(self, room: dict) -> None:
        boss_index = room["bossesDefeated"]
        boss = room["bossSequence"][boss_index]
        count = len(room["players"])
        strain = self._strain_percent(room["strainMistakes"])
        route_health = room["routePressure"] * 0.025 if room["routeEffect"] == "enemy_health" else 0
        hp_scale = count * self._party_factor(room, (0.68, 0.78, 0.9, 1.0)) * (0.76 + 0.24 * self._stage_ramp(room)) * (1 + 0.14 * boss_index) * (1 + strain) * (1 + route_health)
        damage_scale = self._party_factor(room, (0.48, 0.68, 0.84, 1.0)) * (0.62 + 0.38 * self._stage_ramp(room)) * (1 + 0.1 * boss_index) * (1 + strain)
        hp = max(1, math.ceil(boss["hp"] * hp_scale))
        room["enemies"] = [{
            "id": secrets.token_hex(4), "name": boss["name"], "kind": "dragon" if boss_index == 2 else boss["kind"], "class": random.choice(tuple(CLASSES)),
            "affinity": boss["affinity"], "color": AFFINITIES[boss["affinity"]], "baseColor": AFFINITIES[boss["affinity"]],
            "x": WIDTH / 2, "y": HEIGHT / 2,
            "hp": hp, "maxHp": hp, "damage": max(1, round(boss["damage"] * damage_scale)),
            "speed": max(18, round((30 + boss_index * 2) * self._party_factor(room, (0.72, 0.82, 0.92, 1.0)) * (0.76 + 0.24 * self._stage_ramp(room)))), "lastAttack": 0, "stunUntil": 0,
            "bleedUntil": 0, "bleedDamage": 0, "lastBleedTick": 0, "boss": True,
        }]
        room["encounterType"] = "large_boss"
        room["encounterName"] = boss["name"]
        self._say(room, "system", "The Gauntlet", f"LARGE BOSS {boss_index + 1} / 3: {boss['name']} blocks the way!")

    @staticmethod
    def _strain_percent(mistakes: int) -> float:
        early = min(mistakes, 2) * 0.005
        middle = min(max(mistakes - 2, 0), 2) * 0.01
        late = max(mistakes - 4, 0) * 0.02
        return min(0.15, early + middle + late)

    def _damage_enemy(self, room: dict, player: dict, enemy: dict, damage: int) -> None:
        if enemy not in room["enemies"]:
            return
        enemy["hp"] -= max(1, damage)
        if enemy["hp"] > 0:
            return
        room["enemies"].remove(enemy)
        room["runes"] += random.randint(2, 5)
        self._say(room, "system", "The Gauntlet", f"{enemy['affinity']} {enemy['name']} defeated. Runes collected.")
        if not room["enemies"]:
            self._complete_encounter(room)

    @staticmethod
    def _add_effect(room: dict, effect_type: str, x: float, y: float, color: str,
                    target_x: float | None = None, target_y: float | None = None,
                    duration: float = 0.35, text: str = "", attack_class: str = "") -> None:
        effect = {"id": secrets.token_hex(4), "type": effect_type, "x": x, "y": y,
                  "targetX": target_x if target_x is not None else x,
                  "targetY": target_y if target_y is not None else y,
                  "color": color, "until": time.time() + duration, "text": text, "class": attack_class}
        room["effects"].append(effect)
        room["effects"] = room["effects"][-80:]

    def _launch_projectile(self, room: dict, *, side: str, owner_id: str, target_id: str,
                           x: float, y: float, damage: int, color: str, attack_class: str,
                           effect_kind: str = "damage", speed: float = 270, splash: int = 0) -> None:
        target_pool = room["enemies"] if side == "hero" else room["players"].values()
        aimed = next((item for item in target_pool if item["id"] == target_id), None)
        target_x = aimed["x"] if aimed else x + 1
        target_y = aimed["y"] if aimed else y
        if side == "enemy" and aimed:
            lead = min(0.32, math.hypot(target_x - x, target_y - y) / max(speed, 1) * 0.35)
            target_x += aimed.get("dx", 0) * CLASSES.get(aimed.get("class"), {}).get("speed", 140) * lead
            target_y += aimed.get("dy", 0) * CLASSES.get(aimed.get("class"), {}).get("speed", 140) * lead
        dx, dy = target_x - x, target_y - y
        distance = max(0.001, math.hypot(dx, dy))
        room["projectiles"].append({"id": secrets.token_hex(4), "side": side, "ownerId": owner_id,
            "targetId": target_id, "x": x, "y": y, "vx": dx / distance * speed, "vy": dy / distance * speed,
            "expiresAt": time.monotonic() + 4, "damage": max(1, damage), "color": color,
            "class": attack_class, "effectKind": effect_kind, "speed": speed, "splash": splash,
            "lastTick": time.monotonic()})

    def _damage_player(self, room: dict, enemy: dict, target: dict, amount: int) -> None:
        if target["status"] == "downed":
            target["downedUntil"] = max(time.monotonic() + 0.5, target["downedUntil"] - 0.35)
            return
        now = time.monotonic()
        armor = sum(item.get("armor", 0) for item in target["toolSlots"] if item)
        curse = 1.25 if (target.get("curse") or {}).get("effect") == "frail" else 1
        damage = max(1, round(max(1, amount - armor) * curse * (target["wardFactor"] if target["wardUntil"] > now else 1)))
        target["hp"] -= damage
        if target["hp"] <= 0:
            target["hp"] = 0
            target["status"] = "downed"
            target["downedUntil"] = now + 8
            target["dx"], target["dy"] = 0, 0
            self._say(room, "system", "The Gauntlet", f"{target['name']} is down! Enemies are swarming the rescue.")

    def _tick_projectiles(self, room: dict, now: float) -> None:
        if room["phase"] != "combat":
            room["projectiles"] = []
            return
        remaining = []
        for projectile in room["projectiles"]:
            dt = min(0.12, max(0, now - projectile["lastTick"]))
            projectile["lastTick"] = now
            start_x, start_y = projectile["x"], projectile["y"]
            projectile["x"] += projectile["vx"] * dt
            projectile["y"] += projectile["vy"] * dt
            segment_x, segment_y = projectile["x"] - start_x, projectile["y"] - start_y
            segment_length = max(0.001, segment_x * segment_x + segment_y * segment_y)

            def segment_distance(item: dict) -> float:
                fraction = max(0.0, min(1.0, ((item["x"] - start_x) * segment_x + (item["y"] - start_y) * segment_y) / segment_length))
                closest_x, closest_y = start_x + segment_x * fraction, start_y + segment_y * fraction
                return math.hypot(item["x"] - closest_x, item["y"] - closest_y)

            if projectile["side"] == "hero":
                targets = [enemy for enemy in room["enemies"] if segment_distance(enemy) <= 19]
            else:
                targets = [player for player in room["players"].values() if player["status"] in ("alive", "downed")
                           and segment_distance(player) <= 19]
            target = min(targets, key=segment_distance, default=None)
            if target is None:
                if (now < projectile["expiresAt"] and -24 <= projectile["x"] <= WIDTH + 24
                        and -24 <= projectile["y"] <= HEIGHT + 24):
                    remaining.append(projectile)
                continue
            self._add_effect(room, "impact", target["x"], target["y"], projectile["color"], duration=0.3, attack_class=projectile["class"])
            if projectile["side"] == "hero":
                owner = room["players"].get(projectile["ownerId"], room["players"][room["host"]])
                targets = [target]
                if projectile["splash"]:
                    targets += [other for other in room["enemies"] if other is not target and
                                math.hypot(other["x"] - target["x"], other["y"] - target["y"]) <= projectile["splash"]]
                for struck in targets:
                    if projectile["effectKind"] == "stun":
                        struck["stunUntil"] = time.monotonic() + 1.5
                    if projectile["effectKind"] == "bleed":
                        struck["bleedUntil"] = time.monotonic() + 5
                        struck["bleedDamage"] = max(1, round(projectile["damage"] * 0.35))
                        struck["lastBleedTick"] = time.monotonic()
                    self._damage_enemy(room, owner, struck, projectile["damage"])
            else:
                self._damage_player(room, projectile, target, projectile["damage"])
        room["projectiles"] = remaining if room["phase"] == "combat" else []

    def _enemy_class_attack(self, room: dict, enemy: dict, target: dict, now: float) -> None:
        role = enemy.get("class", "Knight")
        ranged = role in ("Wizard", "Archer", "Cleric", "Druid", "Bard", "Healer")
        enemy["lastAttack"] = now
        enemy["animationUntil"] = time.time() + 0.45
        self._add_effect(room, "enemy_attack", enemy["x"], enemy["y"], enemy["color"],
                         target["x"], target["y"], 0.35, attack_class=role)
        if role == "Bard":
            for ally in room["enemies"]:
                if math.hypot(ally["x"] - enemy["x"], ally["y"] - enemy["y"]) <= 240:
                    ally["damageBoost"] = 1.25
                    ally["damageBoostUntil"] = now + 5
            self._add_effect(room, "aura", enemy["x"], enemy["y"], "#f095bf", duration=1, attack_class=role)
        elif role == "Healer":
            wounded = [ally for ally in room["enemies"] if ally["hp"] < ally["maxHp"] and
                       math.hypot(ally["x"] - enemy["x"], ally["y"] - enemy["y"]) <= 220]
            if wounded:
                ally = min(wounded, key=lambda item: item["hp"] / item["maxHp"])
                ally["hp"] = min(ally["maxHp"], ally["hp"] + max(8, enemy["damage"] * 2))
                self._add_effect(room, "heal", enemy["x"], enemy["y"], "#85d9db", ally["x"], ally["y"], 0.6, attack_class=role)
            else:
                speed_scale = self._party_factor(room, (0.68, 0.8, 0.92, 1.0)) * (0.75 + 0.25 * self._stage_ramp(room))
                self._launch_projectile(room, side="enemy", owner_id=enemy["id"], target_id=target["id"],
                    x=enemy["x"], y=enemy["y"], damage=enemy["damage"], color="#85d9db", attack_class=role, speed=200 * speed_scale)
        elif ranged:
            speed_scale = self._party_factor(room, (0.68, 0.8, 0.92, 1.0)) * (0.75 + 0.25 * self._stage_ramp(room))
            speed = {"Wizard": 240, "Archer": 340, "Cleric": 190, "Druid": 210, "Bard": 230}.get(role, 200) * speed_scale
            self._launch_projectile(room, side="enemy", owner_id=enemy["id"], target_id=target["id"],
                x=enemy["x"], y=enemy["y"], damage=enemy["damage"], color=enemy["color"], attack_class=role, speed=speed)
        else:
            damage = enemy["damage"] * (1.25 if role == "Rogue" else 1)
            self._damage_player(room, enemy, target, damage)
            if role == "Rogue" and target["status"] == "alive":
                self._add_effect(room, "bleed", target["x"], target["y"], "#cf6674", duration=0.8, attack_class=role)

    def _complete_encounter(self, room: dict) -> None:
        players = len(room["players"])
        encounter_type = room["encounterType"]
        reward = 5 + 2 * players
        if encounter_type == "mini_boss":
            room["miniBossesSinceBoss"] += 1
            reward += 12 + 4 * players
            self._say(room, "system", "The Gauntlet", "Mini-boss defeated!")
        elif encounter_type == "large_boss":
            room["bossesDefeated"] += 1
            reward += 40 + 12 * players
            if room["bossesDefeated"] == 3:
                room["runes"] += reward
                room["phase"] = "cleared"
                self._say(room, "system", "The Gauntlet", f"The final dragon falls! The party earns {reward} Runes and saves the realm!")
                return
            self._say(room, "system", "The Gauntlet", "The great foe falls. A new stretch lies ahead.")
            room["miniBossesSinceBoss"] = 0
        elif encounter_type == "assassination":
            reward += 25 + 8 * players
            self._say(room, "system", "The Gauntlet", "The assassination attempt is defeated!")
        room["runes"] += reward
        if room["stageWave"] < room["stageWaves"]:
            room["stageWave"] += 1
            room["wave"] += 1
            room["phase"] = "combat"
            room["waveStartsAt"] = time.monotonic() + 3
            room["projectiles"] = []
            room["effects"] = []
            self._say(room, "system", "The Gauntlet", f"Wave {room['stageWave']} of {room['stageWaves']} arrives in three seconds!")
            return
        self._advance_curses(room)
        self._say(room, "system", "The Gauntlet", f"Stage {room['stage']} cleared. The party earns {reward} Runes.")
        for member in room["players"].values():
            if member["status"] != "alive":
                member["status"] = "alive"
                member["hp"] = max(1, round(member["maxHp"] * 0.3))
            member["reviving"] = None
            member["attacking"] = False
        self._offer_chest_or_routes(room)

    def _offer_chest_or_routes(self, room: dict) -> None:
        chance = {"normal": 0.38, "mini_boss": 0.78, "large_boss": 1.0, "assassination": 1.0}.get(room["encounterType"], 0.38)
        if random.random() >= chance:
            self._present_routes(room)
            return
        room["chest"] = {"decisions": {}, "runesAwarded": False, "x": WIDTH / 2, "y": HEIGHT / 2}
        for player in room["players"].values():
            player["chestReward"] = None
        room["phase"] = "chest"
        room["effects"].append({"id": secrets.token_hex(4), "type": "chest_spawn", "x": WIDTH / 2, "y": HEIGHT / 2,
                                "color": "#ffd166", "until": time.time() + 1.4})
        self._say(room, "system", "The Gauntlet", "A treasure chest appears in the arena. Walk up and press E to open it.")

    def _cast_ability(self, room: dict, player: dict, slot_index: int) -> None:
        now = time.monotonic()
        ability_id = player["abilities"][slot_index]
        ability = next((ability_record(entry) for entry in ABILITY_SETS[player["class"]] if entry[0] == ability_id), None)
        if not ability:
            raise ValueError("That ability is not available to this class.")
        ready_at = player["abilityCooldowns"].get(ability_id, 0)
        if ready_at > now:
            raise ValueError(f"{ability['name']} is ready in {math.ceil(ready_at - now)} seconds.")
        kind, reach, power = ability["kind"], ability["range"], ability["power"]
        nearby = [enemy for enemy in room["enemies"] if math.hypot(enemy["x"] - player["x"], enemy["y"] - player["y"]) <= reach]
        if kind in ("damage", "stun", "bleed", "dash_strike", "pierce") and not nearby:
            raise ValueError("No enemy is in range.")
        if kind == "area" and not any(math.hypot(enemy["x"] - player["x"], enemy["y"] - player["y"]) <= reach for enemy in room["enemies"]):
            raise ValueError("No enemy is close enough.")
        if kind == "revive" and not any(member["status"] in ("downed", "fallen") and
                math.hypot(member["x"] - player["x"], member["y"] - player["y"]) <= reach
                for member in room["players"].values()):
            raise ValueError("No downed ally is close enough to revive.")
        if kind == "team_revive" and not any(member["status"] in ("downed", "fallen") for member in room["players"].values()):
            raise ValueError("No fallen allies need reviving.")
        if player["mana"] < ability["manaCost"]:
            raise ValueError(f"{ability['name']} needs {ability['manaCost']} mana.")
        player["mana"] -= ability["manaCost"]
        player["abilityCooldowns"][ability_id] = now + ability["cooldown"]
        player["animation"] = ability["attackType"]
        player["animationUntil"] = time.time() + 0.45
        base_damage = CLASSES[player["class"]]["damage"] + sum(item.get("damage", 0) for item in player["toolSlots"] if item)
        curse_factor = 0.75 if (player.get("curse") or {}).get("effect") == "weakened" else 1
        base_damage = round(base_damage * (player["damageBoost"] if player["damageBoostUntil"] > now else 1) * curse_factor)
        ranged_class = player["class"] in ("Wizard", "Archer", "Cleric", "Druid", "Bard", "Healer")
        if kind in ("damage", "stun", "bleed", "dash_strike", "pierce"):
            nearest = min(nearby, key=lambda enemy: math.hypot(enemy["x"] - player["x"], enemy["y"] - player["y"]), default=None)
            if nearest:
                player["facingX"], player["facingY"] = nearest["x"] - player["x"], nearest["y"] - player["y"]
            if ranged_class and nearest and kind not in ("dash_strike", "bleed"):
                self._add_effect(room, "cast", player["x"], player["y"], CLASSES[player["class"]]["color"],
                                 nearest["x"], nearest["y"], 0.32, attack_class=player["class"])
            elif kind in ("damage", "stun", "bleed", "dash_strike", "pierce"):
                self._add_effect(room, "slash", player["x"], player["y"], CLASSES[player["class"]]["color"],
                                 nearest["x"] if nearest else player["x"], nearest["y"] if nearest else player["y"],
                                 0.34, attack_class=player["class"])
        elif kind in ("team_heal", "revive", "team_revive"):
            self._add_effect(room, "heal", player["x"], player["y"], CLASSES[player["class"]]["color"], duration=0.6, attack_class=player["class"])
        elif kind in ("area",):
            self._add_effect(room, "burst", player["x"], player["y"], CLASSES[player["class"]]["color"], duration=0.55, attack_class=player["class"])
        else:
            self._add_effect(room, "aura", player["x"], player["y"], CLASSES[player["class"]]["color"], duration=0.6, attack_class=player["class"])

        if kind in ("damage", "stun", "bleed", "dash_strike"):
            target = min(nearby, key=lambda enemy: math.hypot(enemy["x"] - player["x"], enemy["y"] - player["y"]))
            if ranged_class and kind in ("damage", "stun"):
                speed = 360 if player["class"] == "Archer" else 260 if player["class"] == "Wizard" else 220
                self._launch_projectile(room, side="hero", owner_id=player["id"], target_id=target["id"],
                    x=player["x"], y=player["y"] - 8, damage=round(base_damage * power),
                    color=CLASSES[player["class"]]["color"], attack_class=player["class"], effect_kind=kind, speed=speed)
                target = None
            if target is None:
                pass
            else:
                if kind == "dash_strike":
                    distance = max(1, math.hypot(target["x"] - player["x"], target["y"] - player["y"]))
                    player["x"] = max(28, min(WIDTH - 28, target["x"] - (target["x"] - player["x"]) / distance * 28))
                    player["y"] = max(30, min(HEIGHT - 30, target["y"] - (target["y"] - player["y"]) / distance * 28))
                if kind == "stun":
                    target["stunUntil"] = now + 1.5
                if kind == "bleed":
                    target["bleedUntil"] = now + 5
                    target["bleedDamage"] = max(1, round(base_damage * 0.45))
                    target["lastBleedTick"] = now
                self._damage_enemy(room, player, target, round(base_damage * power))
        elif kind == "area":
            targets = [enemy for enemy in list(room["enemies"]) if math.hypot(enemy["x"] - player["x"], enemy["y"] - player["y"]) <= reach]
            for enemy in targets:
                self._damage_enemy(room, player, enemy, round(base_damage * power))
        elif kind == "pierce":
            target = min(nearby, key=lambda enemy: math.hypot(enemy["x"] - player["x"], enemy["y"] - player["y"]))
            if ranged_class:
                self._launch_projectile(room, side="hero", owner_id=player["id"], target_id=target["id"],
                    x=player["x"], y=player["y"] - 8, damage=round(base_damage * power),
                    color=CLASSES[player["class"]]["color"], attack_class=player["class"], speed=360, splash=48)
            else:
                for enemy in sorted(nearby, key=lambda item: math.hypot(item["x"] - player["x"], item["y"] - player["y"]))[:3]:
                    self._damage_enemy(room, player, enemy, round(base_damage * power))
        elif kind == "self_ward":
            player["wardUntil"] = now + 8
            player["wardFactor"] = power
        elif kind == "team_ward":
            for member in room["players"].values():
                if not reach or math.hypot(member["x"] - player["x"], member["y"] - player["y"]) <= reach:
                    member["wardUntil"] = now + 8
                    member["wardFactor"] = min(member.get("wardFactor", 1.0), power)
        elif kind == "self_damage":
            player["damageBoostUntil"], player["damageBoost"] = now + 8, power
        elif kind == "team_damage":
            for member in room["players"].values():
                member["damageBoostUntil"], member["damageBoost"] = now + 8, power
        elif kind == "team_heal":
            for member in room["players"].values():
                if member["status"] == "alive" and (not reach or math.hypot(member["x"] - player["x"], member["y"] - player["y"]) <= reach):
                    member["hp"] = min(member["maxHp"], member["hp"] + power)
        elif kind == "revive":
            fallen = [member for member in room["players"].values() if member["status"] in ("downed", "fallen") and math.hypot(member["x"] - player["x"], member["y"] - player["y"]) <= reach]
            target = min(fallen, key=lambda member: math.hypot(member["x"] - player["x"], member["y"] - player["y"]))
            target["status"], target["hp"], target["downedUntil"] = "alive", max(1, round(target["maxHp"] * 0.45)), 0
            self._say(room, "system", "The Gauntlet", f"{player['name']} quickly revived {target['name']}.")
        elif kind == "team_revive":
            revived = []
            for target in room["players"].values():
                if target["status"] in ("downed", "fallen"):
                    target["status"], target["hp"], target["downedUntil"] = "alive", max(1, round(target["maxHp"] * 0.4)), 0
                    revived.append(target["name"])
            self._say(room, "system", "The Gauntlet", f"{player['name']} called every fallen ally back: {', '.join(revived)}.")
        elif kind == "speed":
            player["speedBoostUntil"], player["speedBoost"] = now + 6, power
        elif kind == "team_speed":
            for member in room["players"].values():
                member["speedBoostUntil"], member["speedBoost"] = now + 6, power
        elif kind == "invisible":
            player["invisibleUntil"] = now + 5
        elif kind == "taunt":
            player["tauntUntil"] = now + 7
        elif kind == "summon":
            player["summonUntil"] = now + 10
            player["damageBoostUntil"], player["damageBoost"] = now + 10, power
        elif kind == "blink":
            enemy = min(room["enemies"], key=lambda entry: math.hypot(entry["x"] - player["x"], entry["y"] - player["y"]), default=None)
            if enemy:
                dx, dy = player["x"] - enemy["x"], player["y"] - enemy["y"]
                distance = max(1, math.hypot(dx, dy))
                player["x"] = max(28, min(WIDTH - 28, player["x"] + dx / distance * reach))
                player["y"] = max(30, min(HEIGHT - 30, player["y"] + dy / distance * reach))
        self._say(room, "system", "The Gauntlet", f"{player['name']} used {ability['name']}.")

    def _attack(self, room: dict, player: dict) -> None:
        if room["phase"] != "combat" or player["status"] != "alive":
            return
        now = time.monotonic()
        class_data = CLASSES.get(player["class"], {})
        cooldown = 0.42 if player["class"] == "Rogue" else 0.55
        if now - player["lastAttack"] < cooldown:
            return
        player["lastAttack"] = now
        player["animation"] = "light"
        player["animationUntil"] = time.time() + 0.45
        reach = class_data.get("range", 180)
        targets = [
            enemy for enemy in room["enemies"]
            if math.hypot(enemy["x"] - player["x"], enemy["y"] - player["y"]) <= reach
        ]
        if not targets:
            self._add_effect(room, "slash", player["x"], player["y"], class_data.get("color", "#fff"),
                             player["x"] + 18, player["y"] - 4, 0.18, attack_class=player["class"])
            return
        target = min(targets, key=lambda enemy: math.hypot(enemy["x"] - player["x"], enemy["y"] - player["y"]))
        player["facingX"], player["facingY"] = target["x"] - player["x"], target["y"] - player["y"]
        now = time.monotonic()
        weapon_bonus = sum(item.get("damage", 0) for item in player["toolSlots"] if item)
        curse_factor = 0.75 if (player.get("curse") or {}).get("effect") == "weakened" else 1
        special_factor = player["specialAttackFactor"] if player["specialAttacks"] > 0 else 1
        damage = round((class_data.get("damage", 10) + weapon_bonus) * (player["damageBoost"] if player["damageBoostUntil"] > now else 1) * curse_factor * special_factor)
        if player["specialAttacks"] > 0:
            player["specialAttacks"] -= 1
            if player["specialAttacks"] == 0:
                player["specialAttackFactor"] = 1
        ranged_classes = {"Wizard", "Archer", "Cleric", "Druid", "Bard", "Healer"}
        if player["class"] in ranged_classes:
            speed = {"Wizard": 280, "Archer": 380, "Cleric": 220, "Druid": 250, "Bard": 235, "Healer": 210}[player["class"]]
            self._add_effect(room, "cast", player["x"], player["y"], class_data.get("color", "#fff"),
                             target["x"], target["y"], 0.3, attack_class=player["class"])
            self._launch_projectile(room, side="hero", owner_id=player["id"], target_id=target["id"],
                x=player["x"], y=player["y"] - 8, damage=damage, color=class_data.get("color", "#fff"),
                attack_class=player["class"], speed=speed)
        else:
            self._add_effect(room, "slash", player["x"], player["y"], class_data.get("color", "#fff"),
                             target["x"], target["y"], 0.28, attack_class=player["class"])
            self._damage_enemy(room, player, target, damage)

    def _revive(self, room: dict, rescuer: dict) -> None:
        if room["phase"] != "combat" or rescuer["status"] != "alive":
            return
        downed = [
            player for player in room["players"].values()
            if player["status"] == "downed"
            and math.hypot(player["x"] - rescuer["x"], player["y"] - rescuer["y"]) <= 62
        ]
        if not downed:
            return
        target = min(downed, key=lambda p: math.hypot(p["x"] - rescuer["x"], p["y"] - rescuer["y"]))
        rescuer["reviving"] = target["id"]
        rescuer["reviveStarted"] = time.monotonic()

    def _tick_puzzle(self, room: dict) -> None:
        if not room.get("puzzle"):
            return
        all_ready = True
        now = time.monotonic()
        for player_id, player in room["players"].items():
            puzzle_room = room["puzzle"]["rooms"][player_id]
            standing = next((entry["rune"] for entry in puzzle_room["runes"]
                             if math.hypot(player["x"] - entry["x"], player["y"] - entry["y"]) <= 34), None)
            puzzle_room["standing"] = standing
            if standing != puzzle_room["target"]:
                all_ready = False
                if standing and now - puzzle_room["wrongAt"] >= 2.5:
                    puzzle_room["wrongAt"] = now
                    room["strainMistakes"] += 1
                    room.setdefault("privateNotices", {})[player_id] = "Wrong rune. The gauntlet grows slightly harder."
                    self._say(room, "system", "The Gauntlet", f"{player['name']} stands on the wrong rune. The run grows slightly more dangerous.")
        if not all_ready:
            return
        room["puzzlesCompleted"] += 1
        self._advance_curses(room)
        room["puzzle"] = None
        room["stageWave"] = 1
        room["phase"] = "combat"
        self._add_effect(room, "puzzle_solved", WIDTH / 2, HEIGHT / 2, "#ffe08a", duration=1.2, text="RUNE GATE OPEN")
        self._say(room, "system", "The Gauntlet", "Every adventurer found the right rune. The gate opens!")
        self._spawn_wave(room)

    def tick(self) -> None:
        now = time.monotonic()
        with self.lock:
            for room in self.rooms.values():
                room["effects"] = [effect for effect in room["effects"] if effect["until"] > time.time()]
                self._tick_projectiles(room, now)
                for player in room["players"].values():
                    elapsed = min(1.0, max(0, now - player["lastManaTick"]))
                    player["lastManaTick"] = now
                    if room["phase"] == "combat" and player["status"] == "alive":
                        player["mana"] = min(player["maxMana"], player["mana"] + 4 * elapsed)
                    elif room["phase"] in ("town", "routes", "stage_exit", "puzzle", "chest"):
                        player["mana"] = min(player["maxMana"], player["mana"] + 12 * elapsed)
                    if room["phase"] in ("town", "routes", "stage_exit", "puzzle", "chest") and player["status"] == "alive":
                        dt = min(0.1, max(0, now - player["lastMove"]))
                        player["lastMove"] = now
                        speed = CLASSES.get(player["class"], {}).get("speed", 140)
                        if room["phase"] == "town" and player.get("townInterior"):
                            player["x"] = max(180, min(WIDTH - 180, player["x"] + player["dx"] * speed * dt))
                            player["y"] = max(100, min(HEIGHT - 64, player["y"] + player["dy"] * speed * dt))
                            if player.get("townExitReady"):
                                player["townExitReady"] = False
                        else:
                            next_x = max(28, min(WIDTH - 28, player["x"] + player["dx"] * speed * dt))
                            next_y = max(30, min(HEIGHT - 30, player["y"] + player["dy"] * speed * dt))
                            if room["phase"] == "routes":
                                if self._on_fork_path(next_x, player["y"]):
                                    player["x"] = next_x
                                if self._on_fork_path(player["x"], next_y):
                                    player["y"] = next_y
                            elif room["phase"] == "town":
                                if self._town_walkable(room, next_x, player["y"]):
                                    player["x"] = next_x
                                if self._town_walkable(room, player["x"], next_y):
                                    player["y"] = next_y
                            else:
                                player["x"], player["y"] = next_x, next_y
                            if room["phase"] == "town" and player.get("townExitReady"):
                                gate_x, gate_y = TOWN_GATE
                                if math.hypot(player["x"] - gate_x, player["y"] - gate_y) > 78:
                                    player["townExitReady"] = False
                        if room["phase"] == "town" and player.get("townInteraction"):
                            npc = self._nearby_npc(room, player)
                            if not npc or npc["id"] != player["townInteraction"]:
                                player["townInteraction"] = None
                if room["phase"] in ("stage_exit", "routes"):
                    self._tick_travel(room)
                if room["phase"] == "puzzle":
                    self._tick_puzzle(room)
                    if room["phase"] != "combat":
                        continue
                if room["phase"] != "combat":
                    continue
                if room.get("waveStartsAt"):
                    if now < room["waveStartsAt"]:
                        for member in room["players"].values():
                            if member["status"] != "alive":
                                continue
                            dt = min(0.1, max(0, now - member["lastMove"]))
                            member["lastMove"] = now
                            speed = CLASSES.get(member["class"], {}).get("speed", 140)
                            member["x"] = max(28, min(WIDTH - 28, member["x"] + member["dx"] * speed * dt))
                            member["y"] = max(30, min(HEIGHT - 30, member["y"] + member["dy"] * speed * dt))
                        continue
                    room["waveStartsAt"] = 0
                    self._spawn_wave(room, preserve_players=True)
                for player in room["players"].values():
                    if player["status"] == "downed":
                        if now >= player["downedUntil"]:
                            player["status"] = "fallen"
                        continue
                    if player["status"] != "alive":
                        continue
                    dt = min(0.1, max(0, now - player["lastMove"]))
                    player["lastMove"] = now
                    curse_speed = 0.75 if (player.get("curse") or {}).get("effect") == "sluggish" else 1
                    speed = CLASSES.get(player["class"], {}).get("speed", 140) * (player["speedBoost"] if player["speedBoostUntil"] > now else 1) * curse_speed
                    player["x"] = max(28, min(WIDTH - 28, player["x"] + player["dx"] * speed * dt))
                    player["y"] = max(30, min(HEIGHT - 30, player["y"] + player["dy"] * speed * dt))
                    if player["attacking"]:
                        self._attack(room, player)
                for rescuer in room["players"].values():
                    target_id = rescuer.get("reviving")
                    if not target_id or rescuer["status"] != "alive":
                        continue
                    target = room["players"].get(target_id)
                    if not target or target["status"] != "downed" or math.hypot(target["x"] - rescuer["x"], target["y"] - rescuer["y"]) > 62:
                        rescuer["reviving"] = None
                        continue
                    duration = 0.8 if rescuer["class"] == "Healer" else 1.8
                    if now - rescuer["reviveStarted"] >= duration:
                        target["status"] = "alive"
                        target["hp"] = max(1, round(target["maxHp"] * 0.3))
                        target["downedUntil"] = 0
                        rescuer["reviving"] = None
                        self._say(room, "system", "The Gauntlet", f"{rescuer['name']} revived {target['name']}.")

                for enemy in list(room["enemies"]):
                    if enemy.get("bleedUntil", 0) > now and now - enemy.get("lastBleedTick", 0) >= 1:
                        enemy["lastBleedTick"] = now
                        self._damage_enemy(room, room["players"][room["host"]], enemy, enemy.get("bleedDamage", 0))
                        if room["phase"] != "combat":
                            break
                    if enemy.get("stunUntil", 0) > now:
                        continue
                    available = [p for p in room["players"].values() if p["status"] in ("alive", "downed")]
                    if not available:
                        break
                    downed = [p for p in available if p["status"] == "downed"]
                    taunting = [p for p in available if p["status"] == "alive" and p["tauntUntil"] > now]
                    visible = [p for p in available if p["status"] == "alive" and p["invisibleUntil"] <= now]
                    targets = downed or taunting or visible or [p for p in available if p["status"] == "alive"]
                    if not targets:
                        continue
                    target = min(targets, key=lambda p: math.hypot(p["x"] - enemy["x"], p["y"] - enemy["y"]))
                    squadron = room.get("encounterName") == "Mini-boss Squadron"
                    if squadron and not downed:
                        target_pool = taunting or visible or targets
                        enemy_index = room["enemies"].index(enemy)
                        target = target_pool[enemy_index % len(target_pool)]
                    dx, dy = target["x"] - enemy["x"], target["y"] - enemy["y"]
                    enemy["facingX"], enemy["facingY"] = dx, dy
                    previous_x, previous_y = enemy["x"], enemy["y"]
                    distance = max(0.001, math.hypot(dx, dy))
                    role = enemy.get("class", "Knight")
                    ranged = role in ("Wizard", "Archer", "Cleric", "Druid", "Bard", "Healer")
                    attack_range = {"Wizard": 205, "Archer": 275, "Cleric": 175, "Druid": 195, "Bard": 190, "Healer": 210}.get(role, 30)
                    attack_cooldown = 0.85 if role == "Rogue" else 1.45 if ranged else 1.0
                    party_aggression = self._party_factor(room, (0.56, 0.72, 0.86, 1.0))
                    attack_cooldown /= max(0.38, party_aggression * (0.62 + 0.38 * self._stage_ramp(room)))
                    if downed:
                        attack_cooldown *= 0.82
                    if enemy.get("assassin"):
                        attack_cooldown /= 1.15
                    if squadron:
                        enemy_index = room["enemies"].index(enemy)
                        slot_angle = (2 * math.pi * enemy_index / max(1, len(room["enemies"]))) + now * 0.12
                        desired_radius = attack_range * 0.72 if ranged else 23
                        slot_x = max(28, min(WIDTH - 28, target["x"] + math.cos(slot_angle) * desired_radius))
                        slot_y = max(30, min(HEIGHT - 30, target["y"] + math.sin(slot_angle) * desired_radius))
                        slot_dx, slot_dy = slot_x - enemy["x"], slot_y - enemy["y"]
                        slot_distance = max(0.001, math.hypot(slot_dx, slot_dy))
                        if slot_distance > 12:
                            enemy["x"] += slot_dx / slot_distance * enemy["speed"] * 0.055
                            enemy["y"] += slot_dy / slot_distance * enemy["speed"] * 0.055
                        if distance <= attack_range and now - enemy["lastAttack"] >= attack_cooldown:
                            self._enemy_class_attack(room, enemy, target, now)
                    elif distance > attack_range:
                        enemy["x"] += dx / distance * enemy["speed"] * 0.055
                        enemy["y"] += dy / distance * enemy["speed"] * 0.055
                    elif now - enemy["lastAttack"] >= attack_cooldown:
                        self._enemy_class_attack(room, enemy, target, now)
                    if not squadron and distance <= attack_range:
                        strafe = enemy.setdefault("strafeDirection", random.choice((-1, 1)))
                        strafe_speed = enemy["speed"] * (0.34 if ranged else 0.22)
                        enemy["x"] += (-dy / distance) * strafe_speed * 0.05 * strafe
                        enemy["y"] += (dx / distance) * strafe_speed * 0.05 * strafe
                    enemy["moving"] = math.hypot(enemy["x"] - previous_x, enemy["y"] - previous_y) > 0.1
                if room["phase"] == "combat" and room["players"] and all(p["status"] in ("downed", "fallen") for p in room["players"].values()):
                    room["phase"] = "defeat"
                    room["runes"] -= math.floor(room["runes"] * 0.4)
                    message = "The party has fallen. 40% of its Runes are lost; items remain. "
                    message += "The host can return to the last inn." if room["checkpoint"] else "The party never reached an inn checkpoint."
                    self._say(room, "system", "The Gauntlet", message + " Evil claims the field.")


WORLD = GameWorld()

