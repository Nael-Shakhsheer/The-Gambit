# The Gauntlet - project handoff

Last updated: **2026-10-06**.

This file saves the project's working context for a new chat or another computer.
It is a summary of decisions and implementation, not a copy of the conversation.
Read `README.md` for the normal startup instructions. `GAME_DESIGN.md` contains
earlier planning and can disagree with the more recent decisions below.

## Continue on another computer

1. Copy and extract `The-Gauntlet-Laptop-2026-10-06.zip` on the laptop. The archive
   includes the source, instructions, and all imported sprites. The original
   sprite ZIP files on the home PC's D: drive are not required.
2. Install Python 3.10 or newer if needed. No third-party Python packages are
   required.
3. Open the extracted **The Gauntlet** folder as the coding workspace in Codex or
   ChatGPT Work. Start a new chat with the prompt below.
4. In a terminal in that folder, run `python server.py` (or `py server.py` on
   Windows if that is how Python is installed). Open `http://127.0.0.1:8000/`.

Suggested new-chat prompt:

> Read AGENTS.md, PROJECT_CONTEXT.md, and README.md. Continue working on The
> Gauntlet from its current state. Preserve the agreed game design and existing
> features. I prefer you to implement routine changes without repeatedly asking
> for approval. My next change is: [describe the change].

The archive is a snapshot; subsequent edits on one computer do not automatically
update the other. Copy an updated project back before continuing there. Active
rooms, room codes, and current runs are held in server memory and do not transfer.
Keybindings and browser room identity are stored in that browser's localStorage.

## Product and user preferences

- A real-time, top-down, cooperative pixel fantasy game for **1-4 players**.
  Friends join from phones or laptops using a room code without accounts or an
  installation. The game is not turn based.
- During play, the game fills the playing view. HP is a red bottom bar; mana is
  blue; three equipped utility slots appear on the right side of the bottom HUD.
- Combat, explorable towns, physical fork paths, and separate puzzle rooms form
  a run. Avoid replacing these with full-screen choice popups.
- Keep future destinations' encounter types and difficulty hidden. Boss and town
  counters and raw phase titles such as STAGE_EXIT should not appear in the HUD.
- Sprites should resemble the supplied directional pixel art, with distinct
  elemental glows. Town characters are smaller so they fit the buildings.
- The user wants implementation to proceed autonomously for ordinary changes.
  Do not ask for approval at every turn.

## Architecture and file map

| File | Responsibility |
| --- | --- |
| `game.py` | Authoritative GameWorld, classes/abilities, actions, movement, combat, enemies, difficulty, stage schedules, routes, towns, economy, inventories, checkpoints |
| `puzzles.py` | Puzzle creation and private per-player room/clue views |
| `server.py` | Standard-library HTTP server, room/join/action/state APIs, static assets, simulation loop |
| `static/app.js` | Browser input, polling, interpolated canvas rendering, sprite animation, HUD and menus |
| `static/index.html` | Client page structure |
| `static/style.css` | Pixel fantasy UI, responsive playing view, menus and overlays |
| `static/sprites/` | Imported Knight, Wizard, Serpent Guard and Minotaur PNG sheets with JSON metadata |
| `README.md` | Running and playing the game |
| `GAME_DESIGN.md` | Earlier broader design notes; some sections are outdated |

The server ticks at approximately 20 Hz. The browser polls state at approximately
10 Hz and renders independently using requestAnimationFrame and interpolation.
The arena coordinate system is 960 x 540. No framework or package install is
currently needed.

HTTP APIs: `POST /api/rooms`, `POST /api/join`, `POST /api/action`, and
`GET /api/state?room=...&player=...`. Static files are served by the same server.
Sprite PNG/JSON requests are restricted to the `static/sprites` directory.

## Heroes and controls

Only one player can choose each class in a party. There are now **eight** classes
(the initial seven gained a separate Healer).

| Hero | Role | Base HP |
| --- | --- | --- |
| Knight | Melee tank | 150 |
| Wizard | Ranged arcane caster with support options | 100 |
| Archer | Fast ranged piercing attacks | 105 |
| Cleric | Splash-potion support | 85 |
| Rogue | Fast bleed damage and temporary invisibility | 80 |
| Druid | Nature caster with a spirit companion ability | 80 |
| Bard | Team damage and movement buffs | 75 |
| Healer | Strong healing and rapid revives, low damage | 110 |

Each class has two Light, two Special and two Ultimate choices in
`ABILITY_SETS`. Equip one from each category, for three abilities total. The
source is authoritative for ability names, powers, mana costs and cooldowns.

- Move with WASD by default; arrows and a touch pad also work.
- Left click / touch Light button: Light attack. Q: Special. X: Ultimate.
  Main-menu Controls & keybindings can remap relevant actions.
- Space: directional dash, five-second recharge.
- E: interact. Hold E near a downed teammate to revive in combat.
- 1, 2, 3 or numpad 1, 2, 3: equipped utilities. Clicking the slots also works.
  Gameplay hotkeys should not fire while typing in chat or another input.
- All ability and dash cooldowns refresh when entering a new stage.
- Built-in party text chat supports puzzle coordination.

## Combat, difficulty and run progression

- At the start of a combat stage, players form a line near the bottom and enemies
  begin near the top with space between them.
- Clearing a wave starts a **three-second countdown** at the top. Retain the
  current scenery and player positions; the next enemies run in from an edge.
- Ordinary wave base counts are currently 1-2 / 3-5 / 5-8 / 8-12 for one / two /
  three / four players. Stages have two waves for one or two players, three for
  three or four. Party size also scales enemy HP, damage, speed, aggression and
  projectile speed. Hidden route modifiers can change these base results.
- Enemy families include Serpent Guard, Minotaur, Wolf, Cave Spider and Cave
  Troll. Mobs receive combat kits drawn from the eight hero classes, including
  ranged and support attacks. They can move while attacking; squadrons flank and
  try to surround players. Minotaurs receive a 30% speed boost.
- Enemy projectiles aim once and then travel straight so they can be dodged.
  Heroes and enemies have attack animation/effects, including projectiles.
- A short attack-range indicator surrounds the local hero during combat.
- Downed players have an eight-second revive window. The Healer revives faster.
  Enemies become more aggressive around knockdowns. A full-party wipe recovers
  at the latest inn checkpoint, loses 40% of shared Runes, and retains items.
- Gradual added difficulty starts at **stage 8**. `_stage_ramp` uses
  `0.62 + 0.38 * (stage - 1) / 24`, then adds `0.08 + 0.04 * (stage - 8)` for
  stage 8 onward, clamped to stages 1-25. Existing stat/cadence calculations use
  that ramp. This latest tuning did not add extra waves or extra enemies.
- Large bosses occur at **stages 8, 16 and 25**. The last is always a randomized
  dragon. Two to four miniboss stages are distributed through each boss interval.
  Miniboss encounters use an empowered enemy or a larger squadron.
- First-boss pool: Serpent Matriarch, Labyrinth Minotaur King, Ancient Stone
  Behemoth, Chimera, Great Wolf Guardian. Dragon types: Fire, Ice, Dark Magic,
  Arcane and Storm.
- One 8% roll per new run determines whether an assassination ambush is scheduled
  on an eligible combat stage. It can occur at most once even after checkpoint
  recovery. Stronger enemies enter from all four sides, scaled to party size.
- Victory celebrates the final dragon defeat; defeat uses a dark presentation.

## Physical exploration and routes

- Stage rewards use a physical chest in the arena. Approach and press E; announce
  obtained loot to the player. There is no separate "leave unopened" choice.
- After combat and any treasure, prompt the party to gather at the top opening.
  This transitions into a **separate fork area**.
- Follow the left or right trail all the way to its screen edge. Everyone must
  reach an exit; majority wins a split vote and the host breaks a tie. Moving
  away cancels a player's vote. The server constrains movement to the trails.
- Fork signs show actual **location names**, not encounter spoilers. The sign
  was moved upward onto grass to avoid covering the path.
- A hidden pressure counter changes with the chosen path. Its run modifier
  affects **wave size OR enemy HP**, never both together. A rare, one-use
  Pathfinder's Lens provides a clear indication of the easier route.

## Towns, items and checkpoints

- Runs schedule 2-4 towns, weighted 15% / 70% / 15% for two / three / four. Counts
  are hidden. Village names: Mossgate, Bellweather, Hearthrest, Silverbrook and
  Rookhaven.
- Each village shuffles building locations and appearance. Players walk around
  outside, then enter individual building interiors with E at the door.
- Innkeeper, Merchant and Alchemist are inside the Inn, Store and Alchemy Lab.
  Approach the NPC and press E. There are additional decorative houses.
- Inn heals/restores the party and records the checkpoint. Merchant stock is
  class-specific (e.g. Wizard wands rather than Knight swords). Alchemist has
  potion/restoration interaction. There is no town-to-town travel menu.
- To leave, every player gathers at the outside gate and presses E to vote.
  Moving away cancels that player's readiness.
- Currency is **Runes**, shared by the party, earned through enemies, chests and
  rewards. Utilities include healing, mana, temporary buffs, special arrows and
  route hints. Loot rarities range from Common through Legendary.
- Equipment: three utility slots, two tool slots (weapon/armor), five carried
  pouch items. Equip/unequip anywhere; selling requires a merchant. Equipment
  overlays change the hero's appearance and affect combat.
- Pouch opens as a bottom-center bar. **Expand** reveals item descriptions and
  **Collapse** returns to the compact view.
- Curses occupy their own hidden sixth pouch slot; they cannot be sold or
  cleansed and must expire naturally after five completed combat/puzzle stages.
  Towns do not reduce the timer. Current curses slow movement, reduce outgoing
  damage, or increase incoming damage. Chest curse chance is 12% when uncursed.

## Puzzles

- Schedule 1-3 puzzles per run, weighted 65% / 30% / 5%. One is guaranteed;
  a third is rare.
- Players are separated into private rooms containing scattered rune sigils and
  a randomly placed clue totem. Clues require communication across the party.
  Rooms and completion adjust to party size, including solo play.
- Players must stand at their matching rune; all must be correct to proceed.
  Totem/rune use matching clear sigils and colors when the clue is revealed.
- Wrong answers increase hidden run strain slightly: 0.5% per first two mistakes,
  1% per next two, 2% each from the fifth, capped at 15%. It persists across wipes.
- Intro/clue dialogue disappears after **three seconds** and can be reread with E.

## Art and recent changes

- Imported directional sprites: Knight, Wizard, Serpent Guard, Minotaur. The
  latest completed change was the Minotaur sprite import from the supplied
  `16-bit_pixel_art_aggress-Idle-spritesheet.zip`.
- All are 9x9 sheets. Row zero provides facing poses; remaining rows correspond
  to South, Southeast, East, Northeast, North, Northwest, West and Southwest.
  Knight/Serpent/Minotaur use 68px cells; Wizard uses 64px cells.
- In `static/app.js`, `heroSprites` and `drawImportedHero` handle imported sheets.
  Minotaur uses columns 0-2 for idle, 3-5 for movement, 6-8 for attack. Other
  sheets have their own pose selections. Imported enemies retain elemental glows
  without hero equipment overlays; bosses/minibosses are scaled larger.
- Enemy affinities Fire, Ice, Dark, Arcane, Poison, Storm and Nature add colored
  glows around the base sprite rather than replacing it with unrelated art.
- Performance work separated rendering from polling, interpolated positions,
  cached scenery/glows, and reduced repeated DOM work. Stage scenery stays
  stable between waves. Town sprites use a smaller scale than combat sprites.
- Recent changes also removed the raw phase-title badge, moved the fork sign,
  and added the gentle difficulty ramp after stage 7.

## Known limits and unfinished requirements

- **No public deployment yet.** Localhost works on the host computer. Same-LAN
  devices use the host's LAN IP; a public link requires a hosting decision and
  deployment. The original multiplayer challenge wanted a public link.
- Rooms and checkpoints are not persisted to disk; server restart loses runs.
- Dedicated sprites for the other six heroes and remaining monsters/bosses are
  not imported yet; those still use code-drawn art.
- Druid companion currently provides a timed damage boost and visual marker;
  independent animal movement/attack AI is not implemented.
- The user earlier requested one class switch per player per run at towns.
  Current implementation selects classes in the lobby; the town switch is still
  missing. Do not describe it as already working.
- Balance is evolving from the user's play feedback. Recent syntax checks and
  sprite HTTP checks passed, but comprehensive multiplayer/mobile playtesting
  has not been performed. Do not claim gameplay was fully verified.
- At this handoff, Git exists locally but has no commits and no remote. Nothing
  has been uploaded or published for the laptop transfer.

There is no pending new gameplay change in this handoff. The current request is
to make the project and its context portable; continue with the user's next task.
