# The Gauntlet

A browser client with a Python authoritative game server. The game supports room codes, parties of up to four, unique class selection, per-class Light/Special/Ultimate ability choices, regenerating mana, party chat, shared movement, themed battlefields, enemy waves and bosses, puzzle paths, shops, equipment, and inn checkpoints. Equipped weapons and armor appear on player sprites and affect combat.

## Run locally

Requires Python 3.10 or newer. No third-party Python packages are required.

Run: python server.py

Open http://127.0.0.1:8000 on the host computer. Do not open `static/index.html` directly; a `file://` page cannot reach the Python API. For another device on the same Wi-Fi, open http://<host-computer-LAN-IP>:8000 and enter the room code.

The development server is not a public deployment. Publishing a public link will require choosing a hosting service and configuring the Python server for it.

## Controls

- Move: WASD by default, or arrow keys; touch movement pad on phones.
- Light attack: left-click the arena or tap the Light attack button.
- Special: Q. Ultimate: X. Both keys can be changed from Controls & keybindings in the main menu.
- Equipped utilities: 1, 2, and 3 (the number row or numpad), or click/tap their HUD slots.
- Revive: stand near a downed teammate and hold E or Revive.
- Chat: use Party Chat beside the shared game view.

## Exploring the run

- After clearing a stage and opening any treasure, gather at the top opening. The party enters a separate fork area. Walk along the left or right path to the screen edge to choose; everyone must reach an exit. A split party uses the majority choice, with the host breaking a tie.
- Town layouts shuffle each visit. Enter the Inn, Store, or Alchemy Lab with E, then approach the NPC inside and press E. Return through the door. Everyone must gather at the village gate and vote with E to leave.
- Open Pouch and press Expand to read descriptions for carried and equipped items. Equip items anywhere.
- The Knight, Wizard, Serpent Guard, and Minotaur use the supplied directional sprite sheets. Elemental enemy types use colored glows.
- Each new run makes one 8% roll for an assassination ambush, with at most one occurrence even after checkpoint recovery. Ambushes bring stronger enemies from all four sides, scaled to party size.
- Canvas animation runs independently of multiplayer polling, interpolates movement, and caches battlefield scenery and elemental glows.
